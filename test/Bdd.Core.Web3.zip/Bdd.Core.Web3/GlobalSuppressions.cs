﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="GlobalSuppressions.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

[assembly: SuppressMessage("StyleCop.CSharp.SpacingRules", "SA1008:Opening parenthesis must be spaced correctly", Justification = "New convention for Tuples", Scope = "member", Target = "~M:Bdd.Core.DataSources.RuntimeInvocationDataSource.Execute``1(System.String)~``0")]

[assembly: SuppressMessage("Reliability", "CA2000:Dispose objects before losing scope", Justification = "Requires testing", Scope = "member", Target = "~M:Bdd.Core.Web.Executors.UI.FilePage.GetDownloadedFileContent(System.String)~System.Threading.Tasks.Task{System.Byte[]}")]

[assembly: SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.Web.Executors.ElementPage")]
[assembly: SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.Web.Executors.ElementStylesPage}")]
[assembly: SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.Web.Utils.WebDriverExtensions")]
[assembly: SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.Web.Utils.JavaScriptWaiter")]
[assembly: SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.Web.StepDefinitions.WebStepDefinitionBase")]