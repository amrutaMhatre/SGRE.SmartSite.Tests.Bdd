﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="PageExtensions.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.Web.Utils
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Reflection;

    using Bdd.Core.Utils;

    using global::Bdd.Core.StepDefinitions;
    using global::Bdd.Core.Web.Executors;

    using Ocaramba;

    /// <summary>
    /// Extensions
    /// </summary>
    public static class PageExtensions
    {
        private static readonly ConcurrentDictionary<string, dynamic> PageInstances = new ConcurrentDictionary<string, dynamic>();

        private static IEnumerable<Type> pageTypes = Assembly.GetExecutingAssembly().GetExportedTypes()?.Where(t => typeof(ProjectPageBase).IsAssignableFrom(t) && t.IsClass && !t.IsAbstract && !t.Name.Equals(nameof(ProjectPageBase), StringComparison.Ordinal))
            .Union(GenericExtensions.TestAssembly.GetExportedTypes()?.Where(t => typeof(ProjectPageBase).IsAssignableFrom(t) && t.IsClass && !t.IsAbstract && !t.Name.Equals(nameof(ProjectPageBase), StringComparison.Ordinal)));

        public static T Get<T>(this StepDefinitionBase stepDefinition, bool createNew = false)
            where T : ProjectPageBase
        {
            var instance = stepDefinition.DriverContext.Get<T>(createNew);
            return instance;
        }

        public static T Get<T>(this ProjectPageBase basePage, bool createNew = false)
            where T : ProjectPageBase
        {
            var instance = basePage.DriverContext.Get<T>(createNew);
            return instance;
        }

        public static T Get<T>(this DriverContext driverContext, bool createNew = false)
            where T : ProjectPageBase
        {
            var pageType = pageTypes.SingleOrDefault(t => typeof(T).FullName.Equals(t.FullName, StringComparison.Ordinal));
            if (createNew)
            {
                return Activator.CreateInstance(pageType, driverContext) as T;
            }
            else
            {
                // TODO: What if Scenario-Outlines are executed in parallel (and one finishes before the other)?
                // Any way to have the Scenario-Outline arguments also part of the key to maintain the uniqueness?
                var key = driverContext.TestTitle;
                Debug.Assert(!string.IsNullOrWhiteSpace(key), "Get<Page> 'key' is empty!");
                var instance = PageInstances.GetOrAdd(pageType.Name + "." + key ?? string.Empty, Activator.CreateInstance(pageType, driverContext) as T);
                return instance;
            }
        }

        public static void ClearPages(this DriverContext driverContext)
        {
            var key = driverContext.TestTitle;
            foreach (var instance in PageInstances.Keys.Where(k => k.EndsWith(key, StringComparison.Ordinal)))
            {
                if (PageInstances.TryRemove(instance, out var value))
                {
                    ////(value as ProjectPageBase).DriverContext = null;
                    value = null;
                }
            }
        }
    }
}