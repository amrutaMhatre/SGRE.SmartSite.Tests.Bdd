﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="WebDriverExtensions.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.Web.Utils
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Configuration;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Resources;
    using System.Text.RegularExpressions;

    using Bdd.Core.Utils;
    using Bdd.Core.Web.Entities;
    using Bdd.Core.Web.Properties;

    using NLog;

    using Ocaramba;
    using Ocaramba.Extensions;
    using Ocaramba.Types;

    using OpenQA.Selenium;
    using OpenQA.Selenium.Internal;
    using OpenQA.Selenium.Remote;
    using OpenQA.Selenium.Support.Events;
    using OpenQA.Selenium.Support.UI;

    public static class WebDriverExtensions
    {
        // private const string ClientPerf = "var performance = window.performance || window.mozPerformance || window.msPerformance || window.webkitPerformance || {}; return performance;";
        private const string ClientEntries = "var performance = window.performance || window.mozPerformance || window.msPerformance || window.webkitPerformance || {}; return performance.getEntries();";
        private const string OuterHtml = "outerHTML";
        private const string LeftSquareBrace = "[";
        private static readonly Logger Logger = LogManager.GetLogger(nameof(WebDriverExtensions));

        private static readonly Logger PerfLogger = LogManager.GetLogger("Perf");

        private static readonly bool EnablePerfDebugLogging = bool.Parse(ConfigurationManager.AppSettings["EnablePerfDebugLogging"]);

        public static Dictionary<string, dynamic> LocatorTypes => new Dictionary<string, dynamic>(StringComparer.OrdinalIgnoreCase)
        {
            { AttributeTypes.Id, Locator.Id },
            { AttributeTypes.Class, Locator.ClassName },
            { AttributeTypes.XPath, Locator.XPath },
            { AttributeTypes.Css, Locator.CssSelector },
            { AttributeTypes.LinkText, Locator.LinkText },
            { AttributeTypes.PartialLinkText, Locator.PartialLinkText },
            { AttributeTypes.Name, Locator.Name },
            { AttributeTypes.TagName, Locator.TagName },
        };

        public static void ClearEdgeCache(this DriverContext driverContext)
        {
            try
            {
                var edgeCache = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) +
                                @"\Packages\Microsoft.MicrosoftEdge_8wekyb3d8bbwe\AC\";
                var cacheDir = new DirectoryInfo(edgeCache);
                if (cacheDir.Exists)
                {
                    foreach (var dir in cacheDir.EnumerateDirectories("#!*", SearchOption.TopDirectoryOnly))
                    {
                        try
                        {
                            dir.Delete(true);
                        }
                        catch (Exception e)
                        {
                            Logger.Warn(e);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Logger.Warn(e);
            }
        }

        public static IWebElement FindElement(this DriverContext driverContext, By by, double timeoutInSeconds)
        {
            return driverContext.Driver.FindElement(by, timeoutInSeconds);
        }

        public static ReadOnlyCollection<IWebElement> FindElements(this DriverContext driverContext, By by, double timeoutInSeconds)
        {
            return driverContext.Driver.FindElements(by, timeoutInSeconds);
        }

        public static ElementLocator GetElementLocator(this DriverContext driverContext, string resourceKey, params object[] formatArgs)
        {
            Debug.Assert(driverContext != null, $"{nameof(driverContext)} is null");
            var resource = GetResourcePair(resourceKey);
            return driverContext.GetElementLocator(resource, formatArgs);
        }

        public static ElementLocator GetElementLocator(this DriverContext driverContext, KeyValuePair<string, string> locatorTypeAndValue, params object[] formatArgs)
        {
            Debug.Assert(driverContext != null, $"{nameof(driverContext)} is null");
            var type = locatorTypeAndValue.Key;
            var locator = formatArgs?.Length > 0 ? string.Format(CultureInfo.InvariantCulture, locatorTypeAndValue.Value, formatArgs) : locatorTypeAndValue.Value;

            var locatorType = LocatorTypes[type.Trim()];
            if (locatorType is Locator)
            {
                var element = new ElementLocator(locatorType, locator);
                return element;
            }

            return null;
        }

#pragma warning disable CA1054 // Uri parameters should not be strings
        public static bool IsPageUrl(this IWebDriver webDriver, string url, double timeout)
#pragma warning restore CA1054 // Uri parameters should not be strings
        {
            try
            {
                // var wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(timeout));
                // wait.Until(d => d.Url.ToLower(CultureInfo.CurrentCulture) == url.ToLower(CultureInfo.CurrentCulture));
                webDriver.WaitUntil(timeout, SeleniumExtras.WaitHelpers.ExpectedConditions.UrlContains(url));
            }
            catch (WebDriverTimeoutException)
            {
                Logger.Error(CultureInfo.CurrentCulture, "Actual page URL is {0};", webDriver.Url);
                return false;
            }

            return true;
        }

        public static RemoteWebElement ToWrappedElement(this IWebElement element)
        {
            if (element.GetType().DeclaringType == typeof(EventFiringWebDriver))
            {
                var wrappedElement = ((IWrapsElement)element).WrappedElement as RemoteWebElement;
                return wrappedElement;
            }
            else
            {
                return element as RemoteWebElement;
            }
        }

        public static IWebDriver ToWrappedDriver(this IWebElement element)
        {
            if (element.GetType().DeclaringType == typeof(EventFiringWebDriver))
            {
                // var wrappedDriver = ((IWrapsDriver)element).WrappedDriver as RemoteWebDriver;
                var wrappedDriver = element.ToWrappedElement().WrappedDriver;
                return wrappedDriver;
            }
            else
            {
                return element.ToDriver();
            }
        }

        //// Credit: https://stackoverflow.com/a/37417900
        public static IWebDriver HookEventFiringWebDriver(
            this IWebDriver wd,
            Action<WebDriverExceptionEventArgs> error = null,
            Action<WebDriverNavigationEventArgs> navigating = null,
            Action<WebDriverNavigationEventArgs> navigated = null,
            Action<WebElementEventArgs> clicked = null,
            Action<IWebDriver> hookedDriver = null)
        {
            var ed = new EventFiringWebDriver(wd);
            ed.ElementClicked += new EventHandler<WebElementEventArgs>((o, ea) =>
            {
                clicked?.Invoke(ea);
            });

            ed.Navigated += (driver, ea) =>
            {
                navigated?.Invoke(ea);
            };

            ed.Navigating += (driver, ea) =>
            {
                navigating?.Invoke(ea);
            };

            ed.ExceptionThrown += (driver, ea) =>
            {
                error?.Invoke(ea);
            };

            hookedDriver?.Invoke(ed);
            return ed;
        }

        public static void NavigateToAndMeasureTime(this DriverContext driverContext, Uri url, bool waitForAjax)
        {
            driverContext.PerformanceMeasures.StartMeasure();
            driverContext.Driver.Navigate().GoToUrl(url);
            if (waitForAjax)
            {
                driverContext.Driver.WaitUntilJavaScriptReady();
            }

            driverContext.MeasureClientPerf(url.OriginalString, "url");
            driverContext.PerformanceMeasures.StopMeasure(url.AbsolutePath);
        }

        public static void MeasureClientPerf(this DriverContext driverContext, string id, string type)
        {
            var hasWebStorage = (driverContext.Driver as RemoteWebDriver)?.HasWebStorage;
            if (hasWebStorage.HasValue && hasWebStorage.Value)
            {
                var clientEntries = ((IJavaScriptExecutor)driverContext.Driver).ExecuteScript(ClientEntries).ToObject<List<Entry>>();
                var clientPerf = new ClientPerfMetrics
                {
                    id = id,
                    type = type,
                    entries = clientEntries,
                };

                if (EnablePerfDebugLogging)
                {
                    var logs = driverContext.Driver.Manage().Logs;
                    var perfLogs = logs.GetLog("performance");
                    var browserLogs = logs.GetLog(LogType.Browser);

                    clientPerf.browserMetrics = browserLogs.Select(x => x.Message.FromJson<object>());
                    clientPerf.perfMetrics = perfLogs.Select(x => x.Message.FromJson<object>());
                }

                var json = clientPerf.ToJson();
                PerfLogger.Info(json);
            }
        }

        public static TResult WaitUntil<TResult>(this IWebDriver driver, double timeoutInSeconds, Func<IWebDriver, TResult> condition)
        {
            WebDriverWait wait = null;
            if (timeoutInSeconds > 0)
            {
                wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutInSeconds));
            }
            else
            {
                wait = new WebDriverWait(driver, TimeSpan.FromSeconds(1));
            }

            return wait.Until(condition);
        }

        public static string GetHtmlWithParents(this IWebDriver driver, IWebElement outerElement)
        {
            //// var xPath = GetAbsoluteXPath(driver, outerElement);
            //// var html = string.Empty;
            //// var nodes = new List<string>();
            //// var elements = outerElement.FindElements(By.XPath(string.Format($"{xPath}/ancestor::*")));
            //// foreach(var element in elements)
            //// {
            ////     var attributes = ((IJavaScriptExecutor)driver).ExecuteScript(@"var items = '';" + "for (index = 0; index < arguments[0].attributes.length; ++index) { items += ' ' + arguments[0].attributes[index].name + ' = \"' + arguments[0].attributes[index].value + '\"'};" + "return items;", element).ToString();
            ////     nodes.Add(element.TagName);
            ////     html = GetXmlTags(html, element.TagName, attributes);
            //// }
            //// html += outerElement.GetAttribute(OuterHtml);
            //// return GetXmlClosingTags(html, nodes);

            var html = string.Empty;
            var xpath = GetAbsoluteXPath(driver, outerElement);
            List<string> xpathNodes = null;
            if (xpath != null)
            {
                xpathNodes = xpath.Split('/').Skip(1).ToList();
                var elements = outerElement.FindElements(By.XPath($"{xpath}/ancestor::*"));
                var i = 0;
                foreach (var element in elements)
                {
                    var regex = new Regex(@"\[(\d+).*?\]", RegexOptions.CultureInvariant);
                    var matches = regex.Matches(xpathNodes[i]);
                    if (matches.Count > 0)
                    {
                        foreach (Match match in matches)
                        {
                            xpathNodes[i] = regex.Replace(xpathNodes[i], "_" + match.Groups[1].Value, 1);
                        }
                    }

                    var attributes = ((IJavaScriptExecutor)driver).ExecuteScript(@"var items = '';" + "for (index = 0; index < arguments[0].attributes.length; ++index) { items += ' ' + arguments[0].attributes[index].name + ' = \"' + arguments[0].attributes[index].value + '\"'};" + "return items;", element).ToString();
                    html = GetXmlTags(html, xpathNodes[i], attributes);
                    i++;
                }
            }

            html += outerElement.GetAttribute(OuterHtml);
            return GetXmlClosingTags(html, xpathNodes);
        }

        // Credit: https://stackoverflow.com/a/40875386
        public static string[] SplitXPath(this string input, char splitChar = '/', char groupStart = '[', char groupEnd = ']')
        {
            var splits = new List<string>();
            var startIdx = 0;
            var groupNo = 0;

            for (var i = 0; i < input.Length; i++)
            {
                if (input[i] == splitChar && groupNo == 0)
                {
                    splits.Add(input.Substring(startIdx, i - startIdx));
                    startIdx = i + 1;
                }
                else if (input[i] == groupStart)
                {
                    groupNo++;
                }
                else if (input[i] == groupEnd)
                {
                    groupNo = Math.Max(groupNo - 1, 0);
                }
            }

            splits.Add(input.Substring(startIdx, input.Length - startIdx));
            return splits.ToArray(); // splits.Where(s => !string.IsNullOrEmpty(s)).ToArray();
        }

        public static string TransformXPath(this string input, char splitChar = '/', string replacementTemplate = @"*[contains(local-name(), '{0}')]")
        {
            var inputs = input.SplitXPath(splitChar);
            var transformation = inputs.TransformXPath(splitChar.ToString(CultureInfo.InvariantCulture), replacementTemplate);
            return transformation;
        }

        public static string TransformXPath(this string[] inputs, string splitChar = @"/", string replacementTemplate = @"*[contains(local-name(), '{0}')]")
        {
            var list = inputs.Select(x =>
            {
                return ReplaceXPath(replacementTemplate, x);
            }).ToArray();
            var join = string.Join(splitChar, list);
            return join;
        }

        public static void ClientClick(this IWebElement element)
        {
            element.JavaScriptClick();
        }

        public static bool ElementExists(this IWebDriver driver, By by, double timeout = BrowserOptions.DefaultTimeout)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeout));
            try
            {
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(by));
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool ElementIsVisible(this IWebDriver driver, By by, double timeout = BrowserOptions.DefaultTimeout)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeout));
            try
            {
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(by));
                return true;
            }
            catch
            {
                return false;
            }
        }

        private static KeyValuePair<string, string> GetResourcePair(string resourceKey)
        {
            var testAssembly = GenericExtensions.TestAssembly;
            var resourceManager = new ResourceManager($"{GenericExtensions.TestAssemblyName}.Properties.Resources", testAssembly);
            var identifiers = resourceManager.GetString(resourceKey, CultureInfo.InvariantCulture)?.Split(new[] { ':' }, 2, StringSplitOptions.RemoveEmptyEntries);
            var type = AttributeTypes.Id;
            string locator;

            if (identifiers?.Length > 1)
            {
                type = identifiers[0];
                locator = identifiers[1];
            }
            else
            {
                locator = identifiers?[0];
            }

            Logger.Debug(locator);
            return new KeyValuePair<string, string>(type, locator);
        }

        // Credit: https://stackoverflow.com/a/47088726
        private static string GetAbsoluteXPath(IWebDriver driver, IWebElement element)
        {
            return (string)((IJavaScriptExecutor)driver).ExecuteScript(Resource.AbsoluteXPathScript, element);
        }

        private static string ReplaceXPath(string replacementTemplate, string x)
        {
            var replacement = string.Empty;
            if (x?.Length > 0)
            {
                var containsLeftSquareBrace = x.Contains(LeftSquareBrace);
                var replacementSuffix = containsLeftSquareBrace ? LeftSquareBrace : string.Empty;
                var tag = containsLeftSquareBrace ? x.Substring(0, x.IndexOf(LeftSquareBrace, StringComparison.OrdinalIgnoreCase)) : x;
                replacement = x.Replace(tag + replacementSuffix, string.Format(CultureInfo.InvariantCulture, replacementTemplate, tag) + replacementSuffix);
            }

            return replacement;
        }

        private static string GetXmlTags(string html, string node, string attributes)
        {
            html += $"<{node}{attributes}>";
            return html;
        }

        private static string GetXmlClosingTags(string html, List<string> nodes)
        {
            nodes?.Reverse();
            foreach (var node in nodes?.Skip(1))
            {
                if (!string.IsNullOrEmpty(node))
                {
                    html += $"</{node}>";
                }
            }

            return html;
        }

        private static IWebElement FindElement(this IWebDriver driver, By by, double timeoutInSeconds)
        {
            if (timeoutInSeconds > 0)
            {
                var wait = WaitForDriver(driver, timeoutInSeconds);
                return wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(by));
            }

            return driver.FindElement(by);
        }

        private static ReadOnlyCollection<IWebElement> FindElements(this IWebDriver driver, By by, double timeoutInSeconds)
        {
            if (timeoutInSeconds > 0)
            {
                var wait = WaitForDriver(driver, timeoutInSeconds);
                return wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.PresenceOfAllElementsLocatedBy(by));
            }

            return driver.FindElements(by);
        }

        private static WebDriverWait WaitForDriver(this IWebDriver driver, double timeoutInSeconds)
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutInSeconds));
            wait.IgnoreExceptionTypes(typeof(NoSuchElementException));
            return wait;
        }
    }
}