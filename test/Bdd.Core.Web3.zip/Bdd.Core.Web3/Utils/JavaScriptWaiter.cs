﻿// <copyright file="JavaScriptWaiter.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>

namespace Bdd.Core.Web.Utils
{
    using System;
    using System.Threading.Tasks;
    using NLog;
    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.UI;

    /// <summary>
    /// Credit: https://www.swtestacademy.com/selenium-wait-javascript-angular-ajax/.
    /// </summary>
    public static class JavaScriptWaiter
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        // Wait for JQuery Load
        public static void WaitForJQueryLoad(this IWebDriver jsWaitDriver, int timeoutSec = 15)
        {
            var jsWait = new WebDriverWait(jsWaitDriver, TimeSpan.FromSeconds(timeoutSec));
            var jsExec = (IJavaScriptExecutor)jsWaitDriver;

            // Get JQuery is Ready
            bool jqueryReady = (bool)jsExec.ExecuteScript("return jQuery.active==0");

            // Wait JQuery until it is Ready!
            if (!jqueryReady)
            {
                Logger.Warn("JQuery is NOT Ready!");

                // Wait for jQuery to load
                jsWait.Until(driver => ((long)((IJavaScriptExecutor)jsWaitDriver).ExecuteScript("return jQuery.active") == 0));
            }
            else
            {
                Logger.Trace("JQuery is Ready!");
            }
        }

        // Wait for Angular Load
        public static void WaitForAngularLoad(this IWebDriver jsWaitDriver, int timeoutSec = 15)
        {
            var jsExec = (IJavaScriptExecutor)jsWaitDriver;
            var wait = new WebDriverWait(jsWaitDriver, TimeSpan.FromSeconds(timeoutSec));
            var angularReadyScript = "return angular.element(document).injector().get('$http').pendingRequests.length === 0";

            // Get Angular is Ready
            var angularReady = bool.Parse(jsExec.ExecuteScript(angularReadyScript).ToString());

            // Wait ANGULAR until it is Ready!
            if (!angularReady)
            {
                Logger.Warn("ANGULAR is NOT Ready!");

                // Wait for Angular to load
                wait.Until(driver => bool.Parse(((IJavaScriptExecutor)driver).ExecuteScript(angularReadyScript).ToString()));
            }
            else
            {
                Logger.Trace("ANGULAR is Ready!");
            }
        }

        // Wait Until JS Ready
        public static void WaitUntilJavaScriptReady(this IWebDriver jsWaitDriver, double timeoutSec = 15)
        {
            var wait = new WebDriverWait(jsWaitDriver, TimeSpan.FromSeconds(timeoutSec));
            var jsExec = (IJavaScriptExecutor)jsWaitDriver;

            // Get JS is Ready
            var jsReady = jsExec.ExecuteScript("return document.readyState").ToString().Equals("complete", StringComparison.OrdinalIgnoreCase);

            // Wait JavaScript until it is Ready!
            if (!jsReady)
            {
                Logger.Warn("JS in NOT Ready!");

                // Wait for JavaScript to load
                wait.Until(driver => ((IJavaScriptExecutor)jsWaitDriver).ExecuteScript("return document.readyState").ToString().Equals("complete", StringComparison.OrdinalIgnoreCase));
            }
            else
            {
                Logger.Debug("JS is Ready!");
            }
        }

        // Wait Until JQuery and JS Ready
        public static void WaitUntilJQueryReady(this IWebDriver jsWaitDriver, int timeoutSec = 15)
        {
            var jsExec = (IJavaScriptExecutor)jsWaitDriver;

            // First check that JQuery is defined on the page. If it is, then wait AJAX
            var jqueryDefined = (bool)jsExec.ExecuteScript("return typeof jQuery != 'undefined'");
            if (jqueryDefined)
            {
                //// Pre Wait for stability (Optional)
                // await Sleep(timeoutSec).ConfigureAwait(false);

                // Wait JQuery Load
                jsWaitDriver.WaitForJQueryLoad(timeoutSec);

                // Wait JS Load
                jsWaitDriver.WaitUntilJavaScriptReady(timeoutSec);

                //// Post Wait for stability (Optional)
                // await Sleep(timeoutSec).ConfigureAwait(false);
            }
            else
            {
                Logger.Warn("jQuery is not defined on this site!");
            }
        }

        // Wait Until Angular and JS Ready
        public static void WaitUntilAngularReady(this IWebDriver jsWaitDriver, int timeoutSec = 15)
        {
            var jsExec = (IJavaScriptExecutor)jsWaitDriver;

            // First check that ANGULAR is defined on the page. If it is, then wait ANGULAR
            var angularUnDefined = (bool)jsExec.ExecuteScript("return window.angular === undefined");
            if (!angularUnDefined)
            {
                var angularInjectorUnDefined = (bool)jsExec.ExecuteScript("return angular.element(document).injector() === undefined");
                if (!angularInjectorUnDefined)
                {
                    //// Pre Wait for stability (Optional)
                    // await Sleep(timeoutSec).ConfigureAwait(false);

                    // Wait Angular Load
                    jsWaitDriver.WaitForAngularLoad(timeoutSec);

                    // Wait JS Load
                    jsWaitDriver.WaitUntilJavaScriptReady(timeoutSec);

                    //// Post Wait for stability (Optional)
                    // await Sleep(timeoutSec).ConfigureAwait(false);
                }
                else
                {
                    Logger.Warn("Angular injector is not defined on this site!");
                }
            }
            else
            {
                Logger.Warn("Angular is not defined on this site!");
            }
        }

        // Wait Until JQuery Angular and JS is ready
        public static void WaitUntilJQueryAndAngularReady(this IWebDriver jsWaitDriver, int timeoutSec = 15)
        {
            jsWaitDriver.WaitUntilJQueryReady(timeoutSec);
            jsWaitDriver.WaitUntilAngularReady(timeoutSec);
        }

        private static async Task Sleep(int seconds)
        {
            try
            {
                await Task.Delay(seconds).ConfigureAwait(false);
            }
            catch (Exception e)
            {
                Logger.Warn(e);
            }
        }

        // // Credit: https://stackoverflow.com/questions/15122864/selenium-wait-until-document-is-ready
        // public static IWebDriver WaitForLoad(this IWebDriver driver, int timeoutSec = 15)
        // {
        //     var wait = new WebDriverWait(driver, new TimeSpan(0, 0, timeoutSec));
        //     var javaScriptExecutor = driver as IJavaScriptExecutor;
        //     wait.Until(wd =>
        //     {
        //         var readyState = javaScriptExecutor.ExecuteScript("return document.readyState")?.ToString();
        //         var jquery = javaScriptExecutor.ExecuteScript("return jQuery.active")?.ToString();
        //         return (readyState?.Equals("complete", StringComparison.OrdinalIgnoreCase) == true || readyState?.Equals("loaded", StringComparison.OrdinalIgnoreCase) == true) && jquery?.Equals("0", StringComparison.OrdinalIgnoreCase) == true;
        //     });
        //     ////wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.VisibilityOfAllElementsLocatedBy(By.XPath("//*")));
        //     return driver;
        // }
    }
}
