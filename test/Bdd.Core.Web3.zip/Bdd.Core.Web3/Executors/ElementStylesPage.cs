﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ElementStylesPage.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.Web.Executors
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using global::Bdd.Core.Utils;

    using global::Bdd.Core.Web.Entities;
    using global::Bdd.Core.Web.Utils;

    using Ocaramba;
    using Ocaramba.Extensions;
    using Ocaramba.Types;

    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.UI;

    public class ElementStylesPage : ProjectPageBase
    {
        private const string Color = "color";
        private const string BackgroundColor = "background-color";

        private const string FontSize = "font-size";
        private const string FontFamily = "font-family";
        private const string FontWeight = "font-weight";

        public ElementStylesPage(DriverContext driverContext)
           : base(driverContext)
        {
        }

        public List<ElementStyle> GetElementStyles(string resourceKey, List<Element> validatedElements, bool waitUntilFound = true, params string[] formatArgs)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey, formatArgs.Select(formatResourceKey => formatResourceKey.GetResourceValue()).ToArray());
            return this.GetElementStyles(locator, validatedElements, waitUntilFound);
        }

        public List<ElementStyle> GetElementStyles(KeyValuePair<string, string> locatorTypeAndValue, List<Element> validatedElements, bool waitUntilFound = true, params string[] formatArgs)
        {
            var locator = this.DriverContext.GetElementLocator(locatorTypeAndValue, formatArgs.Select(formatResourceKey => formatResourceKey.GetResourceValue()).ToArray());
            return this.GetElementStyles(locator, validatedElements, waitUntilFound);
        }

        public List<ElementStyle> GetElementStyles(IEnumerable<KeyValuePair<string, string>> locatorTypesAndValues, List<Element> validatedElements, bool waitUntilFound = true, params string[] formatArgs)
        {
            var styles = new List<ElementStyle>();
            foreach (var locatorTypeAndValue in locatorTypesAndValues)
            {
                var locator = this.DriverContext.GetElementLocator(locatorTypeAndValue, formatArgs.Select(formatResourceKey => formatResourceKey.GetResourceValue()).ToArray());
                var result = this.GetElementStyles(locator, validatedElements, waitUntilFound);
                styles.AddRange(result);
            }

            return styles;
        }

        private List<ElementStyle> GetElementStyles(ElementLocator locator, List<Element> validatedElements, bool waitUntilFound)
        {
            IList<IWebElement> webElements = null;
            if (waitUntilFound)
            {
                var wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(BaseConfiguration.MediumTimeout));
                var waitForElement = new Func<IWebDriver, bool>(driver =>
                {
                    try
                    {
                        webElements = driver.GetElements(locator);
                        return webElements?.Any() == true;
                    }
                    catch (Exception)
                    {
                        return false;
                    }
                });

                wait.Until(waitForElement);
            }
            else
            {
                webElements = this.Driver.GetElements(locator);
            }

            var freshElements = webElements?.Where(x => !validatedElements.Any(y => y.Name.Equals(x.Text, StringComparison.Ordinal) && y.Type.Equals(x.TagName, StringComparison.Ordinal) && y.Size.Height.Equals(x.Size.Height) && y.Size.Width.Equals(x.Size.Width) && y.Location.X.Equals(x.Location.X) && y.Location.Y.Equals(x.Location.Y) && y.Enabled.Equals(x.Enabled) && y.Displayed.Equals(x.Displayed)));
            var styles = freshElements.Select(element =>
                {
                    return new ElementStyle
                    {
                        Element = new Element
                        {
                            Name = element.Text,
                            Type = element.TagName,
                            Enabled = element.Enabled,
                            Displayed = element.Displayed,
                            Html = this.Driver.GetHtmlWithParents(element),
                            Locator = locator.Value,
                            FontSize = element.GetCssValue(FontSize),
                            Color = element.GetCssValue(Color),
                            BackgroundColor = element.GetCssValue(BackgroundColor),
                            FontFamily = element.GetCssValue(FontFamily),
                            FontWeight = element.GetCssValue(FontWeight),
                            Size = new Size { Height = element.Size.Height, Width = element.Size.Width },
                            Location = new Location { X = element.Location.X, Y = element.Location.Y },
                            //// Margin = new Margin { General = element.GetCssValue(Margin), Left = element.GetCssValue(MarginLeft), Top = element.GetCssValue(MarginTop), Right = element.GetCssValue(MarginRight), Bottom = element.GetCssValue(MarginBottom) }
                        },
                    };
                }).ToList();
            return styles;
        }
    }
}
