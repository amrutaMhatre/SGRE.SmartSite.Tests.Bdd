﻿// <copyright file="UrlPage.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>

namespace Bdd.Core.Web.Executors
{
    using System;
    using System.Collections.Specialized;
    using System.Globalization;
    using System.Web;

    using global::Bdd.Core.Utils;
    using global::Bdd.Core.Web.Entities;
    using global::Bdd.Core.Web.Utils;

    using Ocaramba;

    public class UrlPage : ProjectPageBase
    {
        public UrlPage(DriverContext driverContext)
            : base(driverContext)
        {
        }

        public Uri Url
        {
            get
            {
                return new Uri(this.DriverContext.Driver.Url);
            }
        }

        public string[] GetUrlSegments()
        {
            return this.DriverContext.Driver.Url.Split('/');
        }

        public string GetQueryValue(string key, Uri url = null)
        {
            var results = this.GetQueryParams(url);
            return results[key];
        }

        public NameValueCollection GetQueryParams(Uri url = null)
        {
            if (url == null)
            {
                url = this.Url;
            }

            var queryParams = HttpUtility.ParseQueryString(url.Query);
            return queryParams;
        }

        public bool UrlContains(string text, bool ignoreCase = true)
        {
            return ignoreCase ? this.Driver.Url.ContainsIgnoreCase(text) : this.Driver.Url.Contains(text);
        }

        public void NavigateTo(string endpoint, bool newWindow = false)
        {
            if (newWindow)
            {
                this.Get<WindowPage>().OpenWindow();
                this.Get<WindowPage>().SwitchToAdjacentWindow();
            }

            this.Driver.Navigate().GoToUrl(new Uri(endpoint));
            Logger.Info(CultureInfo.CurrentCulture, "Opening page {0}", endpoint);
        }

        public void NavigateToUrl(string endpoint)
        {
            this.DriverContext.NavigateToAndMeasureTime(new Uri(endpoint), true);
            Logger.Info(CultureInfo.InvariantCulture, "Opening page {0}", endpoint);
        }

        public bool WaitUntilUrlContains(string fraction, double timeout = BrowserOptions.DefaultTimeout)
        {
            return this.Driver.WaitUntil(timeout, SeleniumExtras.WaitHelpers.ExpectedConditions.UrlContains(fraction));
        }
    }
}
