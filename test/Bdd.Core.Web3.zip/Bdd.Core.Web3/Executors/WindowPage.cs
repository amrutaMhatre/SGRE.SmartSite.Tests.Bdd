﻿// <copyright file="WindowPage.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>

namespace Bdd.Core.Web.Executors
{
    using Ocaramba;
    using Ocaramba.Extensions;

    using OpenQA.Selenium;

    /// <summary>
    /// Element Page
    /// </summary>
    public class WindowPage : ProjectPageBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WindowPage" /> class.
        /// </summary>
        /// <param name="driverContext">The driver context.</param>
        public WindowPage(DriverContext driverContext)
            : base(driverContext)
        {
        }

        public void SwitchToFrame(int index)
        {
            this.Driver.SwitchTo().Frame(index);
        }

        public IWebDriver SwitchToWindow(int handleIndex)
        {
            return this.Driver.SwitchTo().Window(this.Driver.WindowHandles[handleIndex]);
        }

        public object OpenWindow()
        {
            var jscript = this.Driver as IJavaScriptExecutor;
            return jscript.ExecuteScript("window.open()");
        }

        public void SwitchToAdjacentWindow()
        {
            var tabs = this.DriverContext.Driver.WindowHandles;
            this.SwitchToWindow(tabs.Count - 1);
        }

        public void ExecuteScript(string script, params object[] args)
        {
            var js = (IJavaScriptExecutor)this.Driver;
            js.ExecuteScript(script, args);
        }

        public string GetPageTitle()
        {
            var title = this.Driver.Title;
            return title;
        }

        public bool HasPageTitle(string pageTitle)
        {
            return this.Driver.IsPageTitle(pageTitle, BaseConfiguration.LongTimeout);
        }

        public void Refresh()
        {
            this.Driver.Navigate().Refresh();
        }

        public void Back()
        {
            this.Driver.Navigate().Back();
        }
    }
}