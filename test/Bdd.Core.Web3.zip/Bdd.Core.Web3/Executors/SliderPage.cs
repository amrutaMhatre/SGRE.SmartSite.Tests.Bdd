﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SliderPage.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.Web.Executors
{
    using Bdd.Core.Web.Utils;

    using Ocaramba;

    using OpenQA.Selenium.Interactions;

    public class SliderPage : ProjectPageBase
    {
        public SliderPage(DriverContext driverContext)
            : base(driverContext)
        {
        }

        public void SlideElement(string resourceKey, params object[] formatArgs)
        {
            var element = this.Get<ElementPage>().GetElement(resourceKey, formatArgs);
            var action = new Actions(this.Driver);
            action.DragAndDropToOffset(element, 100, 0).Build().Perform();
        }
    }
}
