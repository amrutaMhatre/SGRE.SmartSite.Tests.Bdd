﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ProjectPageBase.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.Web.Executors
{
    using System;

    using NLog;

    using Ocaramba;

    using OpenQA.Selenium;

    using SeleniumExtras.PageObjects;

    public class ProjectPageBase 
    {
        /// <summary>
        /// The logger.
        /// </summary>
        protected static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectPageBase" /> class.
        /// </summary>
        /// <param name="driverContext">The driver context.</param>
        public ProjectPageBase(DriverContext driverContext)
        {
            this.DriverContext = driverContext;
            this.Driver = driverContext.Driver; // .ToWrappedDriver()?
            // this.Driver.WaitUntilJavaScriptReady(BaseConfiguration.MediumTimeout);
            PageFactory.InitElements(this, new RetryingElementLocator(this.Driver, TimeSpan.FromSeconds(BaseConfiguration.MediumTimeout)));
        }

        /// <summary>
        /// Gets or sets the driver context.
        /// </summary>
        /// <value>
        /// The driver context.
        /// </value>
        public DriverContext DriverContext { get; set; }

        protected IWebDriver Driver { get; set; }

        protected int ImplicitlyWaitMilliseconds => (int)BaseConfiguration.ImplicitlyWaitMilliseconds;
    }
}