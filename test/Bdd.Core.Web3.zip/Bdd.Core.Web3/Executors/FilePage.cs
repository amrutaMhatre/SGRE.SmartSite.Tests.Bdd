﻿// <copyright file="FilePage.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>

namespace Bdd.Core.Web.Executors.UI
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;

    using Bdd.Core.Executors;
    using Bdd.Core.Utils;
    using Bdd.Core.Web.Entities;
    using Bdd.Core.Web.Executors;
    using Bdd.Core.Web.Utils;
    using EmbedIO;
    using Flurl.Http;

    using Newtonsoft.Json.Linq;

    using Ocaramba;
    using Ocaramba.Types;

    using OpenQA.Selenium;
    using OpenQA.Selenium.Remote;

    using TechTalk.SpecFlow;

    public class FilePage : ProjectPageBase
    {
        private const string ChromeDownloads = "chrome://downloads";
        private const string GetFilesScript = "return downloads.Manager.get().items_.filter(e => e.state === \"COMPLETE\").map(e => e.file_url);";

        private const string NGrokArgs = "http -host-header=\"localhost:9696\" 9696";
        private const string NGrokApiEndpoint = "http://localhost:4040/api/tunnels";
        private const string LocalWebServerUrl = "http://localhost:9696";
        private const string ReadFileHtml = "/ReadFile.html";
        private static readonly string NGrokPath = @"Web\ngrok.exe".GetFullPath();

        public FilePage(DriverContext driverContext)
            : base(driverContext)
        {
        }

        public void SelectFile(IWebElement input, string filePath)
        {
            input.SendKeys(filePath);
        }

        public void SelectFile(ElementLocator locator, string filePath, double timeout = BrowserOptions.DefaultTimeout)
        {
            var input = this.Get<ElementPage>().GetElement(locator, timeout);
            this.SelectFile(input, filePath);
        }

        public void SelectFile(string resourceKey, string filePath, params object[] formatArgs)
        {
            var input = this.Get<ElementPage>().GetElement(resourceKey, formatArgs);
            this.SelectFile(input, filePath);
        }

        public void RemoteSelectFile(string resourceKey, string filePath, params object[] formatArgs)
        {
            var fileDetectionDriver = this.DriverContext.Driver as IAllowsFileDetection;
            var fileDetector = fileDetectionDriver.FileDetector;
            fileDetectionDriver.FileDetector = new LocalFileDetector();
            this.SelectFile(resourceKey, filePath, formatArgs);
            fileDetectionDriver.FileDetector = fileDetector;
        }

        public List<string> GetDownloadedFiles()
        {
            if (!this.Driver.Url.StartsWith(ChromeDownloads, StringComparison.OrdinalIgnoreCase))
            {
                this.Get<UrlPage>().NavigateTo(ChromeDownloads, true);
            }

            var files = ((IJavaScriptExecutor)this.Driver).ExecuteScript(GetFilesScript).ToObject<List<string>>();
            return files.Select(x => Uri.UnescapeDataString(x.Replace("file:///", string.Empty)))?.ToList();
        }

        public string GetDownloadedFilePath(string fileName)
        {
            var files = this.GetDownloadedFiles();
            var file = files.FirstOrDefault(x => x.EndsWith(fileName, StringComparison.OrdinalIgnoreCase));
            if (string.IsNullOrWhiteSpace(file))
            {
                file = files.FirstOrDefault(x => x.Contains(fileName));
            }

            return file;
        }

        public async Task<byte[]> GetDownloadedFileContent(string fileName)
        {
            var filePath = this.GetDownloadedFilePath(fileName);
            var readFileUrl = ConfigurationManager.AppSettings["ReadFileUrl"];
            if (string.IsNullOrWhiteSpace(readFileUrl))
            {
                using (var server = new WebServer(LocalWebServerUrl))
                {
#pragma warning disable AsyncFixer04 // A disposable object used in a fire & forget async call
#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
                    // Don't await
                    server.WithLocalSessionManager()
                          .WithStaticFolder("/", "Web".GetFullPath(), true)
                          .RunAsync();
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed
#pragma warning restore AsyncFixer04 // A disposable object used in a fire & forget async call

                    using (var ngrok = new ConsoleExecutor())
                    {
                        await ngrok.Run(NGrokPath, NGrokArgs, false, onOutputReceived: Logger.Info, onErrorReceived: Logger.Error, workingDirectory: Path.GetDirectoryName(NGrokPath), createNoWindow: false).ConfigureAwait(false);
                        await Task.Delay(2000).ConfigureAwait(false);
                        var json = await NGrokApiEndpoint.GetJsonAsync<JObject>().ConfigureAwait(false);
                        var tunnels = json?.SelectToken("tunnels");
                        readFileUrl = tunnels?.Select(s => (string)s["public_url"]).LastOrDefault();
                        return this.GetFileContent(filePath, readFileUrl);
                    }
                }
            }
            else
            {
                var remoteHtmlFileUrl = readFileUrl.EndsWith(ReadFileHtml, StringComparison.InvariantCultureIgnoreCase) ? readFileUrl : readFileUrl.TrimEnd('/') + ReadFileHtml;
                return this.GetFileContent(filePath, remoteHtmlFileUrl);
            }
        }

        public async Task<dynamic> CheckDownloadedFileContent(string fileName, ScenarioContext scenarioContext, FeatureContext featureContext)
        {
            var dataSource = scenarioContext.GetDataSourceByExtension(featureContext, fileName);
            var newFile = (Path.GetFileNameWithoutExtension(fileName) + "_Validate" + Path.GetExtension(fileName)).GetFullPath();
            var bytes = await this.GetDownloadedFileContent(fileName).ConfigureAwait(false);
            File.WriteAllBytes(newFile, bytes);

            dynamic result = null;
            if (dataSource != null)
            {
                dataSource.Input = newFile;
                result = await dataSource.ReadAllAsync<dynamic>().ConfigureAwait(false);
            }

            return result;
        }

        private byte[] GetFileContent(string filePath, string href)
        {
            this.Get<UrlPage>().NavigateTo(href);
            this.Get<FilePage>().SelectFile(this.Driver.FindElement(By.Id("files")), filePath);
            this.Driver.FindElement(By.Id("btn_Read")).Click();
            var content = this.Driver.FindElement(By.Id("byte_content")).Text;
            var bytes = Convert.FromBase64String(content);
            this.Get<WindowPage>().SwitchToWindow(0);
            return bytes;
        }
    }
}
