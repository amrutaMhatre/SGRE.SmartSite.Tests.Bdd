﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ElementPage.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.Web.Executors
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Globalization;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Threading;

    using Bdd.Core.Web.Utils;

    using global::Bdd.Core.Utils;
    using global::Bdd.Core.Web.Entities;

    using Ocaramba;
    using Ocaramba.Extensions;
    using Ocaramba.Types;

    using OpenQA.Selenium;
    using OpenQA.Selenium.Interactions;
    using OpenQA.Selenium.Support.Events;
    using OpenQA.Selenium.Support.UI;

    public class ElementPage : ProjectPageBase
    {
        private const string VKey = "v";
        private static readonly string[] NonClickableElements = new string[] { "span", "div", "label", "input" };

        /// <summary>
        /// Initializes a new instance of the <see cref="ElementPage"/> class.
        /// </summary>
        /// <param name="driverContext"></param>
        public ElementPage(DriverContext driverContext)
            : base(driverContext)
        {
        }

        public event EventHandler<WebElementEventArgs> ElementClientClicked;

        public ElementPage ClearText(string resourceKey, params object[] formatArgs)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            return this.ClearText(locator);
        }

        public ElementPage ClearText(ElementLocator locator)
        {
            this.GetElement(locator).Clear();
            this.GetElement(locator).SendKeys(string.Empty);
            return this;
        }

        public ElementPage SetValue(string resourceKey, string value, params object[] formatArgs)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            var element = this.GetElement(locator);
            return this.SetValue(element, value);
        }

        public ElementPage SetValue(IWebElement element, string value)
        {
            element.Clear();
            this.SetClipboardText(value);
            element.SendKeys(Keys.Control + VKey);
            return this;
        }

        public ElementPage EnterText(ElementLocator locator, string value)
        {
            this.ClearText(locator);
            this.GetElement(locator).SendKeys(value);
            return this;
        }

        public ElementPage EnterText(string resourceKey, string value, params object[] formatArgs)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            return this.EnterText(locator, value);
        }

        public string GetElementText(string resourceKey, params object[] formatArgs)
        {
            try
            {
                var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
                var element = this.GetElement(elementLocator);
                var elementText = element?.Text;
                return elementText;
            }
            catch
            {
                return null;
            }
        }

        public string GetAttributeValue(string resourceKey, string attributeKey, params object[] formatArgs)
        {
            try
            {
                var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
                var element = this.GetElement(elementLocator);
                var elementText = element?.GetAttribute(attributeKey);
                return elementText;
            }
            catch
            {
                return null;
            }
        }

        public bool CheckIfElementIsPresent(string resourceKey, double timeout = BrowserOptions.DefaultTimeout, params object[] formatArgs)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);

            // return this.Driver.IsElementPresent(elementLocator, timeout);
            var exists = this.Driver.ElementExists(elementLocator.ToBy(), timeout);
            return exists;
        }

        public IList<IWebElement> GetListElements(string resourceKey, params object[] formatArgs)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            var elementList = this.GetElements(elementLocator);
            return elementList;
        }

        public IWebElement GetElement(string resourceKey, params object[] formatArgs)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            return this.GetElement(elementLocator);
        }

        public IWebElement GetElement(ElementLocator elementLocator, double timeout = BrowserOptions.DefaultTimeout)
        {
            var wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(timeout));
            var element = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(elementLocator.ToBy()));
            return element;
        }

        public IList<IWebElement> GetElements(string resourceKey, params object[] formatArgs)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            return this.GetElements(elementLocator);
        }

        public IList<IWebElement> GetElements(ElementLocator elementLocator, double timeout = BrowserOptions.DefaultTimeout)
        {
            var elements = this.DriverContext.FindElements(elementLocator.ToBy(), timeout);
            return elements;
        }

        public void SlideElement(string resourceKey, int offsetX, int offsetY, params object[] formatArgs)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            this.SlideElement(elementLocator, offsetX, offsetY);
        }

        public void SlideElement(ElementLocator elementLocator, int offsetX, int offsetY)
        {
            var element = this.GetElement(elementLocator);
            var action = new Actions(this.Driver);
            action.DragAndDropToOffset(element, offsetX, offsetY)
                .Build()
                .Perform();
        }

        public void DrawOnSurface(string resourceKey, int offsetX, int offsetY, int moveByOffsetX, int moveByOffsetY, params object[] formatArgs)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            this.DrawOnSurface(elementLocator, offsetX, offsetY, moveByOffsetX, moveByOffsetY);
        }

        public void DrawOnSurface(ElementLocator elementLocator, int offsetX, int offsetY, int moveByOffsetX, int moveByOffsetY)
        {
            var element = this.GetElement(elementLocator);
            var action = new Actions(this.Driver);
            action.MoveToElement(element, offsetX, offsetY)
                .ClickAndHold()
                .MoveByOffset(moveByOffsetX, moveByOffsetY)
                .Release()
                .Perform();
        }

        public void ScrollIntoView(string resourceKey, params object[] formatArgs)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            this.ScrollIntoView(elementLocator);
        }

        public void ScrollIntoView(ElementLocator elementLocator)
        {
            var element = this.GetElement(elementLocator);
            this.Get<WindowPage>().ExecuteScript("arguments[0].scrollIntoView(true);", element);
        }

        public void MouseHover(string resourceKey, params object[] formatArgs)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            this.MouseHover(elementLocator);
        }

        public void MouseHover(ElementLocator elementLocator)
        {
            var element = this.GetElement(elementLocator);
            this.MouseHover(element);
        }

        public void MouseHover(IWebElement element)
        {
            var action = new Actions(this.Driver);
            action.MoveToElement(element).Perform();
        }

        public IWebElement FindElementByXPath(string resourceKey, params object[] formatArgs)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            var element = this.Driver.FindElement(By.XPath(elementLocator.Value));
            return element;
        }

        public IList<IWebElement> FindElementsByXPath(string resourceKey, params object[] formatArgs)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            var elements = this.Driver.FindElements(By.XPath(elementLocator.Value));
            return elements;
        }

        public IWebElement FindElementById(string resourceKey, params object[] formatArgs)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            var element = this.Driver.FindElement(By.Id(elementLocator.Value));
            return element;
        }

        public IList<IWebElement> FindElementsById(string resourceKey, params object[] formatArgs)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            var elements = this.Driver.FindElements(By.Id(elementLocator.Value));
            return elements;
        }

        public IWebElement FindElementByCss(string resourceKey, params object[] formatArgs)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            var element = this.Driver.FindElement(By.CssSelector(elementLocator.Value));
            return element;
        }

        public IList<IWebElement> FindElementsByCss(string resourceKey, params object[] formatArgs)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            var elements = this.Driver.FindElements(By.CssSelector(elementLocator.Value));
            return elements;
        }

        public List<string> GetListElementsText(string resourceKey, params object[] formatArgs)
        {
            var resultText = new List<string>();
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            var elementList = this.Driver.GetElements(elementLocator);
            foreach (var element in elementList)
            {
                resultText.Add(element.Text);
            }

            return resultText;
        }

        public string GetReadOnlyElementText(string resourceKey)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey);
            var element = this.GetElement(elementLocator);
            var elementText = element?.GetAttribute("value");
            return elementText;
        }

        public string GetReadOnlyElementText(string resourceKey, params object[] formatArgs)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            var element = this.Driver.GetElement(elementLocator, BaseConfiguration.MediumTimeout);
            var elementText = element?.GetAttribute("value");
            return elementText;
        }

        public ElementPage OpenHomePage()
        {
            var url = BaseConfiguration.GetUrlValue;
            this.Driver.NavigateTo(new Uri(url));
            Logger.Info(CultureInfo.CurrentCulture, "Opening page {0}", url);
            Driver.Manage().Window.Maximize();
            return this;
        }

        public ElementPage OpenHomePageAndMeasureTime()
        {
            var url = BaseConfiguration.GetUrlValue;
            this.DriverContext.NavigateToAndMeasureTime(new Uri(url), true);
            Logger.Info(CultureInfo.CurrentCulture, "Opening page {0}", url);
            return this;
        }

        public ElementPage OpenHomePageWithUserCredentials()
        {
            var url = BaseConfiguration.GetUrlValueWithUserCredentials;
            this.Driver.NavigateTo(new Uri(url));
            Logger.Info(CultureInfo.CurrentCulture, "Opening page {0}", url);
            return this;
        }

        public ElementPage SendEnterKey(string resourceKey, params object[] formatArgs)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            this.Driver.GetElement(locator, BaseConfiguration.MediumTimeout).SendKeys(Keys.Enter);
            return this;
        }

        public ElementPage SendDownKeys(string resourceKey)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey);
            this.GetElement(locator).SendKeys(Keys.Down);
            this.GetElement(locator).SendKeys(Keys.Enter);
            this.GetElement(locator).SendKeys(Keys.Return);
            return this;
        }

        public string GetPlaceHolderText(string resourceKey)
        {
            var elementLocator = this.DriverContext.GetElementLocator(resourceKey);
            var element = this.GetElement(elementLocator);
            var elementText = element?.GetAttribute("placeholder");
            return elementText;
        }

        public string GetElementCountOnPage(string resourceKey)
        {
            var footerRow = this.Get<ElementPage>().GetListElements(resourceKey);
            var allObject = footerRow[0].Text.Split(' ');
            var totalElementCount = allObject[4];
            return totalElementCount;
        }

        public void ClickTab(string resourceKey, string tabToClick)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey);
            var elements = this.Driver.GetElements(locator);
            foreach (var element in elements)
            {
                if (element.Text.Equals(tabToClick, StringComparison.Ordinal))
                {
                    this.ClientClick(element);
                }
            }
        }

        public void ClickButtonByText(string text)
        {
            this.ClickElementByText(text, ElementTypes.Button);
        }

        public void ClickLabelByText(string text)
        {
            this.ClickElementByText(text, ElementTypes.Label);
        }

        public void ClickSubmitByText(string text)
        {
            this.ClickElementByText(text, ElementTypes.Input);
        }

        public void Click(string resourceKey, params object[] formatArgs)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            this.Click(locator);
        }

        public void Click(ElementLocator locator, bool byText = false)
        {
            var element = byText ? this.Driver.GetElements(locator).FirstOrDefault(x => x.Enabled && x.Displayed) : this.GetElement(locator);
            var nonClickable = NonClickableElements.Any(element.TagName.EqualsIgnoreCase);
            this.WaitUntilElementToBeClickable(element);
            if (nonClickable)
            {
                element.Click();
            }
            else
            {
                this.ClientClick(element);
            }
        }

        public void ClientClick(IWebElement element, bool measurePerf = false, [CallerMemberName] string member = "")
        {
            if (measurePerf)
            {
                this.ClientClickAndMeasure(element, member: member);
            }
            else
            {
                element.ToWrappedElement().JavaScriptClick();
            }

            this.ElementClientClicked?.Invoke(null, new WebElementEventArgs(this.Driver, element));
        }

        public void ClientClick(ElementLocator locator, bool measurePerf = false)
        {
            var element = this.GetElement(locator);
            this.ClientClick(element, measurePerf);
        }

        public void ClientClick(string resourceKey, bool measurePerf = false)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey);
            this.ClientClick(locator, measurePerf);
        }

        public void ClientClick(string resourceKey, params object[] formatArgs)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            this.ClientClick(locator, false);
        }

        public void ClickMenu(string resourceKey)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey);
            var menuItem = this.GetElement(locator);
            this.ClientClick(menuItem, true);
        }

        public IWebElement GetFirstElementFromList(string resourceKey)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey);
            var elements = this.Driver.GetElements(locator);
            return elements.FirstOrDefault();
        }

        public void ClickOnFirstElementFromList(string resourceKey)
        {
            var element = this.GetFirstElementFromList(resourceKey);
            this.ClientClick(element);
        }

        public string GetText(string resourceKey, string menu)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey, menu);
            return this.GetText(locator);
        }

        public string GetText(ElementLocator locator)
        {
            var element = this.GetElement(locator);
            return element.Text;
        }

        public void ClickElementByText(string text, string type)
        {
            var locator = this.DriverContext.GetElementLocator(type, text, text.ToPascalCase(), string.Empty);
            this.Click(locator, true);
        }

        public void HoverElement(string resourceKey, params object[] formatArgs)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            this.HoverElement(locator);
        }

        public void HoverElement(ElementLocator locator)
        {
            var allElements = this.Driver.GetElements(locator);
            foreach (var element in allElements)
            {
                if (element.Enabled && element.Displayed)
                {
                    this.MouseHover(element);
                    break;
                }
            }
        }

        public bool IsActive(string resoureKey, params object[] formatArgs)
        {
            return this.GetAttributeValue(resoureKey, "class", formatArgs).Contains("active");
        }

        public string CreateLocalizedId(bool isLocalized = false, params string[] args)
        {
            return (isLocalized ? "localized_" : string.Empty) + string.Join("_", args);
        }

        public void WaitUntilPageLoad(double timeout = BrowserOptions.DefaultTimeout)
        {
            this.Driver.WaitUntilJavaScriptReady(timeout);
        }

        public bool WaitUntil(Func<bool> func, double timeout = BrowserOptions.DefaultTimeout)
        {
            return this.DriverContext.Driver.WaitUntil(timeout, x => func());
        }

        public IWebElement WaitUntilElementIsVisible(string resourceKey, double timeout = BrowserOptions.DefaultTimeout, params object[] formatArgs)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            return this.WaitUntilElementIsVisible(locator, timeout);
        }

        public IWebElement WaitUntilElementIsVisible(ElementLocator locator, double timeout = BrowserOptions.DefaultTimeout)
        {
            return this.DriverContext.Driver.WaitUntil(timeout, SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(locator.ToBy()));
        }

        public bool WaitUntilInvisibilityOfElementLocated(string resourceKey, double timeout = BrowserOptions.DefaultTimeout, params object[] formatArgs)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            return this.WaitUntilInvisibilityOfElementLocated(locator, timeout);
        }

        public bool WaitUntilInvisibilityOfElementLocated(ElementLocator locator, double timeout = BrowserOptions.DefaultTimeout)
        {
            return this.DriverContext.Driver.WaitUntil(timeout, SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(locator.ToBy()));
        }

        public IWebElement WaitUntilElementExists(string resourceKey, double timeout = BrowserOptions.DefaultTimeout, params object[] formatArgs)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            return this.WaitUntilElementExists(locator, timeout);
        }

        public IWebElement WaitUntilElementExists(ElementLocator locator, double timeout = BrowserOptions.DefaultTimeout)
        {
            return this.DriverContext.Driver.WaitUntil(timeout, SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(locator.ToBy()));
        }

        public bool WaitUntilElementInvisible(ElementLocator locator, string text, double timeout = BrowserOptions.DefaultTimeout)
        {
            var wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(timeout));
            return wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementWithText(locator.ToBy(), text));
        }

        public void SelectItemAtIndex(IWebElement list, int index)
        {
            for (var i = 0; i <= index; i++)
            {
                list.SendKeys(Keys.Down);
            }

            list.SendKeys(Keys.Enter);
        }

        public void SelectItemAtIndex(ElementLocator locator, int index)
        {
            var list = this.Driver.GetElement(locator);
            for (var i = 0; i <= index; i++)
            {
                list.SendKeys(Keys.Down);
            }

            list.SendKeys(Keys.Enter);
        }

        public ReadOnlyCollection<IWebElement> WaitUntilVisibilityOfAllElementsLocatedBy(string resourceKey, double timeout = BrowserOptions.DefaultTimeout, params object[] formatArgs)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            return this.WaitUntilVisibilityOfAllElementsLocatedBy(locator, timeout);
        }

        public ReadOnlyCollection<IWebElement> WaitUntilVisibilityOfAllElementsLocatedBy(ElementLocator locator, double timeout = BrowserOptions.DefaultTimeout)
        {
            return this.DriverContext.Driver.WaitUntil(timeout, SeleniumExtras.WaitHelpers.ExpectedConditions.VisibilityOfAllElementsLocatedBy(locator.ToBy()));
        }

        public bool WaitUntilTextToBePresentInElement(IWebElement webElement, string text, double timeout = BrowserOptions.DefaultTimeout)
        {
            return this.DriverContext.Driver.WaitUntil(timeout, SeleniumExtras.WaitHelpers.ExpectedConditions.TextToBePresentInElement(webElement, text));
        }

        public IWebElement WaitUntilElementToBeClickable(string resourceKey, double timeout = BrowserOptions.DefaultTimeout, params object[] formatArgs)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            return this.DriverContext.Driver.WaitUntil(timeout, SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(locator.ToBy()));
        }

        public IWebElement WaitUntilElementToBeClickable(IWebElement element, double timeout = BrowserOptions.DefaultTimeout)
        {
            return this.DriverContext.Driver.WaitUntil(timeout, SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(element));
        }

        public bool WaitUntilTextToBePresentInElement(string resourceKey, string text, double timeout = BrowserOptions.DefaultTimeout, params object[] formatArgs)
        {
            var locator = this.DriverContext.GetElementLocator(resourceKey, formatArgs);
            return this.DriverContext.Driver.WaitUntil(timeout, SeleniumExtras.WaitHelpers.ExpectedConditions.TextToBePresentInElementLocated(locator.ToBy(), text));
        }

        public bool WaitUntilUrlContains(string fraction, double timeout = BrowserOptions.DefaultTimeout)
        {
            return this.DriverContext.Driver.WaitUntil(timeout, SeleniumExtras.WaitHelpers.ExpectedConditions.UrlContains(fraction));
        }

        public void MoveToElement(string resourceKey, params object[] args)
        {
            var element = this.Get<ElementPage>().GetElement(resourceKey, args);
            this.MoveToElement(element);
        }

        public void DoubleClick(IWebElement element, bool measurePerf = false, [CallerMemberName] string member = "")
        {
            if (measurePerf)
            {
                this.DoubleClickAndMeasure(element, member: member);
            }
            else
            {
                var action = new Actions(this.Driver).DoubleClick(element);
                action.Build().Perform();
            }
        }

        private void DoubleClickAndMeasure(IWebElement webElement, bool waitForAjax = true, [CallerMemberName] string member = "")
        {
            if (webElement != null)
            {
                this.DriverContext.PerformanceMeasures.StartMeasure();
                var id = webElement.Text ?? string.Empty;
                var type = webElement.TagName ?? string.Empty;
                var action = new Actions(this.Driver).DoubleClick(webElement);
                action.Build().Perform();
                if (waitForAjax)
                {
                    webElement.ToWrappedDriver()?.WaitForAjax();
                }

                this.DriverContext.MeasureClientPerf(id, type);
                this.DriverContext.PerformanceMeasures.StopMeasure(member);
            }
        }

        private void ClientClickAndMeasure(IWebElement webElement, bool waitForAjax = true, [CallerMemberName] string member = "")
        {
            if (webElement != null)
            {
                this.DriverContext.PerformanceMeasures.StartMeasure();
                var id = webElement.Text ?? string.Empty;
                var type = webElement.TagName ?? string.Empty;
                webElement.ToWrappedElement().JavaScriptClick();
                if (waitForAjax)
                {
                    webElement.ToWrappedDriver()?.WaitUntilJavaScriptReady(); // .WaitUntilJQueryReady(); // .WaitUntilJavaScriptReady();
                }

                this.DriverContext.MeasureClientPerf(id, type);
                this.DriverContext.PerformanceMeasures.StopMeasure(member);
            }
        }

        private void SetClipboardText(string value)
        {
            var thread = new Thread(() => System.Windows.Forms.Clipboard.SetText(value));
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();
        }

        private void MoveToElement(IWebElement element)
        {
            this.Driver.Actions().MoveToElement(element).Build().Perform();
        }
    }
}