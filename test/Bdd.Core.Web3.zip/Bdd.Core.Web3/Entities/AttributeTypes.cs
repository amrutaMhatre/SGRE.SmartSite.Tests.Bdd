﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AttributeTypes.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.Web.Entities
{
    /// <summary>
    /// Actions
    /// </summary>
    public static class AttributeTypes
    {
        /// <summary>
        /// The identifier
        /// </summary>
        public const string Id = "id";

        /// <summary>
        /// The class
        /// </summary>
        public const string Class = "class";

        /// <summary>
        /// The automation identifier
        /// </summary>
        public const string AutomationId = "automationId";

        /// <summary>
        /// The inner text
        /// </summary>
        public const string InnerText = "innertext";

        /// <summary>
        /// The link text
        /// </summary>
        public const string LinkText = "linktext";

        /// <summary>
        /// The partial link text
        /// </summary>
        public const string PartialLinkText = "partiallinktext";

        /// <summary>
        /// The name
        /// </summary>
        public const string Name = "name";

        /// <summary>
        /// The tag name
        /// </summary>
        public const string TagName = "tagname";

        /// <summary>
        /// The x path
        /// </summary>
        public const string XPath = "xpath";

        /// <summary>
        /// The CSS
        /// </summary>
        public const string Css = "css";

        /// <summary>
        /// The URL
        /// </summary>
        public const string Sql = "sql";
    }
}