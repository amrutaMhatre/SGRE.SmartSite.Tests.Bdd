﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BrowserOptions.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.Web.Entities
{
    public static class BrowserOptions
    {
        /// <summary>
        /// The start full screen
        /// </summary>
        public const string StartFullScreen = "--start-fullscreen";

        /// <summary>
        /// The headless
        /// </summary>
        public const string Headless = "--headless";

        /// <summary>
        /// The no sandbox
        /// </summary>
        public const string NoSandbox = "no-sandbox";

        /// <summary>
        /// The incognito
        /// </summary>
        public const string Incognito = "incognito";

        /// <summary>
        /// The default timeout in seconds
        /// </summary>
        public const double DefaultTimeout = 15;
    }
}