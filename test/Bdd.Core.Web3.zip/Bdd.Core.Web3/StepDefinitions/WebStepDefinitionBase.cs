﻿// <copyright file="WebStepDefinitionBase.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>

namespace Bdd.Core.Web.StepDefinitions
{
    using System;

    using Bdd.Core.StepDefinitions;
    using Bdd.Core.Web.Executors;

    using global::Bdd.Core.Web.Entities;
    using global::Bdd.Core.Web.Utils;

    using NUnit.Framework;

    public class WebStepDefinitionBase : StepDefinitionBase
    {
        public void ClickButtonByText(string text)
        {
            this.ClickElementByText(text, ElementTypes.Button);
        }

        public void ClickLabelByText(string text)
        {
            this.ClickElementByText(text, ElementTypes.Label);
        }

        public void ClickSubmitByText(string text)
        {
            this.ClickElementByText(text, ElementTypes.Input);
        }

        public void HasTitle(string title)
        {
            this.VerifyThat(() => Assert.IsTrue(this.Get<WindowPage>().HasPageTitle(title), $"Page Title Not as Expected {title}"));
            this.Get<ElementPage>().WaitUntilPageLoad();
        }

        protected virtual void ClickElementByText(string text, string type)
        {
            try
            {
                this.Get<ElementPage>().ClickElementByText(text, type);
            }
            catch (Exception ex)
            {
                Assert.Fail($"{text}: {ex.Message}");
            }
        }
    }
}