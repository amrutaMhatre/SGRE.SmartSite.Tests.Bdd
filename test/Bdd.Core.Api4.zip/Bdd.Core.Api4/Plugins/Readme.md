﻿### Bdd.Core.Generator.SpecFlowPlugin

#### WHY?
- Although multiple *Tests* are auto-generated for a ScenarioOutline (for every *Example*), only one TestCase is created in Azure DevOps for a ScenarioOutline. This is to avoid unnecessary redundancy
- Azure DevOps does not support linking multiple Tests with a TestCase - so when a TestCase is executed from the Test-Hub in Azure Devops (Test-Plan), only one Test gets executed (the one that is linked under 'Associated-Automation' for the TestCase)
- Since we need to run multiple Tests as part of the (ScenarioOutline) TestCase, the workaround is to created  a *Wrapper* Test that in turn calls / encapsulates the other (auto-generated) Tests related to the ScenarioOutline

#### WHAT?
- A *Wrapper* Test is (auto) generated as part of "Generate Feature-files" that in turn calls the other (auto-generated) Tests related to the ScenarioOutline decorated with [NUnit.Framework.CategoryAttribute("bddcore-wrapper")] attribute
- The name of this *Wrapper* Test matches with the Associated-Automation name for the TestCase in AzureDevOps
- The default auto-generated Tests for the ScenarioOutline are appended with [NUnit.Framework.CategoryAttribute("bddcore-ex")] attribute (`ex` prefix stands for exclude / example)
- The above *Categories* are provided for any *filter*ing that might be required when running the CI pipeline

#### HOW?
- There is a *Plugins* folder that's added to the Test project that contains the custom Bdd.Core SpecFlow plugin along with the necessary dependencies
- App.config is updated with `<plugins>` node under `<specFlow>` section with the necessary details to load the plugin
  ```xml
  <specFlow>
    ...
    <plugins>
        <add name="Bdd.Core.Generator" path=".\Plugins" type="Generator" />
    </plugins>
  </specFlow>
  ```
- Once the Plugin setup is in place, whenever .feature.cs is generated, it gets updated with the details provided in the **WHAT** section above.
