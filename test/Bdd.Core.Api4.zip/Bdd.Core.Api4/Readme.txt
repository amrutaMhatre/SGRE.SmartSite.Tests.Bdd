﻿BDD.CORE.API
------------

- Code files
	- `Core\DocUtils.cs`: Used for VSTS Sync / Documentation
		- In order to not trigger the VSTS-Sync tests as part of CI/CD inadvertently, the DocUtils class is marked with [Ignore("Manually triggered...")].
		- Comment out the attribute and pass `false` in the last parameter (demoMode) in `GenerateVstsTestCasesFromBddFeatures` Test/method
		- Uncomment the [Ignore] attribute once done
	- `Core\AppTestBase.cs`: Used for "Hooks"

- Configuration
	- `app.config`: Change values under `<vstsDocTarget>` node for VSTS-sync
	- Make sure the values of AssignedTo (in .config) / @owner tag (in .feature) are valid.
		- e.g.: The alias vamsitp(@microsoft.com) is different than vamsi.tp(@microsoft.com) - though both are valid aliases. VSTS only honors that one that was added to the account

- Main classes to use
    - `ApiStepDefinitionBase`: To add additional functionality, inherit this class and add/override methods
    - `ApiExecutor`: To add additional functionality, inherit this class and add/override methods

- Scenario specific Packages
    - `Bdd.Core.Web`: For Web Tests
    - `Bdd.Core.Api`: For Api Tests