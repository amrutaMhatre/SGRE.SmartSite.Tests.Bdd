﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ApiStepDefinitionBase.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.Api.StepDefinitions
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Net.Http;
    using System.Threading.Tasks;

    using Bdd.Core.Api.Entities;
    using Bdd.Core.Api.Executors;
    using Bdd.Core.StepDefinitions;

    using Flurl.Http.Content;

    using global::Bdd.Core.Entities.Tags;

    using TechTalk.SpecFlow;
    using System.Diagnostics.CodeAnalysis;

    [ExcludeFromCodeCoverage]
    [Binding]
    public class ApiStepDefinitionBase : StepDefinitionBase
    {
        protected bool IsPerf => bool.Parse(ConfigurationManager.AppSettings["EnablePerfTag"]) && this.ScenarioContext.ScenarioInfo.Tags.Contains(TypeTags.Perf);

        protected virtual ApiExecutor ApiExecutor
        {
            get
            {
                if (!this.FeatureContext.ContainsKey(nameof(Executors.ApiExecutor)))
                {
                   this.FeatureContext.Set(new ApiExecutor(), nameof(Executors.ApiExecutor));
                }

                return this.FeatureContext.Get<ApiExecutor>(nameof(Executors.ApiExecutor));
            }
        }

        public async Task<T> GetAsync<T>(string endpoint, Dictionary<string, object> additionalHeaders = null)
        {
            var operationId = Guid.NewGuid();
            Logger.Debug($"{nameof(operationId)} for '{endpoint}': {operationId}");
            var response = default(T);
            if (this.IsPerf)
            {
                //var result = await this.ApiExecutor.RunPerf(endpoint, this.UserDetails, operationId).ConfigureAwait(false);
                var result =  true;
                var perfResponse = new PagedResult<dynamic> { TotalResultCount = result ? 1 : 0 };
                Logger.Info(perfResponse);
            }
            else
            {
                response = await this.ApiExecutor.GetAsync<T>(endpoint, this.UserDetails, operationId, additionalHeaders).ConfigureAwait(false);
            }

            return response;
        }

        public async Task<bool> DeleteAsync(string endpoint, Dictionary<string, object> additionalHeaders = null)
        {
            var operationId = Guid.NewGuid();
            Logger.Debug($"{nameof(operationId)} for '{endpoint}': {operationId}");
            var result = await this.ApiExecutor.DeleteAsync(endpoint, this.UserDetails, operationId, additionalHeaders).ConfigureAwait(false);
            return result;
        }

        public async Task<HttpResponseMessage> DeleteWithResponseAsync(string endpoint, Dictionary<string, object> additionalHeaders = null)
        {
            var operationId = Guid.NewGuid();
            Logger.Debug($"{nameof(operationId)} for '{endpoint}': {operationId}");
            var result = await this.ApiExecutor.DeleteWithResponseAsync(endpoint, this.UserDetails, operationId, additionalHeaders).ConfigureAwait(false);
            return result;
        }

        public async Task<T> PostAsync<T>(string endpoint, object content, Dictionary<string, object> additionalHeaders = null)
        {
            var operationId = Guid.NewGuid();
            Logger.Debug($"{nameof(operationId)} for '{endpoint}': {operationId}");
            var result = await this.ApiExecutor.PostAsync<dynamic>(endpoint, content, this.UserDetails, operationId, additionalHeaders).ConfigureAwait(false);
            return result;
        }

        public async Task<HttpResponseMessage> PostWithResponseAsync(string endpoint, object content, Dictionary<string, object> additionalHeaders = null)
        {
            var operationId = Guid.NewGuid();
            Logger.Debug($"{nameof(operationId)} for '{endpoint}': {operationId}");
            var result = await this.ApiExecutor.PostWithResponseAsync(endpoint, content, this.UserDetails, operationId, additionalHeaders).ConfigureAwait(false);
            return result;
        }

        public async Task<T> PutAsync<T>(string endpoint, object content, Dictionary<string, object> additionalHeaders = null)
        {
            var operationId = Guid.NewGuid();
            Logger.Debug($"{nameof(operationId)} for '{endpoint}': {operationId}");
            var result = await this.ApiExecutor.PutAsync<dynamic>(endpoint, content, this.UserDetails, operationId, additionalHeaders).ConfigureAwait(false);
            return result;
        }

        public async Task<HttpResponseMessage> PutWithResponseAsync(string endpoint, object content, Dictionary<string, object> additionalHeaders = null)
        {
            var operationId = Guid.NewGuid();
            Logger.Debug($"{nameof(operationId)} for '{endpoint}': {operationId}");
            var result = await this.ApiExecutor.PutWithResponseAsync(endpoint, content, this.UserDetails, operationId, additionalHeaders).ConfigureAwait(false);
            return result;
        }

        public async Task<string> DownloadAsync(string endpoint, string localFolderPath, string localFileName = null)
        {
            var operationId = Guid.NewGuid();
            Logger.Debug($"{nameof(operationId)} for '{endpoint}': {operationId}");
            var result = await this.ApiExecutor.DownloadAsync(endpoint, localFolderPath, localFileName).ConfigureAwait(false);
            return result;
        }

        public async Task<HttpResponseMessage> PostMultipartAsync(string endpoint, Action<CapturedMultipartContent> buildContent, Dictionary<string, object> additionalHeaders = null)
        {
            var operationId = Guid.NewGuid();
            Logger.Debug($"{nameof(operationId)} for '{endpoint}': {operationId}");
            var result = await this.ApiExecutor.PostMultipartAsync(endpoint, buildContent, this.UserDetails, operationId, additionalHeaders).ConfigureAwait(false);
            return result;
        }
    }
}