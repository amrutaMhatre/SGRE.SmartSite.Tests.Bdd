﻿using Bdd.Core.Api.Executors;
using Bdd.Core.Entities;
using Bdd.Core.Web.Executors;
using Bdd.Core.Web.Utils;
using NUnit.Framework;
using Ocaramba;
using Ocaramba.Extensions;
using Ocaramba.Types;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SGRE.SmartSite.Tests.Bdd.Entities;
using SGRE.SmartSite.Tests.Bdd.StepDefinitions;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace SGRE.SmartSite.Tests.Bdd.PageObjects
{
    public class SiteSettingsPage : ElementPage
    {

        private readonly ElementLocator PageTitle = new ElementLocator(Locator.CssSelector, "[class='smart-breadcrumb']>a"),
            SiteSettingsTabs = new ElementLocator(Locator.CssSelector, "a[id^='uncontrolled-tab-example-tab']"),
            ProjectTab = new ElementLocator(Locator.CssSelector, "[id='uncontrolled-tab-example-tab-project']"),
            TurbineTab = new ElementLocator(Locator.CssSelector, "[id='uncontrolled-tab-example-tab-turbines']"),
            ResourcesTab = new ElementLocator(Locator.CssSelector, "[id='uncontrolled-tab-example-tab-resources']"),
            PageHeading = new ElementLocator(Locator.CssSelector, "label[class='active-bread']"),
            ProjectNameTxtField = new ElementLocator(Locator.CssSelector, "input[name='projectName']"),
            ProjecIdTxtField = new ElementLocator(Locator.CssSelector, "input[name='projectCode']"),
            RegionDropDown = new ElementLocator(Locator.CssSelector, "select[name='regionId']"),
            CountryDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'Country')]/../select"),
            LatTxtField = new ElementLocator(Locator.CssSelector, "input[name='latitude']"),
            LongTxtField = new ElementLocator(Locator.CssSelector, "input[name='longitude']"),
            AreaTxtField = new ElementLocator(Locator.CssSelector, "input[name='area']"),
            WTGCountTxtField = new ElementLocator(Locator.CssSelector, "input[name='numberOfWTG']"),
            DescriptionTxtField = new ElementLocator(Locator.CssSelector, "[name='projectDesc']"),
            FileUploadField = new ElementLocator(Locator.CssSelector, "[class='input-group has-validation']>input[placeholder='Upload file']"),
            PMDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'Project Manager')]/../select"),
            CLDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'Commissioning Lead')]/../select"),
            SMDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'Site Manager')]/../select"),
            ProjectCreationField = new ElementLocator(Locator.XPath, "//label[contains(text(),'Project Creation')]/../div/input"),
            PublicationDateField = new ElementLocator(Locator.XPath, "//label[contains(text(),'Publication Date')]/../div/input"),
            SWIRealDateField = new ElementLocator(Locator.XPath, "//label[contains(text(),'SWI Real Date')]/../div/input"),
            SWIContractedDateField = new ElementLocator(Locator.XPath, "//label[contains(text(),'SWI Contracted Date')]/../div/input"),
            ProjectStartDateField = new ElementLocator(Locator.XPath, "//label[contains(text(),'Projected Start Date')]/../div/input"),
            ProjectEndDateField = new ElementLocator(Locator.XPath, "//label[contains(text(),'Projected End Date')]/../div/input"),
            SaveButton = new ElementLocator(Locator.CssSelector, "div[id='uncontrolled-tab-example-tabpane-project'] button[class$='btn btn-primary']"),
            CreateProjectSuccessMsg = new ElementLocator(Locator.CssSelector, "button[class='btn btn-primary']"),
            UpdateProjectSuccessMsg = new ElementLocator(Locator.CssSelector, "button[class='btn btn-primary']"),
            ProjectStatusTextField = new ElementLocator(Locator.XPath, "//label[contains(text(),'Status')]/../div/input"),
            ProjectStatusDropDown = new ElementLocator(Locator.CssSelector, "select[name = 'projectStatusId']"),
            SitePanel = new ElementLocator(Locator.XPath, "//div[contains(text(),'Site')]/..//div[2]/form"),
            ResponsibilitiesPanel = new ElementLocator(Locator.XPath, "//div[contains(text(),'Responsibilities')]/..//div[2]/form"),
            StatusPanel = new ElementLocator(Locator.XPath, "//div[contains(text(),'Status')]/../div[4]/form"),
            ProjectStartDateMonth = new ElementLocator(Locator.XPath, "//label[contains(text(),'Projected Start Date')]/../div/div[@class='nice-dates-popover -open']//span[@class='nice-dates-navigation_current']"),

            ProjectSDates = new ElementLocator(Locator.XPath, "//label[contains(text(),'Projected Start Date')]/../div/div[@class='nice-dates-popover -open']//span[@class='nice-dates-day']"),
            ProjectEDates = new ElementLocator(Locator.XPath, "//label[contains(text(),'Projected End Date')]/../div/div[@class='nice-dates-popover -open']//span[@class='nice-dates-day']"),
            SWIRDates = new ElementLocator(Locator.XPath, "//label[contains(text(),'SWI Contracted Date')]/../div/div[@class='nice-dates-popover -open']//span[@class='nice-dates-day']"),
            //Turbine tab
            AddNewConfig = new ElementLocator(Locator.CssSelector, "[id='configs-tab-add']"),
            ConfigTab = new ElementLocator(Locator.CssSelector, "[id^='configs-tab-']"),
            SaveConfigButton = new ElementLocator(Locator.XPath, "//div[starts-with(@aria-labelledby, 'configs-tab')]//button[contains(text(),'Save')]"),
            //update css
            DeleteConfigButton = new ElementLocator(Locator.CssSelector, "[id^='configs-tab-']"),
            TowerSelectionPannel = new ElementLocator(Locator.XPath, "//div[contains(@id, 'configs-tabpane')]//label[contains(text(),'WTGs')]/../div/input"),
            ConfigurationName = new ElementLocator(Locator.XPath, "//label[contains(text(),'Config Name')]/../div/input"),
            WTGPlatformDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'WTG Platform')]/../select"),
            TurbineConfigTowers = new ElementLocator(Locator.CssSelector, "div[class^='modal-dialog'] [class='tower-wrapper']>label"),
            TowerSelectionPopUpCloseButton = new ElementLocator(Locator.CssSelector, "div[class^='modal-dialog'] [class='modal-header']>button"),
            InstallationStrategyDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'Installation Strategy')]/../select"),
            TowerHeightDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'Tower Height')]/../input"),
            TowerSectionsDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'Tower Sections')]/../select"),
            AssemblyPhasesDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'Assembly Phases')]/../select"),
            NazeleTypeDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'Nacelle Type')]/../select"),
            BladeTypeDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'Blade Type')]/../select"),
            DTTypeDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'Drive Train Type')]/../select"),
            ElevatorTypeDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'Elevator Type')]/../select"),
            TightingProcessDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'Tighting Process Type')]/../select"),
            GearboxDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'Gearbox Type')]/../select"),
            WTGFeaturesDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'WTG Features')]/../select"),
            MandatoryFieldText = new ElementLocator(Locator.CssSelector, "div[aria-labelledby^='configs-tab'] div[class='invalid-feedback']"),
            UploadRoadMapButton = new ElementLocator(Locator.XPath, "//button[contains(text(),'Upload Roadmap')]"),
            TemplateTab = new ElementLocator(Locator.CssSelector, "a[id='turbine-submenu-tab-template']"),
            LeadTimeTab = new ElementLocator(Locator.CssSelector, "a[id='turbine-submenu-tab-leadtime']"),
            UnboxingPhase = new ElementLocator(Locator.XPath, "//div[contains(text(),'Phases')]/../div[2]//label[contains(text(),'Unboxing')]"),
            PreparationPhase = new ElementLocator(Locator.XPath, "//div[contains(text(),'Phases')]/../div[2]//label[contains(text(),'Preparation')]"),
            PreAssemblyPhase = new ElementLocator(Locator.XPath, "//div[contains(text(),'Phases')]/../div[2]//label[contains(text(),'Pre Assembly')]"),
            MainErectionPhase = new ElementLocator(Locator.XPath, "//div[contains(text(),'Phases')]/../div[2]//label[contains(text(),'Main Erection')]"),
            MechanicalPhase = new ElementLocator(Locator.XPath, "//div[contains(text(),'Phases')]/../div[2]//label[contains(text(),'Mechanical Completion')]"),
            ElectricalPhase = new ElementLocator(Locator.XPath, "//div[contains(text(),'Phases')]/../div[2]//label[contains(text(),'Electrical Completion')]"),
            Commissioning = new ElementLocator(Locator.XPath, "//div[contains(text(),'Phases')]/../div[2]//label[contains(text(),'Commissioning')]"),
            DeleteConfigDialogBox = new ElementLocator(Locator.XPath, "//div[@role='dialog']//div[@class='modal-title h4']/span"),
            DeleteConfigDialogBoxNoButton = new ElementLocator(Locator.XPath, "//div[@role='dialog']//div[@class='modal-footer']/button"),
            ProjectMenu = new ElementLocator(Locator.XPath, "//ul[@class='SidebarList']//div[contains(text(), 'Projects')]/../.."),
            RoadMapUploadButton = new ElementLocator(Locator.XPath, "//div[@class='mx-2 row add-view text-right']/button[contains(text(), 'Upload Roadmap')]"),
            RoadMapFileSelectionPopUp = new ElementLocator(Locator.CssSelector, "div[class='fade modal show'] div[class='modal-content']"),
            RoadMapFileSelectionPanel = new ElementLocator(Locator.CssSelector, "div[class='fade modal show'] div[class='modal-content'] section input"),
            RoadMapFileSelectionPopUpButtons = new ElementLocator(Locator.CssSelector, "div[class='fade modal show'] div[class='modal-footer'] button"),
            UploadedFileName = new ElementLocator(Locator.CssSelector, "section[class='upload-container'] [class='sub-header']"),
            FileUploadErrorMsg = new ElementLocator(Locator.CssSelector, "section[class='upload-container'] [class='col-12 errors']");

        
        public SiteSettingsPage(DriverContext driverContext) : base(driverContext)
        {}
   
        //validate page title with project name
        public SiteSettingsPage ValidatePageTitle(string selectedProjectName)
        {
            this.WaitUntilTextToBePresentInElement(this.GetElement(PageTitle), selectedProjectName, 15);
            //get the page title of Site Settings page
            string currentProjectName = this.GetElements(PageTitle, 12).ElementAt(0).Text;
                Console.WriteLine("Page title of Site settings page: " + currentProjectName);
                //compare selected and current project names
                Assert.AreEqual(selectedProjectName, currentProjectName, "Site settings page title proejct name is incorrect");
                return this;
        }

        //validate page title with page title
        public SiteSettingsPage ValidatePageTitleProjectName()
        {
            //get the project name page title of Site Settings page
            string currentProjectName = this.GetElement(PageTitle).Text;
            Console.WriteLine("Page title of Site settings page: " + currentProjectName);
            //compare selected and current project names
            Assert.AreEqual("New Project", currentProjectName, "Site settings proejct name is incorrect");
            return this;
        }
        public SiteSettingsPage ValidateSiteSettingsTabs(List<string> listOfTabs)
        {
            Thread.Sleep(9000);
            List<string> actualTabList = new List<string> { };
            IList<IWebElement> tablist = this.GetElements(SiteSettingsTabs, 20);
            foreach (IWebElement element in tablist)
            {
                actualTabList.Add(element.Text);
            }

            if (listOfTabs.Count != actualTabList.Count)
            {
                Assert.Fail("All three tabs are not display on site settings page");
                return this;
            }
            for (int i = 0; i < listOfTabs.Count; i++)
            {
                Assert.That(listOfTabs[i].Equals(actualTabList[i]), "site settings page tab sequence is incorrect");
            }
            return this;

        }
        public SiteSettingsPage OpenProjectDetailsTab()
        {
            this.GetElement(ProjectTab).Click();
            //validate project is default open tab
            string defaultSelection = this.GetElement(ProjectTab).GetAttribute("aria-selected");
            Assert.True(defaultSelection.Equals("true"), "Project is the default open tab for site settings page");
            return this;
        }

        //Project tab view validation
        public SiteSettingsPage ValidateProjectTab()
        {
            this.GetElement(ProjectTab);
            //validate project is default open tab
            string defaultSelection = this.GetElement(ProjectTab).GetAttribute("aria-selected");
            Assert.True(defaultSelection.Equals("true"), "Project is the default open tab for site settings page");
            return this;
        }

        //Turbine tab view validation
        public SiteSettingsPage ValidateTurbineTab()
        {
            this.WaitUntilElementToBeClickable(this.GetElement(TurbineTab), 10);
            this.Click(TurbineTab);
            //validate turbine tab is open
            string selectionStatus = this.GetElement(TurbineTab).GetAttribute("aria-selected");
            Assert.True(selectionStatus.Equals("true"), "Turbine tab is open for site settings page");
            return this;
        }

        public SiteSettingsPage ValidateoResourcesTab()
        {
            //validate Resources tab
            this.GetElement(ResourcesTab);
            this.Click(ResourcesTab);
            string selectionValue = this.GetElement(ResourcesTab).GetAttribute("aria-selected");
            Assert.True(selectionValue.Equals("true"), "Resources tab get opened");
            return this;
        }

        public SiteSettingsPage ValidatePageTitle()
        {
            Thread.Sleep(9000);
            //get the page title of Site Settings page
            string currentProjectName = this.GetElement(PageHeading).Text;
            Console.WriteLine("Page title of Site settings page: " + currentProjectName);
            //compare selected and current project names
            Assert.AreEqual("Site Settings", currentProjectName, "Site settings page title proejct name not matching with selected project name from home page");
            return this;
        }

        public SiteSettingsPage ValidateSiteSectionFields()
        {
            this.GetElement(ProjectNameTxtField);
            this.GetElement(ProjecIdTxtField);
            this.GetElement(RegionDropDown);
            this.GetElement(CountryDropDown);
            this.GetElement(LatTxtField);
            this.GetElement(LongTxtField);
            this.GetElement(AreaTxtField);
            this.GetElement(WTGCountTxtField);
            this.GetElement(DescriptionTxtField);

            Assert.That(this.GetElement(ProjectNameTxtField).Text, Is.Empty);
            Assert.That(this.GetElement(ProjecIdTxtField).Text, Is.Empty);
            Assert.That(this.GetElement(LatTxtField).Text, Is.Empty);
            Assert.That(this.GetElement(LongTxtField).Text, Is.Empty);
            Assert.That(this.GetElement(AreaTxtField).Text, Is.Empty);
            Assert.That(this.GetElement(WTGCountTxtField).Text, Is.Empty);
            Assert.That(this.GetElement(DescriptionTxtField).Text, Is.Empty);
            //Verify region drop down is empty field
            SelectElement regionSelection = new SelectElement(this.GetElement(RegionDropDown));
            IList<IWebElement> regionlist = regionSelection.Options;
            Assert.IsTrue(regionlist.Count > 0);
            for (int i = 0; i < 1; i++)
            {
                string regionValue = regionlist.ElementAt(i).Text;
                Assert.That(regionValue, Is.Empty);
            }
            //Verify country drop down is empty field
            SelectElement countrySelection = new SelectElement(this.GetElement(CountryDropDown));
            IList<IWebElement> countrylist = countrySelection.Options;
            Assert.IsTrue(countrylist.Count > 0);
            for (int i = 0; i < 1; i++)
            {
                string countryValue = countrylist.ElementAt(i).Text;
                Assert.That(countryValue, Is.Empty);
            }
            return this;
        }

        public SiteSettingsPage ValidateDataEnteryForSite(string projectname, string id, string lat, string longitude, string area, string wtg, string description)
        {
            this.GetElement(ProjectNameTxtField).SendKeys(projectname);
            this.GetElement(ProjecIdTxtField).SendKeys(id);
            this.GetElement(LatTxtField).SendKeys(lat);
            this.GetElement(LongTxtField).SendKeys(longitude);
            this.GetElement(AreaTxtField).SendKeys(area);
            this.GetElement(WTGCountTxtField).SendKeys(wtg);
            this.GetElement(DescriptionTxtField).SendKeys(description);
            return this;
        }

       //Select value from PM drop down
        public SiteSettingsPage ValidateSelectPMDropDown()
        {
            this.GetElement(PMDropDown);
            var isEnabled = this.GetElement(PMDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement pmSelection = new SelectElement(this.GetElement(PMDropDown));
                IList<IWebElement> pmlist = pmSelection.Options;
                Assert.IsTrue(pmlist.Count > 0);
                for (int i = 1; i < 2; i++)
                {
                    Assert.That(pmlist.ElementAt(i).Text, Is.Not.Empty);
                    pmlist.ElementAt(i).Click();
                    Thread.Sleep(2000);
                }
            }
            else
            {
                Assert.True(this.GetElement(PMDropDown).Enabled, "User is able to select PM from drop down list");
            }
            return this;
        }

        //Select value from CL drop down
        public SiteSettingsPage ValidateSelectCLDropDown()
        {
            this.GetElement(CLDropDown);
            var isEnabled = this.GetElement(CLDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement clSelection = new SelectElement(this.GetElement(CLDropDown));
                IList<IWebElement> cllist = clSelection.Options;
                Assert.IsTrue(cllist.Count > 0);
                for (int i = 1; i < 2; i++)
                {
                    Assert.That(cllist.ElementAt(i).Text, Is.Not.Empty);
                    cllist.ElementAt(i).Click();
                    Thread.Sleep(2000);
                }
            }
            else
            {
                Assert.True(this.GetElement(CLDropDown).Enabled, "User is able to select CL from drop down list");
            }
            return this;
        }

        //Select value from SM drop down
        public SiteSettingsPage ValidateSelectSMDropDown()
        {
            this.GetElement(SMDropDown);
            var isEnabled = this.GetElement(SMDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement smSelection = new SelectElement(this.GetElement(SMDropDown));
                IList<IWebElement> smlist = smSelection.Options;
                Assert.IsTrue(smlist.Count > 0);
                for (int i = 1; i < 2; i++)
                {
                    Assert.That(smlist.ElementAt(i).Text, Is.Not.Empty);
                    smlist.ElementAt(i).Click();
                    Thread.Sleep(2000);
                }
            }
            else
            {
                Assert.True(this.GetElement(SMDropDown).Enabled, "User is able to select SM from drop down list");
            }
            return this;
        }


        public SiteSettingsPage ValidateCountryDropdown()
        {
            SelectElement rigion = new SelectElement(this.GetElement(RegionDropDown));
            IList<IWebElement> rigionList = rigion.Options;
            Assert.IsTrue(rigionList.Count > 0);
            string selectedRegion = "";
            for (int i = 0; i < 1; i++)
            {
                selectedRegion = rigionList.ElementAt(i).Text;
                Thread.Sleep(2000);
            }

            if(selectedRegion.Equals(""))
            {              
                SelectElement country = new SelectElement(this.GetElement(CountryDropDown));
                IList<IWebElement> countryList = country.Options;
                Assert.IsTrue(countryList.Count == 1);
                string countryValue = countryList.ElementAt(0).Text;
                Assert.That(countryValue, Is.Empty);
            }
            return this;
        }

        public SiteSettingsPage ValidateSelectRegion(string region)
        {
            var isEnabled = this.GetElement(RegionDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement regionField = new SelectElement(this.GetElement(RegionDropDown));
                foreach (IWebElement element in regionField.Options)
                {
                    if (element.Text.Contains(region))
                    {
                        element.Click();
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(RegionDropDown).Enabled, "User is able to select Region");
            }
            return this;
        }

        public SiteSettingsPage ValidateSelectCountry(string country)
        {
            var isEnabled = this.GetElement(CountryDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement countryField = new SelectElement(this.GetElement(CountryDropDown));
                foreach (IWebElement element in countryField.Options)
                {
                    if (element.Text.Contains(country))
                    {
                        element.Click();
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(CountryDropDown).Enabled, "User is able to select Country");
            }
            return this;
        }


        public SiteSettingsPage ValidateSaveButton()
        {
            string saveButtonText = this.GetElement(SaveButton).Text;
            Console.WriteLine("Save button text: " + saveButtonText);
            //compare selected and current project names
            Assert.AreEqual("Save", saveButtonText, "Save button label text is incorrect");
            this.Click(SaveButton);
            return this;
        }

        public SiteSettingsPage ValidateCreateProjectSuccessMsg()
        {
           string successmsg = this.GetElement(CreateProjectSuccessMsg).Text;
           Console.WriteLine("Project Creattion success msg: " + successmsg);
           Assert.That(successmsg, Is.Not.Empty);         
           return this;         
        }

        //All fields are clear and empty
        public SiteSettingsPage ValidateStatusSectionFields()
        {
            this.GetElement(ProjectCreationField);
            this.GetElement(PublicationDateField);
            this.GetElement(SWIContractedDateField);
            this.GetElement(SWIRealDateField);
            this.GetElement(ProjectStartDateField);
            this.GetElement(ProjectEndDateField);

            Assert.That(this.GetElement(ProjectCreationField).Text, Is.Empty);
            Assert.That(this.GetElement(PublicationDateField).Text, Is.Empty);
            Assert.That(this.GetElement(SWIContractedDateField).Text, Is.Empty);
            Assert.That(this.GetElement(SWIRealDateField).Text, Is.Empty);
            Assert.That(this.GetElement(ProjectStartDateField).Text, Is.Empty);
            Assert.That(this.GetElement(ProjectEndDateField).Text, Is.Empty);
            return this;

        }

        //Project status validation
        public SiteSettingsPage ValidateProjectStatus(string projectstatus)
        {
            this.GetElement(ProjectStatusTextField);
            string selectionValue = this.GetElement(ProjectStatusTextField).GetAttribute("value");
            Assert.True(selectionValue.Equals(projectstatus), "Project status is "+ selectionValue);
            Assert.True(this.GetElement(ProjectStatusTextField).GetAttribute("readonly").Equals("true"), "Project status field is non editable");
            return this;
        }

        //Project status validation
        public SiteSettingsPage ChangeProjectStatus(string projectstatus)
        {
            this.GetElement(ProjectTab);
            //validate project is default open tab
            string defaultSelection = this.GetElement(ProjectTab).GetAttribute("aria-selected");
            if (defaultSelection.Equals("true"))
            {
                Console.WriteLine("Project details tab is already open");
            }
            else
            {
                OpenProjectDetailsTab();
            }

            var isEnabled = this.GetElement(ProjectStatusDropDown).Enabled;
            if (isEnabled)
            {
                Console.WriteLine("Current Project status: " + this.GetElement(ProjectStatusDropDown).Text);
                SelectElement statusField = new SelectElement(this.GetElement(ProjectStatusDropDown));
                foreach (IWebElement element in statusField.Options)
                {
                    if (element.Text.Contains(projectstatus))
                    {
                        element.Click();
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(ProjectStatusDropDown).Enabled, "User is able to select Project Status");
            }           
            return this;
        }


        public SiteSettingsPage ValidateNonEditableFieldsOfStatusInProjectCreationMode()
        {
            Assert.True(this.GetElement(ProjectCreationField).GetAttribute("readonly").Equals("true"), "Project creation field is readonly");
            Assert.False(this.GetElement(ProjectCreationField).GetAttribute("class").Contains("calendar input"), "Project creation field is non editable");
            Assert.False(this.GetElement(PublicationDateField).GetAttribute("class").Contains("calendar input"), "Project publication field is non editable");
            Assert.True(this.GetElement(SWIRealDateField).GetAttribute("readonly").Equals("true"), "SWI Real Date field is readonly");
            Assert.False(this.GetElement(SWIRealDateField).GetAttribute("class").Contains("calendar input"), "SWI Real field is non editable");
            return this;

        }


        public SiteSettingsPage ValidateNonEditableFieldsOfStatusInProjectEditMode()
        {
            Assert.True(this.GetElement(ProjectCreationField).GetAttribute("readonly").Equals("true"), "Project creation field is non editable");
            Assert.True(this.GetElement(PublicationDateField).GetAttribute("readonly").Equals("true"), "Project publication field is non editable");
            Assert.True(this.GetElement(SWIRealDateField).GetAttribute("readonly").Equals("true"), "SWI Real Date field is non editable");
            Assert.True(this.GetElement(SWIContractedDateField).GetAttribute("readonly").Equals("true"), "SWI Contracted Date field is non editable");
            Assert.True(this.GetElement(ProjectStartDateField).GetAttribute("readonly").Equals("true"), "Projected Start Date field is non editable");
            Assert.True(this.GetElement(ProjectEndDateField).GetAttribute("readonly").Equals("true"), "Projected End Date field is non editable");
            return this;
        }

        public SiteSettingsPage ValidateDataEnteryForStatus(string projectedstartdate, string projectedenddate, string swicontracteddate)
        {
            //projectedstartdate
            Thread.Sleep(5000);
            string projectedStartDate_Month = projectedstartdate.Split('-')[1];
            string projectedStartDate_Year = projectedstartdate.Split('-')[2];
            string projectedStartDate_Date = projectedstartdate.Split('-')[0];
            Thread.Sleep(2000);
            this.Driver.JavaScripts().ExecuteScript("arguments[0].scrollIntoView(true);", this.GetElement(ProjectStartDateField));
            this.Click(ProjectStartDateField);

            CultureInfo ci = new CultureInfo("en-US");
            var year = DateTime.Now.Year;
            var Date = DateTime.Now.ToString("dd", ci);           
            var month = DateTime.Now.ToString("MMMM", ci);
            
            IList<IWebElement> datelist1 = this.GetElements(ProjectSDates, 90);
            
            foreach (IWebElement date in datelist1)
            {
                if (date.Text == projectedStartDate_Date)
                {
                    date.Click();
                    break;
                }
            }

            //projectedenddate
            string projectEndDate_Month = projectedenddate.Split('-')[1];
            string projectEndDate_Year = projectedenddate.Split('-')[2];
            string projectEndDate_Date = projectedenddate.Split('-')[0];
            
            this.Click(ProjectEndDateField);
            IList<IWebElement> datelist2 = this.GetElements(ProjectEDates, 90);
            foreach (IWebElement date in datelist2)
            {
                if (date.Text == projectEndDate_Date)
                {
                    date.Click();
                    break;
                }
            }

            //swicontracteddate
            string swicontracteddate_Month = swicontracteddate.Split('-')[1];
            string swicontracteddate_Year = swicontracteddate.Split('-')[2];
            string swicontracteddate_Date = swicontracteddate.Split('-')[0];

            this.Click(ProjectEndDateField);
            IList<IWebElement> datelist3 = this.GetElements(SWIRDates, 90);
            foreach (IWebElement date in datelist3)
            {
                if (date.Text == swicontracteddate_Date)
                {
                    date.Click();
                    break;
                }
            }
            return this;
        }

        public SiteSettingsPage ValidateProjectPublicationDate()
        {
            string projectStatus = this.GetElement(ProjectStatusDropDown).Text;
            if (projectStatus.Contains("Published"))
            {
                Assert.That(PublicationDateField, Is.Not.Empty);
            }
            else
            {
                Assert.That(PublicationDateField, Is.Empty);
            }            
            return this;
        }


        public SiteSettingsPage ValidateSiteSettingsSections()
        {
            this.GetElement(SitePanel);
            this.GetElement(ResponsibilitiesPanel);
            this.GetElement(StatusPanel);
            this.GetElement(SaveButton);
            return this;
        }

        public SiteSettingsPage ValidateResponsibilitiesSectionFields()
        {
            this.GetElement(PMDropDown);
            this.GetElement(CLDropDown);
            this.GetElement(SMDropDown);
           
            //Verify PM drop down is empty field
            SelectElement pmSelection = new SelectElement(this.GetElement(PMDropDown));
            Console.WriteLine("try " + this.GetElement(PMDropDown).Text);
            IList<IWebElement> pmlist = pmSelection.Options;
            Assert.IsTrue(pmlist.Count > 0);
            for (int i = 0; i < 1; i++)
            {
                string pmValue = pmlist.ElementAt(i).Text;
                Assert.That(pmValue, Is.Empty, "PM drop down by default empty field");
            }

            //Verify Commissioning Lead drop down is empty field
            SelectElement cmSelection = new SelectElement(this.GetElement(CLDropDown));
            IList<IWebElement> cmlist = cmSelection.Options;
            Assert.IsTrue(cmlist.Count > 0);
            for (int i = 0; i < 1; i++)
            {
                string cmValue = cmlist.ElementAt(i).Text;
                Assert.That(cmValue, Is.Empty, "CM drop down by default empty field");
            }

            //Verify Site Manager drop down is empty field
            SelectElement smSelection = new SelectElement(this.GetElement(SMDropDown));
            IList<IWebElement> smlist = smSelection.Options;
            Assert.IsTrue(smlist.Count > 0);
            for (int i = 0; i < 1; i++)
            {
                string smValue = smlist.ElementAt(i).Text;
                Assert.That(smValue, Is.Empty, "SM drop down by default empty field");
            }
            return this;
        }

        public SiteSettingsPage ValidateSiteSectionFieldsInEditMode()
        {
            string projectStatus = this.GetElement(ProjectStatusDropDown).Text;
            if (projectStatus != "Draft")
            {
                this.GetElement(ProjectNameTxtField);
                this.GetElement(ProjecIdTxtField);
                this.GetElement(RegionDropDown);
                this.GetElement(CountryDropDown);
                this.GetElement(LatTxtField);
                this.GetElement(LongTxtField);
                this.GetElement(AreaTxtField);
                this.GetElement(WTGCountTxtField);
                this.GetElement(DescriptionTxtField);

                Assert.True(this.GetElement(ProjectNameTxtField).Enabled, "Project name is editable in edit mode");
                Assert.True(this.GetElement(ProjecIdTxtField).Enabled, "Project id is editable in edit mode");
                Assert.False(this.GetElement(LatTxtField).Enabled, "Location Lat is non editable in edit mode");
                Assert.False(this.GetElement(LongTxtField).Enabled, "Location long is non editable in edit mode");
                Assert.False(this.GetElement(AreaTxtField).Enabled, "Area is non editable in edit mode");
                Assert.False(this.GetElement(WTGCountTxtField).Enabled, "WTG is non editable in edit mode");
                Assert.False(this.GetElement(DescriptionTxtField).Enabled, "Description is non editable in edit mode");
                //check and update for region and country
                Assert.True(this.GetElement(RegionDropDown).GetAttribute("readonly").Equals("true"), "Project creation field is non editable");
                Assert.True(this.GetElement(CountryDropDown).GetAttribute("readonly").Equals("true"), "Project creation field is non editable");
            }
            else
            {
                Assert.False(projectStatus.Equals("Draft"),"Draft status is display in edit project mode");
            }        
            return this;
        }

        public SiteSettingsPage EditProjectName(string projectname)
        {
            this.GetElement(ProjectNameTxtField);
            Random randomNumber = new Random();
            var randomNumberString = randomNumber.Next(0, 9999).ToString("0000");
            this.GetElement(ProjectNameTxtField).SendKeys(projectname+randomNumberString);
            return this;
        }

        public SiteSettingsPage EditProjectId()
        {
            this.GetElement(ProjecIdTxtField);
            Random randomNumber = new Random();
            var randomNumberString = randomNumber.Next(0, 9999).ToString("0000");
            this.GetElement(ProjecIdTxtField).SendKeys(randomNumberString);
            return this;
        }

        public SiteSettingsPage ValidateResponsibilitiesSectionFieldsInEditMode()
        {
            string projectStatus = this.GetElement(ProjectStatusDropDown).Text;
            if (projectStatus != "Draft")
            {
                Assert.True(this.GetElement(PMDropDown).GetAttribute("readonly").Equals("true"), "PM drop down field is non editable");
                Assert.True(this.GetElement(CLDropDown).GetAttribute("readonly").Equals("true"), "CL drop down field is non editable");
                Assert.True(this.GetElement(SMDropDown).GetAttribute("readonly").Equals("true"), "SM drop down field is non editable");
            }else
            {
                Assert.False(projectStatus.Equals("Draft"), "Draft status is display in edit project mode");
            }
            return this;
        }

        public SiteSettingsPage ValidateUpdateProjectSuccessMsg()
        {
            string successmsg = this.GetElement(UpdateProjectSuccessMsg).Text;
            Console.WriteLine("Project Creattion success msg: " + successmsg);
            Assert.That(successmsg, Is.Not.Empty);
            return this;
        }
        
        //Validate default configuration
        public SiteSettingsPage ValidateDefaultConfigTabIsPresent()
        {
            IList<IWebElement> tablist = this.GetElements(ConfigTab, 20);
            Assert.True(tablist.Count > 0, "Default 1 configuration is present");
            for(int i=0; i<1; i++)
            {
                tablist.ElementAt(i).Click();
            }
            return this;
        }

        //Validate turbine section for each config
        public SiteSettingsPage ValidateSetupSection(int configtab)
        {
            IList<IWebElement> configNameList = this.GetElements(ConfigurationName, 20);
            IList<IWebElement> mappingList = this.GetElements(TowerSelectionPannel, 20);        
            IList<IWebElement> wtgModelList = this.GetElements(WTGPlatformDropDown, 20);
            IList<IWebElement> installationStrategyList = this.GetElements(InstallationStrategyDropDown, 20);
            IList<IWebElement> towerHeightList = this.GetElements(TowerHeightDropDown, 20);
            IList<IWebElement> towerSectionsList = this.GetElements(TowerSectionsDropDown, 20);
            IList<IWebElement> assemblyPhasesList = this.GetElements(AssemblyPhasesDropDown, 20);
            IList<IWebElement> nacelleTypeList = this.GetElements(NazeleTypeDropDown, 20);
            IList<IWebElement> bladeTypeList = this.GetElements(BladeTypeDropDown, 20);
            IList<IWebElement> dTTypeList = this.GetElements(DTTypeDropDown, 20);
            IList<IWebElement> elevatorTypeList = this.GetElements(ElevatorTypeDropDown, 20);
            IList<IWebElement> tightingProcessList = this.GetElements(TightingProcessDropDown, 20);
            IList<IWebElement> gearboxList = this.GetElements(GearboxDropDown, 20);
            IList<IWebElement> wTGFeaturesList = this.GetElements(WTGFeaturesDropDown, 20);

            Assert.True(mappingList.Count == configtab, "Mapping drop down is present for configuration " + configtab);
            Assert.True(configNameList.Count == configtab, "config Name is present for configuration " + configtab);
            Assert.True(wtgModelList.Count == configtab, "Wtg Model drop down is present for configuration " + configtab);
            Assert.True(installationStrategyList.Count == configtab, "Installation Strategy drop down is present for configuration " + configtab);
            Assert.True(towerHeightList.Count == configtab, "Tower Height drop down is present for configuration " + configtab);
            Assert.True(towerSectionsList.Count == configtab, "Tower Sections drop down is present for configuration " + configtab);
            Assert.True(assemblyPhasesList.Count == configtab, "Assembly Phases drop down is present for configuration " + configtab);
            Assert.True(bladeTypeList.Count == configtab, "Blade Type Type drop down is present for configuration " + configtab);
            Assert.True(elevatorTypeList.Count == configtab, "Elevator Type drop down is present for configuration " + configtab);
            Assert.True(tightingProcessList.Count == configtab, "Tighting Process drop down is present for configuration " + configtab);
            Assert.True(gearboxList.Count == configtab, "Gearbox drop down is present for configuration " + configtab);
            Assert.True(wTGFeaturesList.Count == configtab, "WTG Features drop down is present for configuration " + configtab);
            return this;
        }

        //Validate mandatory fields for turbine setup section
        public SiteSettingsPage ValidateMandatorySetupSection()
        {
            IList<IWebElement> mandatoryFieldList = this.GetElements(MandatoryFieldText, 20);
            List<string> listOfTabs = new List<string>
            { "Config Name", "WTGs", "WTG Platform", "Installation Strategy", "Nazzle Type", "Elevator Type", "Tower Height", "Tower Section", "Assembly Phases", "Blade Type", "Tower Tightening Process Type", "DT Type", "Gearbox Type"};
            for(int i=0; i< listOfTabs.Count; i++)
            {
                string text = mandatoryFieldList.ElementAt(i).Text;
                Console.WriteLine("text" + text);
                Assert.True(text.Contains(listOfTabs.ElementAt(i)), "Expected mandatory text msg is present for index" + i);             
            }        
            return this;
        }

        //Validate tower selection count available per config
        public SiteSettingsPage ValidateTowersOfMappingPanel(int configtab)
        {
            //open project details tab
            OpenProjectDetailsTab();
            string WTGCount = this.GetElement(WTGCountTxtField).GetAttribute("value");
            Console.WriteLine("WTGCount " + WTGCount);
            int wtgCount = int.Parse(WTGCount);
            //Open turbine tab
            ValidateTurbineTab();
            for (int i = configtab - 1; i < configtab; i++)
            {
                IList<IWebElement> mappingPanelList = this.GetElements(TowerSelectionPannel, 20);
                mappingPanelList.ElementAt(i).Click();
                IList<IWebElement> towerList = this.GetElements(TurbineConfigTowers, 20);
                Assert.True(towerList.Count == wtgCount, "No of towers available for selection for configuration " + configtab + "is same as WTGCount of prject details tab");
                this.GetElement(TowerSelectionPopUpCloseButton).Click();
            }
            return this;
        }


        //Add new configuration
        public SiteSettingsPage AddNewConfiguration()
        {
            IList<IWebElement> previousTablist = this.GetElements(ConfigTab, 20);
            //validate Add new config tab
            this.GetElement(AddNewConfig);
            this.Click(AddNewConfig);
            IList<IWebElement> currentTablist = this.GetElements(ConfigTab, 20);
            Assert.True(previousTablist.Count < currentTablist.Count, "New Configuration tab is added");
            return this;
        }

        //Validate RoadMap section for each config
        public SiteSettingsPage ValidateRoadMapSection(int configtab)
        {
            this.GetElement(TemplateTab);
            //validate Template tab is open
            string selectionStatus = this.GetElement(TemplateTab).GetAttribute("aria-selected");
            Assert.True(selectionStatus.Equals("true"), "Template tab is open for Roadmap section");
            this.GetElement(LeadTimeTab);
            return this;
        }

        public SiteSettingsPage ValidateSaveConfigButtonIsPresent()
        {
            this.GetElement(SaveConfigButton);
            return this;
        }

        public SiteSettingsPage ClickOnSaveConfigButton(int configtab)
        {
            IWebElement saveButton = this.GetElements(SaveConfigButton, 20).ElementAt(configtab-1);
            this.GetElement(SaveConfigButton).Click();
            return this;
        }

        //Validate delete config button
        public SiteSettingsPage ValidateDeleteConfigButtonIsPresent()
        {
            this.GetElement(DeleteConfigButton);
            return this;
        }

        //Validate turbine section: setup for each config
        public SiteSettingsPage ValidateDefaultViewOfSetupSection(int configtab)
        {
            for (int i = configtab - 1; i < configtab; i++)
            {
                IList<IWebElement> mappingList = this.GetElements(TowerSelectionPannel, 20);
                IList<IWebElement> wtgModelList = this.GetElements(WTGPlatformDropDown, 20);
                IList<IWebElement> installationStrategyList = this.GetElements(InstallationStrategyDropDown, 20);
                IList<IWebElement> towerHeightList = this.GetElements(TowerHeightDropDown, 20);
                IList<IWebElement> towerSectionsList = this.GetElements(TowerSectionsDropDown, 20);
                IList<IWebElement> assemblyPhasesList = this.GetElements(AssemblyPhasesDropDown, 20);
                IList<IWebElement> nacelleTypeList = this.GetElements(NazeleTypeDropDown, 20);
                IList<IWebElement> bladeTypeList = this.GetElements(BladeTypeDropDown, 20);
                IList<IWebElement> dTTypeList = this.GetElements(DTTypeDropDown, 20);
                IList<IWebElement> elevatorTypeList = this.GetElements(ElevatorTypeDropDown, 20);
                IList<IWebElement> tightingProcessList = this.GetElements(TightingProcessDropDown, 20);
                IList<IWebElement> gearboxList = this.GetElements(GearboxDropDown, 20);
                IList<IWebElement> wTGFeaturesList = this.GetElements(WTGFeaturesDropDown, 20);
                IList<IWebElement> uploadRoadMapButtonList = this.GetElements(UploadRoadMapButton, 20);

                SelectElement wtgModelSelection = new SelectElement(wtgModelList.ElementAt(i));
                IList<IWebElement> wtgModellist = wtgModelSelection.Options;
                Assert.IsTrue(wtgModellist.Count > 0);
                for (int j = 0; j < 1; j++)
                {
                    Assert.That(wtgModellist.ElementAt(i).Text, Is.Empty);
                }
            }
            //add for rest of all drop downs           
            return this;
        }

        public SiteSettingsPage ValidateDeleteConfigButtonIsNotPresent()
        {
            this.Driver.JavaScripts().ExecuteScript("arguments[0].click();", this.GetElement(ConfigTab).FindElement(By.TagName("span")));
            this.WaitUntilElementIsVisible(DeleteConfigDialogBox, 10);
            string popUpTitle = this.GetElement(DeleteConfigDialogBox).Text;
            Assert.That(popUpTitle.Contains("Reset Config"), "Default configuration has reset config option");
            this.GetElement(DeleteConfigDialogBoxNoButton).Click();
            return this;
        }

        public SiteSettingsPage ValidateConfigurationName(string configname, int configtab)
        {
            IWebElement configNameField = this.GetElements(ConfigurationName, 20).ElementAt(configtab - 1);
            Assert.That(configNameField.Text.Contains(configname), "Configuration name is correct for config " + configtab);
            return this;
        }

        public SiteSettingsPage EnterConfigurationName(string configname, int configtab)
        {
            IWebElement configNameField = this.GetElements(ConfigurationName, 20).ElementAt(configtab - 1);
            configNameField.SendKeys(configname);        
            return this;
        }

        public SiteSettingsPage ValidatedatePicker()
        {
            this.Click(ProjectStartDateField);
            return this;

        }

        public SiteSettingsPage ValidateTowerSelection(string towerrange, int configtab)
        {
            IList<IWebElement> tablist = this.GetElements(ConfigTab, 20);
            Assert.True(tablist.Count > 0, "Configurations are present");

            for (int i = 0; i < tablist.Count-1; i++)
            {
                //Veifiy that tab is selected
                if(i == (configtab - 1))
                {
                    if (tablist.ElementAt(i).GetAttribute("aria-selected").Equals("true"))
                    {
                        Console.WriteLine("Configuration tab "+ configtab + " is selected");
                    }
                    else
                    {
                        tablist.ElementAt(i).Click();
                        Assert.That(tablist.ElementAt(i).GetAttribute("aria-selected").Equals("true"), "Configuration tab is selected");
                    }
                    IList<IWebElement> mappingList = this.GetElements(TowerSelectionPannel, 20);
                    mappingList.ElementAt(i).Click();
                    
                    //this.GetElement(TowerSelectionPanel);
                    int towerSelection_Start = int.Parse(towerrange.Split('-')[0]);
                    int towerSelection_End = int.Parse(towerrange.Split('-')[1]);

                    //get the list of towers
                    IList<IWebElement> towerList = this.GetElements(TurbineConfigTowers, 20);
                    for (int j = towerSelection_Start - 1; j < towerSelection_End; j++)
                    {
                        Thread.Sleep(1000);
                        this.Driver.JavaScripts().ExecuteScript("arguments[0].click();", towerList.ElementAt(j));         
                    }

                    this.GetElement(TowerSelectionPopUpCloseButton).Click();                    
                }               
            }       
            return this;
        }

        public SiteSettingsPage ValidateTowerSelectionRestrictions(string towerrange, int configtab)
        {
            IList<IWebElement> tablist = this.GetElements(ConfigTab, 20);
            Assert.True(tablist.Count > 0, "Configurations are present");

            for (int i = 0; i < tablist.Count-1; i++)
            {
                //Veifiy that tab is selected
                if(i == (configtab - 1))
                {
                    if (tablist.ElementAt(i).GetAttribute("aria-selected").Equals("true"))
                    {
                        Console.WriteLine("Configuration tab "+ configtab + " is selected");
                    }
                    else
                    {
                        tablist.ElementAt(i).Click();
                        Assert.That(tablist.ElementAt(i).GetAttribute("aria-selected").Equals("true"), "Configuration tab is selected");
                    }
                    IList<IWebElement> mappingList = this.GetElements(TowerSelectionPannel, 20);
                    mappingList.ElementAt(i).Click();
                    
                    //this.GetElement(TowerSelectionPanel);
                    int towerSelection_Start = int.Parse(towerrange.Split('-')[0]);
                    int towerSelection_End = int.Parse(towerrange.Split('-')[1]);

                    //get the list of towers
                    IList<IWebElement> towerList = this.GetElements(TurbineConfigTowers, 20);
                    for (int j = towerSelection_Start - 1; j < towerSelection_End; j++)
                    {
                        Assert.That(towerList.ElementAt(j).GetAttribute("class").Contains("disabled-tower"), "Tower selection is disabled");                               
                    }

                    this.GetElement(TowerSelectionPopUpCloseButton).Click();                    
                }               
            }       
            return this;
        }

        //total count of selected configuration is same as no of wtg's declared in project details tab
        public SiteSettingsPage GetCountOfSelectedTowers()
        {
            int count = 0;
            IList<IWebElement> tablist = this.GetElements(ConfigTab, 20);
            Assert.True(tablist.Count > 0, "Configurations are present");

            for (int i = 0; i < tablist.Count - 1; i++)
            {
                //Veifiy that tab is selected
                if (tablist.ElementAt(i).GetAttribute("aria-selected").Equals("true"))
                {
                    Console.WriteLine("Configuration tab " + i + " is selected");
                }
                else
                {
                    tablist.ElementAt(i).Click();
                    Assert.That(tablist.ElementAt(i).GetAttribute("aria-selected").Equals("true"), "Configuration tab is selected");
                }
                IList<IWebElement> mappingList = this.GetElements(TowerSelectionPannel, 20);
                mappingList.ElementAt(i).Click();
                
                //get the list of towers
                IList<IWebElement> towerList = this.GetElements(TurbineConfigTowers, 20);
                for (int j = 0; j < towerList.Count; j++)
                {
                    if (towerList.ElementAt(j).GetAttribute("class").Contains("selected-tower"))
                    {
                        count++;
                    }                   
                }

                this.GetElement(TowerSelectionPopUpCloseButton).Click();               
            }
            //open project details tab
            OpenProjectDetailsTab();
            string WTGCount = this.GetElement(WTGCountTxtField).GetAttribute("value");
            Console.WriteLine("WTGCount " + WTGCount);
            int wtgCount = int.Parse(WTGCount);
            Assert.True(count == wtgCount, "Total no of towers selected for project configuration/s are same as WTGCount of prject details tab");

            return this;
        }

        /// <summary>
        /// Select values for WTGPlatform of turbine tab : setup section
        /// </summary>
        /// <param name="optionvalue"></param>
        /// <param name="configtab"></param>
        /// <returns></returns>
        public SiteSettingsPage ValidateWTGPlatformSelectionForSetupSection(int optionvalue, int configtab)
        {
            var isEnabled = false;
   
            //WTG Platform
            this.GetElement(WTGPlatformDropDown);
            isEnabled = this.GetElement(WTGPlatformDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement wTGPlatformSelection = new SelectElement(this.GetElements(WTGPlatformDropDown).ElementAt(configtab-1));
                IList<IWebElement> wtglist = wTGPlatformSelection.Options;
                Assert.IsTrue(wtglist.Count > 0);
                for (int i = 1; i < wtglist.Count; i++)
                {
                    if(i == optionvalue)
                    {
                        Assert.That(wtglist.ElementAt(i).Text, Is.Not.Empty);
                        wtglist.ElementAt(i).Click();
                        //Thread.Sleep(2000);
                        break;
                    }                   
                }
            }
            else
            {
                Assert.True(this.GetElement(WTGPlatformDropDown).Enabled, "User is able to select value for WTGPlatform");
            }
            return this;
        }

        //Select values for Installation Strategy of turbine tab : setup section
        public SiteSettingsPage ValidateInstallationStrategySelectionForSetupSection(int optionvalue, int configtab)
        {
            var isEnabled = false;
            this.GetElement(InstallationStrategyDropDown);
            isEnabled = this.GetElement(InstallationStrategyDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement installationStrategySelection = new SelectElement(this.GetElements(InstallationStrategyDropDown).ElementAt(configtab - 1));
                IList<IWebElement> installationStrategylist = installationStrategySelection.Options;
                Assert.IsTrue(installationStrategylist.Count > 0);
                for (int i = 1; i < installationStrategylist.Count; i++)
                {
                    if (i == optionvalue)
                    {
                        Assert.That(installationStrategylist.ElementAt(i).Text, Is.Not.Empty);
                        installationStrategylist.ElementAt(i).Click();
                        Thread.Sleep(2000);
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(InstallationStrategyDropDown).Enabled, "User is able to select value for Installation Strategy");
            }
            return this;
        }

        //Select values for Nazele Type of turbine tab : setup section
        public SiteSettingsPage ValidateNazeleTypeSelectionForSetupSection(int optionvalue, int configtab)
        {
            var isEnabled = false;
            this.GetElement(NazeleTypeDropDown);
            isEnabled = this.GetElement(NazeleTypeDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement nazeleTypeSelection = new SelectElement(this.GetElements(NazeleTypeDropDown).ElementAt(configtab - 1));
                IList<IWebElement> nazelelist = nazeleTypeSelection.Options;
                Assert.IsTrue(nazelelist.Count > 0);
                for (int i = 1; i < nazelelist.Count; i++)
                {
                    if (i == optionvalue)
                    {
                        Assert.That(nazelelist.ElementAt(i).Text, Is.Not.Empty);
                        nazelelist.ElementAt(i).Click();
                        Thread.Sleep(2000);
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(NazeleTypeDropDown).Enabled, "User is able to select value for Nacelle Type DropDown");
            }
            return this;
        }

        //Select values for Elevator type of turbine tab : setup section
        public SiteSettingsPage ValidateElevatorTypeSelectionForSetupSection(int optionvalue, int configtab)
        {
            var isEnabled = false;
            this.GetElement(ElevatorTypeDropDown);
            isEnabled = this.GetElement(ElevatorTypeDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement elevatorTypeSelection = new SelectElement(this.GetElements(ElevatorTypeDropDown).ElementAt(configtab - 1));
                IList<IWebElement> elevatorlist = elevatorTypeSelection.Options;
                Assert.IsTrue(elevatorlist.Count > 0);
                for (int i = 1; i < elevatorlist.Count; i++)
                {
                    if (i == optionvalue)
                    {
                        Assert.That(elevatorlist.ElementAt(i).Text, Is.Not.Empty);
                        elevatorlist.ElementAt(i).Click();
                        Thread.Sleep(2000);
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(ElevatorTypeDropDown).Enabled, "User is able to select value for Elevator type DropDown");
            }
            return this;
        }

        //Select values for Tower height of turbine tab : setup section
        public SiteSettingsPage ValidateTowerHeightSelectionForSetupSection(int optionvalue, int configtab)
        {
            var isEnabled = false;
            this.GetElement(TowerHeightDropDown);
            isEnabled = this.GetElement(TowerHeightDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement towerHeightSelection = new SelectElement(this.GetElements(TowerHeightDropDown).ElementAt(configtab - 1));
                IList<IWebElement> towerHeightlist = towerHeightSelection.Options;
                Assert.IsTrue(towerHeightlist.Count > 0);
                for (int i = 1; i < towerHeightlist.Count; i++)
                {
                    if (i == optionvalue)
                    {
                        Assert.That(towerHeightlist.ElementAt(i).Text, Is.Not.Empty);
                        towerHeightlist.ElementAt(i).Click();
                        Thread.Sleep(2000);
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(TowerHeightDropDown).Enabled, "User is able to select value for Tower Height DropDown");
            }
            return this;
        }

        //Select values for Tower sections of turbine tab : setup section
        public SiteSettingsPage ValidateTowerSectionsSelectionForSetupSection(int optionvalue, int configtab)
        {
            var isEnabled = false;
            this.GetElement(TowerSectionsDropDown);
            isEnabled = this.GetElement(TowerSectionsDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement towerSectionsSelection = new SelectElement(this.GetElements(TowerSectionsDropDown).ElementAt(configtab - 1));
                IList<IWebElement> towerSectionslist = towerSectionsSelection.Options;
                Assert.IsTrue(towerSectionslist.Count > 0);
                for (int i = 1; i < towerSectionslist.Count; i++)
                {
                    if (i == optionvalue)
                    {
                        Assert.That(towerSectionslist.ElementAt(i).Text, Is.Not.Empty);
                        towerSectionslist.ElementAt(i).Click();
                        Thread.Sleep(2000);
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(TowerSectionsDropDown).Enabled, "User is able to select value for Tower Sections DropDown");
            }
            return this;
        }

        //Select values for Assembly phases of turbine tab : setup section
        public SiteSettingsPage ValidateAssemblyPhasesSelectionForSetupSection(int optionvalue, int configtab)
        {
            var isEnabled = false;
            this.GetElement(AssemblyPhasesDropDown);
            isEnabled = this.GetElement(AssemblyPhasesDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement towerSectionsSelection = new SelectElement(this.GetElements(AssemblyPhasesDropDown).ElementAt(configtab - 1));
                IList<IWebElement> towerSectionslist = towerSectionsSelection.Options;
                Assert.IsTrue(towerSectionslist.Count > 0);
                for (int i = 1; i < towerSectionslist.Count; i++)
                {
                    if (i == optionvalue)
                    {
                        Assert.That(towerSectionslist.ElementAt(i).Text, Is.Not.Empty);
                        towerSectionslist.ElementAt(i).Click();
                        Thread.Sleep(2000);
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(AssemblyPhasesDropDown).Enabled, "User is able to select value for Assembly Phases DropDown");
            }
            return this;
        }

        //Select values for Blade Type of turbine tab : setup section
        public SiteSettingsPage ValidateBladeTypeSelectionForSetupSection(int optionvalue, int configtab)
        {
            var isEnabled = false;
            this.GetElement(BladeTypeDropDown);
            isEnabled = this.GetElement(BladeTypeDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement bladeTypeSelection = new SelectElement(this.GetElements(BladeTypeDropDown).ElementAt(configtab - 1));
                IList<IWebElement> bladelist = bladeTypeSelection.Options;
                Assert.IsTrue(bladelist.Count > 0);
                for (int i = 1; i < bladelist.Count; i++)
                {
                    if (i == optionvalue)
                    {
                        Assert.That(bladelist.ElementAt(i).Text, Is.Not.Empty);
                        bladelist.ElementAt(i).Click();
                        Thread.Sleep(2000);
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(BladeTypeDropDown).Enabled, "User is able to select value for Blade Type DropDown");
            }
            return this;
        }

        //Select values for Tower tightening process of turbine tab : setup section
        public SiteSettingsPage ValidateTowerTighteningSelectionForSetupSection(int optionvalue, int configtab)
        {
            var isEnabled = false;
            this.GetElement(TightingProcessDropDown);
            isEnabled = this.GetElement(TightingProcessDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement tightingProcessSelection = new SelectElement(this.GetElements(TightingProcessDropDown).ElementAt(configtab - 1));
                IList<IWebElement> tightingProcesslist = tightingProcessSelection.Options;
                Assert.IsTrue(tightingProcesslist.Count > 0);
                for (int i = 1; i < tightingProcesslist.Count; i++)
                {
                    if (i == optionvalue)
                    {
                        Assert.That(tightingProcesslist.ElementAt(i).Text, Is.Not.Empty);
                        tightingProcesslist.ElementAt(i).Click();
                        Thread.Sleep(2000);
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(TightingProcessDropDown).Enabled, "User is able to select value for Tower Tightening DropDown");
            }
            return this;
        }

        //Select values for DT Type of turbine tab : setup section
        public SiteSettingsPage ValidateDTTypeSelectionForSetupSection(int optionvalue, int configtab)
        {
            var isEnabled = false;
            this.GetElement(DTTypeDropDown);
            isEnabled = this.GetElement(DTTypeDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement dTTypeSelection = new SelectElement(this.GetElements(DTTypeDropDown).ElementAt(configtab - 1));
                IList<IWebElement> dTTlist = dTTypeSelection.Options;
                Assert.IsTrue(dTTlist.Count > 0);
                for (int i = 1; i < dTTlist.Count; i++)
                {
                    if (i == optionvalue)
                    {
                        Assert.That(dTTlist.ElementAt(i).Text, Is.Not.Empty);
                        dTTlist.ElementAt(i).Click();
                        Thread.Sleep(2000);
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(DTTypeDropDown).Enabled, "User is able to select value for DT Type DropDown");
            }
            return this;
        }

        //Select values for Gearbox Type of turbine tab : setup section
        public SiteSettingsPage ValidateGearboxTypeSelectionForSetupSection(int optionvalue, int configtab)
        {
            var isEnabled = false;
            this.GetElement(GearboxDropDown);
            isEnabled = this.GetElement(GearboxDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement gearboxSelection = new SelectElement(this.GetElements(GearboxDropDown).ElementAt(configtab - 1));
                IList<IWebElement> gearboxlist = gearboxSelection.Options;
                Assert.IsTrue(gearboxlist.Count > 0);
                for (int i = 1; i < gearboxlist.Count; i++)
                {
                    if (i == optionvalue)
                    {
                        Assert.That(gearboxlist.ElementAt(i).Text, Is.Not.Empty);
                        gearboxlist.ElementAt(i).Click();
                        Thread.Sleep(2000);
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(GearboxDropDown).Enabled, "User is able to select value for Gearbox DropDown");
            }
            return this;
        }

        //Select values for Additional WTG Features of turbine tab : setup section
        public SiteSettingsPage ValidateAdditionalWTGFeaturesSelectionForSetupSection(int optionvalue, int configtab)
        {
            var isEnabled = false;
            this.GetElement(WTGFeaturesDropDown);
            isEnabled = this.GetElement(WTGFeaturesDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement wTGFeaturesSelection = new SelectElement(this.GetElements(WTGFeaturesDropDown).ElementAt(configtab - 1));
                IList<IWebElement> wTGFeatureslist = wTGFeaturesSelection.Options;
                Assert.IsTrue(wTGFeatureslist.Count > 0);
                for (int i = 1; i < wTGFeatureslist.Count; i++)
                {
                    if (i == optionvalue)
                    {
                        Assert.That(wTGFeatureslist.ElementAt(i).Text, Is.Not.Empty);
                        wTGFeatureslist.ElementAt(i).Click();
                        Thread.Sleep(2000);
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(WTGFeaturesDropDown).Enabled, "User is able to select value for Additional WTG Features DropDown");
            }
            return this;
        }

        //Validate RoadMap phases of template sub tah config
        public SiteSettingsPage ValidateRoadMapPhases(List<RoadMapPhases> phases)
        {
            List<string> roadMapPhases = new List<string> { };
            /*this.GetElement(UnboxingPhase);
            roadMapPhases.Add(this.GetElement(UnboxingPhase).Text);
            this.GetElement(PreparationPhase);
            roadMapPhases.Add(this.GetElement(PreparationPhase).Text);
            this.GetElement(PreAssemblyPhase);
            roadMapPhases.Add(this.GetElement(PreAssemblyPhase).Text);
            this.GetElement(MainErectionPhase);
            roadMapPhases.Add(this.GetElement(MainErectionPhase).Text);
            this.GetElement(MechanicalPhase);
            roadMapPhases.Add(this.GetElement(MechanicalPhase).Text);
            this.GetElement(ElectricalPhase);
            roadMapPhases.Add(this.GetElement(ElectricalPhase).Text);*/
            this.GetElement(Commissioning);
            this.Driver.JavaScripts().ExecuteScript("arguments[0].scrollIntoView(true);", this.GetElement(Commissioning));
            roadMapPhases.Add(this.GetElement(Commissioning).Text.ToLower());

            for (int i = 0; i < phases.Count; i++)
            {
                
                Assert.That(roadMapPhases.Contains(phases[i].phaseName.ToLower()), "RoadMap phases does not exists");
            }

            return this;
        }


        //Validate RoadMap phases of template sub tah config
        public SiteSettingsPage ValidateRoadMapPhasesSelection()
        {
            
            /*this.GetElement(UnboxingPhase);
            roadMapPhases.Add(this.GetElement(UnboxingPhase).Text);
            this.GetElement(PreparationPhase);
            roadMapPhases.Add(this.GetElement(PreparationPhase).Text);
            this.GetElement(PreAssemblyPhase);
            roadMapPhases.Add(this.GetElement(PreAssemblyPhase).Text);
            this.GetElement(MainErectionPhase);
            roadMapPhases.Add(this.GetElement(MainErectionPhase).Text);
            this.GetElement(MechanicalPhase);
            roadMapPhases.Add(this.GetElement(MechanicalPhase).Text);
            this.GetElement(ElectricalPhase);
            roadMapPhases.Add(this.GetElement(ElectricalPhase).Text);*/
            this.GetElement(Commissioning);
            string status = this.GetElement(Commissioning).FindElement(By.CssSelector("input[type='checkbox']")).GetAttribute("disabled");
            

            Assert.True(status.Contains("true"), "RoadMap phases does not exists");
            return this;
        }

        //Select Project from left menu pannel
        public HomePage SelectProjectMenu()
        {
            this.GetElement(ProjectMenu);
            this.Click(ProjectMenu);
            Thread.Sleep(2000);
            return new HomePage(this.DriverContext);
        }

        public async Task CreateProjectConfiguration(string configname, string wtgplatform, string installationstrategy, string nazzletype, string elevatortype, int theight, string tsections, string assemblyphases, string bladetype, string dttype, string ttightingprocess, string gearboxtype, string additionalwtgfeatures, string wtgs, string apiendpoint)
        {
            ApiExecutor api = new ApiExecutor();
            Credentials cr = new Credentials();
            Random randomNumber = new Random();
            var randomNumberString = randomNumber.Next(0, 99).ToString("00");
            string configName = configname + randomNumberString;

            ProjectConfigDtls projectconfig = new ProjectConfigDtls
            {
                configName = configName,
                wtgs = wtgs,
                wtgPlatform = wtgplatform,
                installationStrategy = installationstrategy,
                towerHeight = theight,
                towerSections = tsections,
                assemblyPhases = assemblyphases,
                nazzleType = nazzletype,
                bladeType = bladetype,
                dtType = dttype,
                elevatorType = elevatortype,
                towerTightingProcessType = ttightingprocess,
                gearboxType = gearboxtype,
                additionalWtgFeatures = additionalwtgfeatures,
                projectId = CommonSteps.projectid,
                createdBy = "Admin",
                createdDateTime = "2021-06-17T10:22:39.679709+00:00",
                modifiedBy = null,
                modifiedDateTime = null
            };
            string baseUrl = System.Configuration.ConfigurationManager.AppSettings["APIUrl"];
            string apiurl = baseUrl + apiendpoint;
            var result = await api.PutAsync<ProjectConfigDtls>(apiurl, projectconfig, cr);
            Console.WriteLine("result" + result);
        }

        //Select configuration
        public SiteSettingsPage ClickOnConfigTab(int configtab)
        {
            string configTabText = configtab.ToString();
            IList<IWebElement> tablist = this.GetElements(ConfigTab, 20);
            Assert.True(tablist.Count > 0, "Default 1 configuration is present");
            for (int i = 0; i < tablist.Count-1; i++)
            {
                if (tablist.ElementAt(i).Text.Contains(configTabText))
                {
                    tablist.ElementAt(i).Click();
                    break;
                }
                
            }
            return this;
        }

        public SiteSettingsPage ValidateRoadmapUploadButtonIsNotPresent(int configtab)
        {         
            IList<IWebElement> roadMapUploadButton = this.GetElements(RoadMapUploadButton);
            Assert.IsNull(roadMapUploadButton, "Roadmap UploadButton is not present");
            return this;            
        }

        public SiteSettingsPage ValidateRoadmapUploadButtonIsPresent(int configtab)
        {
            this.GetElements(RoadMapUploadButton).ElementAt(configtab - 1);
            return this;
        }

        public SiteSettingsPage ValidateRoadmapUploadButtonIsEnabled(int configtab)
        {
            Assert.True(this.GetElements(RoadMapUploadButton).ElementAt(configtab - 1).Enabled, "Roadmap upload button is enabled");
            return this;
        }

        public SiteSettingsPage ClickNoRoadmapUploadButton(int configtab)
        {
            this.GetElements(RoadMapUploadButton).ElementAt(configtab - 1).Click();
            return this;
        }

        public SiteSettingsPage ValidateRoadmapUploadPopUpIsPresent()
        {
            Assert.True(this.GetElements(RoadMapFileSelectionPopUp,15).ElementAt(0).Displayed, "RoadMap upload pop window is visible on screen");
            Thread.Sleep(1000);
            return this;
        }

        public SiteSettingsPage UploadRoadMapTemplate(string filepath)
        {
            this.GetElement(RoadMapFileSelectionPanel).SendKeys(filepath);
            return this;
        }

        public SiteSettingsPage ValidateFileUploadErrorMsg(string filename)
        {
            String actualFileName = this.GetElement(UploadedFileName).Text;
            Assert.That(actualFileName.Contains(filename), "Uploaded file name is ");
            return this;
        }



        public SiteSettingsPage ClickOnSaveAndExitButton()
        {
            this.GetElements(RoadMapFileSelectionPopUpButtons, 15).ElementAt(1).Click();
            return this;
        }


    }

}
