﻿using Bdd.Core.Web.Executors;
using Ocaramba;

namespace SGRE.SmartSite.Tests.Bdd.PageObjects
{
    public class ReportPage : ElementPage
    {
        public ReportPage(DriverContext driverContext)
             : base(driverContext)
        {

        }

    }
}