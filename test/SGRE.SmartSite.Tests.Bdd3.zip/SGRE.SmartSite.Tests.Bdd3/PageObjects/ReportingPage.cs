﻿using Bdd.Core.Hooks;
using Bdd.Core.Web.Executors;
using NUnit.Framework;
using Ocaramba;
using Ocaramba.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SGRE.SmartSite.Tests.Bdd.PageObjects
{
    public class ReportingPage : ElementPage
    {
        private readonly ElementLocator ReportingpageName = new ElementLocator(Locator.CssSelector, "label[class='active-bread']"),
        AddTimesheetButton = new ElementLocator(Locator.XPath, "//button/a[contains(text(),'Add Timesheet')]");

        public ReportingPage(DriverContext driverContext) : base(driverContext)
        {}

        /// <summary>
        /// Validate page title
        /// </summary>
        /// <param name="title"></param>
        /// <returns></returns>
        public ReportingPage ValidatePageTitle(string pagetitle)
        {
            string expectedPageTitle = this.GetElement(ReportingpageName).Text;
            Console.WriteLine("pageTitle is: " + expectedPageTitle);
            Assert.AreEqual(pagetitle, expectedPageTitle, "Page title does not match");
            return this;
        }

        /// <summary>
        /// Click on Add Time sheet Button
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage ClickOnAddTimesheetButton()
        {
            this.Click(AddTimesheetButton);
            this.WaitUntilPageLoad(12);
            return new NewTimesheetPage(this.DriverContext);
        }

    }
}
