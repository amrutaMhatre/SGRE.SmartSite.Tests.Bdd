﻿using Bdd.Core.Hooks;
using Bdd.Core.Web.Executors;
using Ocaramba;
using Ocaramba.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SGRE.SmartSite.Tests.Bdd.PageObjects
{
    public class LoginPage : ElementPage
    {
        //private readonly ElementLocator newWindowPageLocator = new ElementLocator(Locator.CssSelector, "h3");

        public LoginPage(DriverContext driverContext) : base(driverContext)
        {}

        public HomePage LoginToSmartApplication(string user)
        {
            //Login Functionality is not developed
            this.OpenHomePage();
            Thread.Sleep(1000);
            return new HomePage(this.DriverContext);
        }
    }
}
