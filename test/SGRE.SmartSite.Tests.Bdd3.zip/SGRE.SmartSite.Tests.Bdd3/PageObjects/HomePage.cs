﻿using Bdd.Core.Web.Executors;
using Bdd.Core.Web.Utils;
using NUnit.Framework;
using Ocaramba;
using Ocaramba.Extensions;
using Ocaramba.Types;
using OpenQA.Selenium;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using TechTalk.SpecFlow;

namespace SGRE.SmartSite.Tests.Bdd.PageObjects
{
    public class HomePage : ElementPage
    {
        private readonly ElementLocator DashBoardTitle = new ElementLocator(Locator.CssSelector, "[class='smart-breadcrumb']>label[class='active-bread']"),
            CurrentLoginField = new ElementLocator(Locator.CssSelector, "[id='account-name']"),
            LastLoginField = new ElementLocator(Locator.CssSelector, "li[class='page-title']"),
            ProfileImage = new ElementLocator(Locator.CssSelector, "li[class='page-title']"),
            LoggedInUserName = new ElementLocator(Locator.CssSelector, "li[class='page-title']"),
            DashBoardTab = new ElementLocator(Locator.CssSelector, "[role='tablist']>[id='uncontrolled-tab-example-tab-project']"),
            ListColumnTitles = new ElementLocator(Locator.CssSelector, "table[class='primary-table table table-sm table-striped'] th"),
            ProjectList = new ElementLocator(Locator.CssSelector, "table[class='primary-table table table-sm table-striped'] tr[class='clickable']"),
            PageNumber = new ElementLocator(Locator.CssSelector, "[class='page-item active']>[class='page-link']"),
            NextLabel = new ElementLocator(Locator.XPath, "//a[contains(text(), 'Next')]"),
            LastLabel = new ElementLocator(Locator.XPath, "//a[contains(text(), 'Last')]"),
            PrevLabel = new ElementLocator(Locator.XPath, "//a[contains(text(), 'Prev')]"),
            FirstLabel = new ElementLocator(Locator.XPath, "//a[contains(text(), 'First')]"),
            SearchBox = new ElementLocator(Locator.CssSelector, "input[id='inlineFormInputGroup']"),
            SearchIcon = new ElementLocator(Locator.CssSelector, "[name='search']"),
            ClearIcon = new ElementLocator(Locator.CssSelector, "table th[ng-repeat='listField in listData.listFields']"),
            SelectedProjectName = new ElementLocator(Locator.CssSelector, "table[class='primary-table table table-sm table-striped'] tr[class='clickable']>td"),
            NextButton = new ElementLocator(Locator.XPath, "//*[@value='NextPage']"),
            LastButton = new ElementLocator(Locator.XPath, "//*[@value='LastPage']"),
            SortIconDown = new ElementLocator(Locator.CssSelector, "[name='arrow-down']"),
            SortIconUp = new ElementLocator(Locator.CssSelector, "[name='arrow-up']"),
            ErrorMesg = new ElementLocator(Locator.XPath, "//*[@value='LastPage']"),
            FailureErrorMesg = new ElementLocator(Locator.CssSelector, "[class='empty-row']"),
            ResetButton = new ElementLocator(Locator.CssSelector, "[class^='clear-btn']>svg[name='cross']"),
            ProjectNameColumn = new ElementLocator(Locator.XPath, "//table[@class='primary-table table table-sm table-striped']//tr/td[1]"),
            PlannedStartDateColumn = new ElementLocator(Locator.XPath, "//table[@class='primary-table table table-sm table-striped']//tr/td[3]"),
            PlannedEndDateColumn = new ElementLocator(Locator.XPath, "//table[@class='primary-table table table-sm table-striped']//tr/td[4]"),
            RegionColumn = new ElementLocator(Locator.XPath, "//table[@class='primary-table table table-sm table-striped']//tr/td[2]"),
            NewProjectButton = new ElementLocator(Locator.CssSelector, "button[class='btn btn-primary']");


        public HomePage(DriverContext driverContext) : base(driverContext)
        { }

        //Validate page title
        public HomePage ValidatePageTitle(string title)
        {
            string pageTitle = this.GetElement(DashBoardTitle).Text;
            Console.WriteLine("pageTitle is: " + pageTitle);
            Assert.AreEqual(title, pageTitle, "Page title does not match");
            return this;
        }

        public HomePage ValidateLoginDetails(string user)
        {

            this.GetElement(CurrentLoginField);
            string currentLoginDetails = this.GetElement(CurrentLoginField).Text;
            this.GetElement(LastLoginField);
            string lastloginDetails = this.GetElement(LastLoginField).Text;
            this.GetElement(ProfileImage);
            string lggedInUserName = this.GetElement(LoggedInUserName).Text;

            Assert.That(currentLoginDetails, Is.Not.Empty);
            Assert.That(lastloginDetails, Is.Not.Empty);
            Assert.That(lggedInUserName, Is.Not.Empty);
            Assert.That(lggedInUserName.Contains(user), "Logged in user name is not marching");
            return this;

        }


        public HomePage ValidateDashboardTabs(string tabtitle)
        {
            //validate list tab
            this.GetElement(DashBoardTab);
            string listTabTitle = this.GetElement(DashBoardTab).Text;
            Assert.That(tabtitle.Equals(listTabTitle), "Dashboard Tab title is not matching");
            //validate list tab is open
            string selectionValue = this.GetElement(DashBoardTab).GetAttribute("aria-selected");
            Assert.True(selectionValue.Equals("true"), "List tab is open");
            return this;
        }

        //Validate list of column titles
        public HomePage ValidateListColumnsTitle(List<string> lstColumnames)
        {
            List<string> lstactualcolumns = new List<string> { };
            IList<IWebElement> columnlist = this.GetElements(ListColumnTitles, 30);
            foreach (IWebElement element in columnlist)
            {
                lstactualcolumns.Add(element.Text);
            }

            if (lstColumnames.Count != lstactualcolumns.Count)
            {
                Assert.Fail("Column names count not matching.");
                return this;
            }
            for (int i = 0; i < lstColumnames.Count; i++)
            {
                Assert.That(lstColumnames[i].Equals(lstactualcolumns[i]), "Dashboard columns are not matching");
            }
            return this;
        }

        //Validate page navigation
        public HomePage ValidatePagination()
        {
            IList<IWebElement> nextButton = this.GetElements(NextLabel);
            if (nextButton != null)
            {
                this.GetElement(NextLabel);
                this.GetElement(LastLabel);
                this.Click(NextLabel);
                Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
                if (this.GetElement(PrevLabel).Enabled && this.GetElement(FirstLabel).Enabled)
                {
                    this.Click(FirstLabel);
                    Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
                }
            }
            else
            {
                Console.WriteLine("Max 1 page of records are available");
            }

            return this;
        }

        //validate pagination options availability
        public HomePage CheckPaginationAvailability()
        {
            string currentpagenumber = this.GetElement(PageNumber).Text;
            Assert.That(currentpagenumber, Is.Not.Empty);
            IList<IWebElement> nextButton = this.GetElements(NextLabel);

            if (nextButton != null)
            {
                this.GetElement(NextLabel);
                string nextLabelText = this.GetElement(NextLabel).Text;
                this.GetElement(LastLabel);
                string lastLabelText = this.GetElement(LastLabel).Text;

                Assert.That(nextLabelText, Is.Not.Empty);
                Assert.That(lastLabelText, Is.Not.Empty);
            }
            else
            {
                Console.WriteLine("Max 1 page of records are available");
            }
            return this;
        }

        //select 1st project from list
        public SiteSettingsPage ValidateSelectProject()
        {
            //get the list count
            IList<IWebElement> projectList = this.GetElements(ProjectList, 90);
            Console.WriteLine("projectList count:" + projectList.Count);
            //if list count greater than 0 then select 1st project
            if (projectList.Count > 0)
            {
                //get the selected project name from list
                this.GetElement(SelectedProjectName);
                var selectedProjectName = this.GetElement(SelectedProjectName).Text;
                //click on 1st project name
                projectList[0].Click();
            }
            else
            {
                Assert.Fail("Project list records are not available");
            }
            return new SiteSettingsPage(this.DriverContext);
        }

        //Select project by project name
        public SiteSettingsPage ValidateSelectProject(string projectname)
        {
            //get the list count
            IList<IWebElement> projectList = this.GetElements(ProjectList, 90);
            Console.WriteLine("projectList count:" + projectList.Count);
            //if list count greater than 0 then select 1st project
            if (projectList.Count > 0)
            {
                IList<IWebElement> projectNameList = this.GetElements(ProjectNameColumn, 90);
                //string[] list = new string[projectNameList.Count];

                for (int i = 0; i < projectNameList.Count; i++)
                {
                    string name = projectNameList.ElementAt(i).Text;

                    if (name.Contains(projectname))
                    {
                        projectNameList.ElementAt(i).Click();
                        break;
                    }
                }
            }
            else
            {
                Assert.Fail("Project list records are not available");
            }
            return new SiteSettingsPage(this.DriverContext);
        }

        public HomePage ValidateSearchOptionIsPresent()
        {
            //Search box is persent
            this.GetElement(SearchBox);
            return this;

        }

        //Validate project search
        public HomePage ValidateSearchOption(string searchtext)
        {
            //Search box is persent
            this.GetElement(SearchBox);
            //Enter text into search box
            this.GetElement(SearchBox).Clear();
            this.GetElement(SearchBox).SendKeys(searchtext);
            Thread.Sleep(2000);
            this.Driver.JavaScripts().ExecuteScript("arguments[0].click();", this.GetElement(SearchIcon));
            Thread.Sleep(7000);
            return this;
        }

        //Validate Search List
        public HomePage ValidateSearchList()
        {
            //get the list count
            IList<IWebElement> projectList = this.GetElements(ProjectList, 90);
            
            if (projectList.Count > 0)
            {
                Console.WriteLine("Project search is successful");
                Console.WriteLine("Project list search count:" + projectList.Count);
            }
            else
            {
                this.GetElement(FailureErrorMesg);
                Assert.That(this.GetElement(FailureErrorMesg).Text, Is.Not.Empty);
            }
            return this;
        }

        //Validate Reset Button
        public HomePage ClickOnResetButton()
        {
            //Search box is persent
            this.GetElement(ResetButton);
            this.Driver.JavaScripts().ExecuteScript("arguments[0].click();", this.GetElement(ResetButton));
            Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(50);
            return this;
        }

        //validate project list view count
        public HomePage ValidateProjectRecordList()
        {
            //get the list count
            IList<IWebElement> projectList = this.GetElements(ProjectList, 90);
            Console.WriteLine("projectList count:" + projectList.Count);
            Assert.True(projectList.Count <= 20, "Max 20 records are display in project list");
            return this;
        }

        public SiteSettingsPage ValidateCreateNewProjectButton()
        {
            this.GetElement(NewProjectButton);
            Assert.That(this.GetElement(NewProjectButton).Text, Is.Not.Empty);
            this.Click(NewProjectButton);
            return new SiteSettingsPage(this.DriverContext);
        }

        public SiteSettingsPage ValidateSelectProjectForEdit()
        {
            //get the list count
            IList<IWebElement> projectList = this.GetElements(ProjectList, 90);
            Console.WriteLine("projectList count:" + projectList.Count);
            //if list count greater than 0 then select 1st project
            if (projectList.Count > 0)
            {
                //get the selected project name from list
                this.GetElement(SelectedProjectName);
                var selectedProjectName = this.GetElement(SelectedProjectName).Text;
                //click on 1st project name
                projectList[1].Click();
            }
            else
            {
                Assert.Fail("Project list records are not available");
            }
            return new SiteSettingsPage(this.DriverContext);
        }


        public HomePage ValidateProjectRecordListSorting()
        {
            int count1, count2;
            Boolean sortFlag = true;
            IList<IWebElement> columnlist = this.GetElements(ListColumnTitles, 30);
            for (int i = 0; i < columnlist.Count - 1; i++)
            {
                do
                {
                    columnlist = this.GetElements(ListColumnTitles, 30);
                    columnlist.ElementAt(i).Click();
                    count1 = this.GetElements(SortIconDown).Count;
                } while (count1 < 0);

                string valueBeforeSort_Projectname = this.GetElements(ProjectNameColumn).ElementAt(0).Text;
                string valueBeforeSort = this.GetElements(ProjectNameColumn).ElementAt(i).Text;

                do
                {
                    columnlist = this.GetElements(ListColumnTitles, 30);
                    columnlist.ElementAt(i).Click();
                    count2 = this.GetElements(SortIconUp).Count;
                } while (count2 < 0);

                string valueAfterSort_Projectname = this.GetElements(ProjectNameColumn).ElementAt(0).Text;
                string valueAfterSort = this.GetElements(ProjectNameColumn).ElementAt(i).Text;

                if (valueBeforeSort_Projectname != valueAfterSort_Projectname || valueBeforeSort != valueAfterSort)
                {
                    Assert.True(sortFlag, "Sorting is working for column no " + i);
                }
                else
                {
                    Assert.True(sortFlag, "Sorting is not working for column no " + i);
                }

            }

            return this;
        }

        //Validate Project Planned start and end date
        public HomePage ValidateProjectSatrtEndDateFormat(String datecolumn)
        {
            string datevalue = null;
            if (datecolumn.Contains("Planned Start Date"))
            {
                datevalue = this.GetElement(PlannedStartDateColumn, 90).Text;
            }else if (datecolumn.Contains("Plnned End Date"))
            {
                datevalue = this.GetElement(PlannedEndDateColumn, 90).Text;
            }
            string[] arr = datevalue.Split('/');
            bool valid = false;

            if (arr.Length == 3)
            {
                string newDate = arr[1] + "/" + arr[0] + "/" + arr[2];
                DateTime parsed;

                valid = DateTime.TryParseExact(newDate, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out parsed);
            }
            return this;
        }

    }

}
