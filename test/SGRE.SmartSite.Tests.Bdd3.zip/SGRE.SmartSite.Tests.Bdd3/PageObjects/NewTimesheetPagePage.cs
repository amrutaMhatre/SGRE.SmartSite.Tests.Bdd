﻿using Bdd.Core.Hooks;
using Bdd.Core.Web.Executors;
using NUnit.Framework;
using Ocaramba;
using Ocaramba.Extensions;
using Ocaramba.Types;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SGRE.SmartSite.Tests.Bdd.PageObjects
{
    public class NewTimesheetPage : ElementPage
    {
        private readonly ElementLocator NewTimesheetpageName = new ElementLocator(Locator.CssSelector, "label[class='active-bread']"),
        BreadcrumbTitle = new ElementLocator(Locator.CssSelector, "[id^='page-content-wrapper'] [class='smart-breadcrumb'] a"),
        CalenderTab = new ElementLocator(Locator.CssSelector, "div[class^= 'head-comp'] div[class$='project-menu-item']"),
        CalenderTabDate = new ElementLocator(Locator.CssSelector, "div[class^= 'head-comp'] div[class$='project-menu-item'] p[class='sub-header']"),
        CalenderOpenIcon = new ElementLocator(Locator.CssSelector, "div[class$='project-menu-item'] [name='arrow-down']"),
        CalenderPopUp = new ElementLocator(Locator.CssSelector, "[class='mx-3 calendar col']"),
        CalenderTodaysDate = new ElementLocator(Locator.CssSelector, "//*[@class='nice-dates-day -today -disabled -selected']//span[@class='nice-dates-day_date']"),
        CalenderCurrentMonth = new ElementLocator(Locator.CssSelector, "[class='nice-dates-navigation_current']"),
        CalenderHeader = new ElementLocator(Locator.CssSelector, "div[class$='project-menu-item'] p[class='sub-header']"),
        CalenderDates = new ElementLocator(Locator.CssSelector, "[class='nice-dates-day'] [class='nice-dates-day_date']"),
        TimesheetColumns = new ElementLocator(Locator.CssSelector, "div[class='activity'] div[class='row']>div[class='col']"),
        AddTimesheetButton = new ElementLocator(Locator.XPath, "//div[@class='plus-btn' and contains(text(),'Add New')]"),
        AddTimesheetWindow = new ElementLocator(Locator.CssSelector, "div[class^='modal-dialog'] [class='modal-content']"),
        TimesheetWindowCollapsIcon = new ElementLocator(Locator.CssSelector, "button[class='cmy-5 arrow-class btn btn-link']"),
        WTGDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'WTG')]/../select"),
        PhaseDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'Phase')]/../select"),
        TaskDropDown = new ElementLocator(Locator.XPath, "//label[contains(text(),'Task')]/../select"),
        PreviousHrs = new ElementLocator(Locator.XPath, "//*[contains(text(),'Previous Hours')]//following-sibling::div[1]"),
        AddNewTaskRow = new ElementLocator(Locator.XPath, "//td[contains(text(),'Add New')]"),
        DeleteTaskRow = new ElementLocator(Locator.CssSelector, "[class='close-btn']"),
        TaskStartTime = new ElementLocator(Locator.CssSelector, "Select[name='startingTime']"),
        TaskFinishTime = new ElementLocator(Locator.CssSelector, "Select[name='finishTime']"),
        EndTime = new ElementLocator(Locator.CssSelector, "Select[name='endTime']"),
        NoOfStaff = new ElementLocator(Locator.CssSelector, "[name='staff']"),
        MainCraneTxtField = new ElementLocator(Locator.CssSelector, "input[name='mainCraneTime']"),
        TnCraneTimeTxtField = new ElementLocator(Locator.CssSelector, "[name='tn500CraneTime']"),
        AuxCraneTxtField = new ElementLocator(Locator.CssSelector, "[name='auxCraneTime']"),
        HoursTotalField = new ElementLocator(Locator.XPath, "//div[contains(text(),'Roadmap Hours')]//following-sibling::div[1]"),
        NightShilfChkBox = new ElementLocator(Locator.CssSelector, "input[name='isNightShift']"),
        CompleteChkBox = new ElementLocator(Locator.CssSelector, "input[name='isComplete']"),
        ExtraWorkChkBox = new ElementLocator(Locator.CssSelector, "input[name='isExtrawork']"),
        RoadmapHrs = new ElementLocator(Locator.XPath, "//div[contains(text(),'Roadmap Hours')]//following-sibling::div[1]"),
        CancelTaskButton = new ElementLocator(Locator.XPath, "//button[contains(text(),'Cancel')]"),
        SaveTaskButton = new ElementLocator(Locator.XPath, "//button[contains(text(),'Save Task')]"),
        Button = new ElementLocator(Locator.XPath, "//button[contains(text(),'Add Hours/Deviation')]"),
        ActivityCard = new ElementLocator(Locator.CssSelector, "div[class='activity cmy-3']"),
        EditActivityCardButton = new ElementLocator(Locator.CssSelector, "div[class='text-right row']>button"),
        AddTimeFrameButton = new ElementLocator(Locator.XPath, "//div[contains(text(),'Add Timeframe')]"),
        ExpandActivityButton = new ElementLocator(Locator.CssSelector, "button[class='cmy-5 arrow-class btn btn-link']"),
        TimeFrameList = new ElementLocator(Locator.XPath, "//div[@class='light-row cmx-5 cmt-10 info row']"),
        AddDeviationButton = new ElementLocator(Locator.XPath, "//div[contains(text(),'Add deviation')]"),
        CauseDropDown = new ElementLocator(Locator.CssSelector, "Select[name='cause']"),
        SubCauseDropDown = new ElementLocator(Locator.CssSelector, "Select[name='subcause']"),
        DetailDropDown = new ElementLocator(Locator.CssSelector, "Select[name='deviationName']"),
        ImpactedResourceDropDown = new ElementLocator(Locator.CssSelector, "Select[name='impactedResourceId']"),
        DeviationCommentArea = new ElementLocator(Locator.CssSelector, "textarea[name='comments']"),
        FTEHrs = new ElementLocator(Locator.CssSelector, "input[name='fteTime']"),
        NccId = new ElementLocator(Locator.CssSelector, "input[name='nccId']"),
        DeviationFileUpload = new ElementLocator(Locator.CssSelector, "span[title='Delete Description File']"),
        DeviationFileSelectionPanel = new ElementLocator(Locator.CssSelector, "div[class='fade modal show'] div[class='modal-content'] section input"),
        BrowseButton = new ElementLocator(Locator.XPath, "//button[contains(text(),'Browse')]"),
        FileUploadPopUp = new ElementLocator(Locator.CssSelector, "div[class='fade modal show'] div[class='modal-content']"),
        DeviationFileSelectionPopUpButtons = new ElementLocator(Locator.CssSelector, "div[class='fade modal show'] div[class='modal-footer'] button"),
        SuccessfullyUploadedFileName = new ElementLocator(Locator.CssSelector, "section[class='upload-container'] [class='row py-3'] [class^='col-6']"),
        UploadedByName = new ElementLocator(Locator.CssSelector, "section[class='upload-container'] [class='row py-3'] [class='col-3']");

        public NewTimesheetPage(DriverContext driverContext) : base(driverContext)
        {}

        /// <summary>
        /// Validate page title
        /// </summary>
        /// <param name="title"></param>
        /// <returns></returns>
        public NewTimesheetPage ValidatePageTitle(string pagetitle)
        {
            string expectedPageTitle = this.GetElement(NewTimesheetpageName).Text;
            Console.WriteLine("pageTitle is: " + expectedPageTitle);
            Assert.AreEqual(pagetitle, expectedPageTitle, "Page title does not match");
            return this;
        }

        /// <summary>
        /// Validate Breadcrumb title 1 and 2
        /// </summary>
        /// <param name="pagetitle1"></param>
        /// <param name="pagetitle2"></param>
        /// <returns></returns>
        public NewTimesheetPage ValidateBreadcrumb(string pagetitle1, string pagetitle2)
        {
            string expectedPageTitle1 = this.GetElements(BreadcrumbTitle).ElementAt(0).Text;
            Assert.AreEqual(pagetitle1, expectedPageTitle1, "Valid Breadcrumb title 1 is display on page");

            string expectedPageTitle2 = this.GetElements(BreadcrumbTitle).ElementAt(1).Text;
            Assert.AreEqual(pagetitle2, expectedPageTitle2, "Valid Breadcrumb title 2 is display on page");
            return this;
        }

        /// <summary>
        /// Validate calender window with today's date
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage ValidateCalenderWindow()
        {
            this.GetElement(CalenderTab);
            CultureInfo ci = new CultureInfo("en-US");
            var year = DateTime.Now.Year;
            var Date = DateTime.Now.ToString("dd", ci);
            string month = DateTime.Now.ToString("MMMM", ci);
            String monthName;
            if (month.Length > 3)
            {
                monthName = month.Substring(0, 3);
            }
            else
            {
                monthName = month;
            }
            string todaysDate = Date + " " + monthName + " " + year;
            string expectedCalenderDate = this.GetElement(CalenderTabDate).Text;
            Assert.AreEqual(todaysDate, expectedCalenderDate, "Valid Breadcrumb title 2 is display on page");
            return this;
        }

        /// <summary>
        /// Validate open calender view with date and month
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage OpenCalenderWindow()
        {
            this.WaitUntilElementIsVisible(CalenderOpenIcon, 15);
            this.GetElement(CalenderOpenIcon);
            this.Driver.JavaScripts().ExecuteScript("arguments[0].click();", this.GetElements(CalenderOpenIcon).ElementAt(1));
            this.WaitUntilElementIsVisible(CalenderPopUp, 10);
            Assert.IsTrue(this.GetElement(CalenderPopUp).Displayed, "Calender window is open");
            CultureInfo ci = new CultureInfo("en-US");
            var year = DateTime.Now.Year;
            var Date = DateTime.Now.ToString("dd", ci);
            string month = DateTime.Now.ToString("MMMM", ci);
            String monthName;
            if (month.Length > 3)
            {
                monthName = month.Substring(0, 3);
            }
            else
            {
                monthName = month;
            }
            string todaysDate = Date + " " + monthName + " " + year;
            Assert.True(this.GetElements(CalenderHeader).ElementAt(1).GetAttribute("title").Equals(todaysDate), "Project creation field is non editable");
            return this;
        }

        /// <summary>
        /// Validate select data from calender window
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage SelectCalenderDate()
        {
            IList<IWebElement> dates = this.GetElements(CalenderDates);
            var Date = DateTime.Today.AddDays(-1);
            for(int i=0; i< dates.Count; i++)
            {
                if (dates.ElementAt(i).Text.Equals(Date))
                {
                    dates.ElementAt(i).Click();
                    break;
                }
            }
            return this;
        }

        /// <summary>
        /// Validate time sheet columns
        /// </summary>
        /// <param name="lstColumnames"></param>
        /// <returns></returns>
        public NewTimesheetPage ValidateListColumnsTitle(List<string> lstColumnames)
        {
            List<string> lstactualcolumns = new List<string> { };
            IList<IWebElement> columnlist = this.GetElements(TimesheetColumns, 30);
            foreach (IWebElement element in columnlist)
            {
                lstactualcolumns.Add(element.Text);
            }
     
            for (int i = 0; i < lstColumnames.Count; i++)
            {
                string value1 = lstColumnames[i];
                string value2 = lstactualcolumns[i+1];
                Assert.That(lstColumnames[i].Equals(lstactualcolumns[i+1]), "Dashboard columns are not matching");
            }
            return this;
        }

        /// <summary>
        /// Click on Add Task button and validate the add new timesheet window is open
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage ClickOnAddTaskButton()
        {
            //Actions action = new Actions(Driver);
            //action.MoveToElement(this.GetElement(AddTimesheetButton)).Build().Perform();
            //action.MoveToElement(this.GetElement(AddTimesheetButton)).Click();
            this.WaitUntilElementIsVisible(AddTimesheetButton, 60);
            this.Driver.JavaScripts().ExecuteScript("arguments[0].click();", this.GetElement(AddTimesheetButton));
            this.WaitUntilElementIsVisible(TimesheetWindowCollapsIcon, 15);
            Assert.True(this.GetElement(TimesheetWindowCollapsIcon).Displayed, "Add Task/Deviation window is open under Activities");
            return this;
        }

        /// <summary>
        /// Select WTG's from drop down list of add task to timesheet screen
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage SelectWTG(int index)
        {
            Thread.Sleep(2000);
            var isEnabled = this.GetElement(WTGDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement wtgSelection = new SelectElement(this.GetElement(WTGDropDown));
                IList<IWebElement> wtglist = wtgSelection.Options;
                Assert.IsTrue(wtglist.Count > 0, "WTG selection list is not empty");
                for (int i = 1; i < wtglist.Count; i++)
                {
                    if (i == index)
                    {
                        Assert.That(wtglist.ElementAt(i).Text, Is.Not.Empty);
                        wtglist.ElementAt(i).Click();
                        break;
                    }                 
                }
            }
            else
            {
                Assert.True(this.GetElement(WTGDropDown).Enabled, "User is able to select WTG's from drop down list");
            }
            return this;
        }

        /// <summary>
        /// Select phases from drop down list of add task to timesheet screen
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage SelectPhase(int index)
        {
            Thread.Sleep(2000);
            // Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(90);
            var isEnabled = this.GetElement(PhaseDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement phaseSelection = new SelectElement(this.GetElement(PhaseDropDown));
                IList<IWebElement> phaselist = phaseSelection.Options;
                Assert.IsTrue(phaselist.Count > 0, "Phase selection list is not empty");
                for (int i = 1; i < phaselist.Count; i++)
                {
                    if (i == index)
                    {
                        Assert.That(phaselist.ElementAt(i).Text, Is.Not.Empty);
                        phaselist.ElementAt(i).Click();
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(PhaseDropDown).Enabled, "User is able to select phases from drop down list");
            }
            return this;
        }

        /// <summary>
        /// Select Tasks from drop down list of add task to timesheet screen
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage SelectTask(int index)
        {
            Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            var isEnabled = this.GetElement(TaskDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement taskSelection = new SelectElement(this.GetElement(TaskDropDown));
                IList<IWebElement> tasklist = taskSelection.Options;
                Assert.IsTrue(tasklist.Count > 0, "Task selection list is not empty");
                for (int i = 1; i < 2; i++)
                {
                    if (i == index)
                    {
                        string value = tasklist.ElementAt(i).Text;
                        Assert.That(tasklist.ElementAt(i).Text, Is.Not.Empty, "WTG Phase is empty for index "+ i);
                        tasklist.ElementAt(i).Click();
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(TaskDropDown).Enabled, "User is able to select phases from drop down list");
            }
            return this;
        }

        /// <summary>
        /// Validate the previous hrs are zero
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage ValidatePreviousHrsAreZero()
        {
            this.WaitUntilElementIsVisible(PreviousHrs, 15);
            int previousHrs = int.Parse(this.GetElement(PreviousHrs).Text);
            Assert.AreEqual(0, previousHrs, "Previous hours are display as expected");
            return this;
        }

        /// <summary>
        /// Add new task row into timesheet window
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage AddNewTimesheetRow()
        {
            this.Driver.JavaScripts().ExecuteScript("arguments[0].click();", this.GetElement(AddNewTaskRow));
            this.WaitUntilElementIsVisible(DeleteTaskRow,10);
            Assert.True(this.GetElements(DeleteTaskRow).Count>0);
            return this;
        }
        
        /// <summary>
        /// Delete time sheet task row
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage DeleteTimesheetRow()
        {
            int rowCount = this.GetElements(AddNewTaskRow).Count;
            this.Driver.JavaScripts().ExecuteScript("arguments[0].click();", this.GetElement(AddNewTaskRow));
            Assert.True(rowCount > this.GetElements(AddNewTaskRow).Count);
            return this;
        }

        /// <summary>
        /// Select start time from drop down list to add task to timesheet screen
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage SelectStratTime(int starttime, int index)
        {
            var isEnabled = this.GetElement(TaskStartTime).Enabled;
            if (isEnabled)
            {
                SelectElement timeSelection = new SelectElement(this.GetElements(TaskStartTime).ElementAt(index - 1));
                IList<IWebElement> timeList = timeSelection.Options;
                Assert.IsTrue(timeList.Count > 0, "Time selection list is not empty");
                for (int i = 1; i < timeList.Count; i++)
                {
                    if (i == starttime)
                    {
                        timeList.ElementAt(i).Click();
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(TaskStartTime).Enabled, "User is able to select time from drop down list");
            }
            return this;
        }

        /// <summary>
        /// Select finish time from drop down list to add task to timesheet screen
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage SelectFinishTime(int finishtime, int index)
        {
            var isEnabled = this.GetElement(TaskStartTime).Enabled;
            if (isEnabled)
            {
                SelectElement timeSelection = new SelectElement(this.GetElements(TaskFinishTime).ElementAt(index-1));
                IList<IWebElement> timeList = timeSelection.Options;
                Assert.IsTrue(timeList.Count > 0, "Time selection list is not empty");
                for (int i = 1; i < timeList.Count; i++)
                {
                    if (i == finishtime)
                    {
                        timeList.ElementAt(i).Click();
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(TaskFinishTime).Enabled, "User is able to select time from drop down list");
            }
            return this;
        }

        /// <summary>
        /// Select End time from drop down list to add task to timesheet screen
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage SelectEndTime(int endtime, int index)
        {
            var isEnabled = this.GetElement(EndTime).Enabled;
            if (isEnabled)
            {
                SelectElement timeSelection = new SelectElement(this.GetElement(EndTime));
                IList<IWebElement> timeList = timeSelection.Options;
                Assert.IsTrue(timeList.Count > 0, "Time selection list is not empty");
                for (int i = 1; i < timeList.Count; i++)
                {
                    if (i == endtime)
                    {
                        timeList.ElementAt(i).Click();
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(EndTime).Enabled, "User is able to select time from drop down list");
            }
            return this;
        }

        /// <summary>
        /// Time frame entry for start time, finish time, no of staff, main crane, 500tcrane, aux crane
        /// </summary>
        /// <param name="starttime"></param>
        /// <param name="finishtime"></param>
        /// <param name="staff"></param>
        /// <param name="maincrane"></param>
        /// <param name="tcrane"></param>
        /// <param name="auxcrane"></param>
        /// <returns></returns>
        public NewTimesheetPage TimeEnteryForTimesheetTask(int starttime, int finishtime, string staff, string maincrane, string tcrane, string auxcrane, int index)
        {
            SelectStratTime(starttime, index);
            SelectFinishTime(finishtime, index);
            
            this.GetElements(NoOfStaff).ElementAt(index - 1).SendKeys(staff);
            this.GetElements(MainCraneTxtField).ElementAt(index - 1).SendKeys(maincrane);
            this.GetElements(TnCraneTimeTxtField).ElementAt(index - 1).SendKeys(tcrane);
            this.GetElements(AuxCraneTxtField).ElementAt(index - 1).SendKeys(auxcrane);
            return this;
        }


        public NewTimesheetPage dataEntryForDeviationTask(int starttime, int endtime, string ftehrs, string maincrane, string tcrane, string auxcrane, string nccid, int index)
        {
            SelectStratTime(starttime, index);
            SelectEndTime(endtime, index);
            this.GetElements(MainCraneTxtField).ElementAt(index - 1).SendKeys(maincrane);
            this.GetElements(TnCraneTimeTxtField).ElementAt(index - 1).SendKeys(tcrane);
            this.GetElements(AuxCraneTxtField).ElementAt(index - 1).SendKeys(auxcrane);
            this.GetElement(NccId).SendKeys(nccid);
            Assert.IsTrue(this.GetElement(FTEHrs).GetAttribute("value").Contains(ftehrs));
            return this;
        }

        /// <summary>
        /// Validate that Time frame fields start time, finish time, no of staff, main crane, 500tcrane, aux crane are empty
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage TimeEnteryForTimesheetTaskIsEmpty(int index)
        {
            Assert.That(this.GetElements(TaskStartTime).ElementAt(index - 1).Text.Contains("00:00"));
            Assert.That(this.GetElements(TaskFinishTime).ElementAt(index - 1).Text.Contains("00:00"));
            Assert.That(this.GetElements(NoOfStaff).ElementAt(index - 1).GetAttribute("value").Contains("0"));
            Assert.IsNull(this.GetElements(MainCraneTxtField).ElementAt(index - 1).Text);
            Assert.IsNull(this.GetElements(TnCraneTimeTxtField).ElementAt(index - 1).Text);
            Assert.IsNull(this.GetElements(AuxCraneTxtField).ElementAt(index - 1).Text);
            return this;
        }

        /// <summary>
        /// Verify total hours of time frame
        /// </summary>
        /// <param name="totalhrs"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage TimeEnteryForTimesheetTask(string totalhrs, int index)
        {
            string actualhrs = this.GetElements(HoursTotalField).ElementAt(index - 1).Text;
            Assert.AreEqual(totalhrs, actualhrs, "Total hours display for time frame is currect");
            return this;
        }

        /// <summary>
        /// Select Night shift check box
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage SelectNightShilfChkBoxResources(int index)
        {
            if(this.GetElements(NightShilfChkBox).ElementAt(index - 1).Selected)
            {
                Console.WriteLine("Night shift checkbox is already selected");
            }
            else
            {
                this.GetElements(NightShilfChkBox).ElementAt(index - 1).Click();
                Assert.IsTrue(this.GetElements(NightShilfChkBox).ElementAt(index - 1).Selected, "Night shift checkbox is selected");
            }            
            return this;
        }

        /// <summary>
        /// Select complete checkbox
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage SelectCompleteChkBoxResources(int index)
        {
            if (this.GetElements(CompleteChkBox).ElementAt(index - 1).Selected)
            {
                Console.WriteLine("Complete checkbox is already selected");
            }
            else
            {
                this.GetElements(CompleteChkBox).ElementAt(index - 1).Click();
                Assert.IsTrue(this.GetElements(CompleteChkBox).ElementAt(index - 1).Selected, "Complete checkbox is selected");
            }
            return this;
        }

        /// <summary>
        /// Select Extra work checkbox
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage SelectExtraWorkChkBoxResources(int index)
        {
            if (this.GetElements(ExtraWorkChkBox).ElementAt(index - 1).Selected)
            {
                Console.WriteLine("Extra work checkbox is already selected");
            }
            else
            {
                this.GetElements(ExtraWorkChkBox).ElementAt(index - 1).Click();
                Assert.IsTrue(this.GetElements(ExtraWorkChkBox).ElementAt(index - 1).Selected, "Extra work checkbox is selected");
            }
            return this;
        }

        /// <summary>
        /// Validate that time frame resources night shift, complete and extra work check boxes are not selected
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage ValidateTimeFrameResourcesAreNotSlected(int index)
        {
            Assert.IsFalse(this.GetElements(NightShilfChkBox).ElementAt(index - 1).Selected, "Night shift checkbox is not selected");
            Assert.IsFalse(this.GetElements(CompleteChkBox).ElementAt(index - 1).Selected, "Complete checkbox is not selected");
            Assert.IsFalse(this.GetElements(ExtraWorkChkBox).ElementAt(index - 1).Selected, "Extra work checkbox is not selected");
            return this;
        }

        /// <summary>
        /// Validate that roadmap hours are not null
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage ValidateRoadmapHoursNotNull(int index)
        {
            Assert.NotNull(this.GetElements(RoadmapHrs).ElementAt(index - 1), "Roadmap hours for timeframe "+ index+ " is not null");
            return this;
        }

        /// <summary>
        /// Validate Activity card is not present
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage ValidateTimeActivityCardIsNotPresent(int index)
        {
            Assert.Null(this.GetElements(ActivityCard), "Activity card is not Present");
            return this;
        }

        /// <summary>
        /// Validate Activity card is present
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage ValidateTimeActivityCardIsPresent(int index)
        {
            Assert.IsTrue(this.GetElements(ActivityCard).Count.Equals(index),"Activity card is not Present");
            return this;
        }

        /// <summary>
        /// Click on cancel task button
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage ClickOnCancelTaskButton()
        {
            this.GetElement(CancelTaskButton).Click();
            return this;
        }

        /// <summary>
        /// Click on save task button
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage ClickOnSaveTaskButton()
        {
            this.Driver.JavaScripts().ExecuteScript("arguments[0].scrollIntoView(true);", this.GetElement(SaveTaskButton));
            this.GetElement(SaveTaskButton).Click();
            return this;
        }

        /// <summary>
        /// Click on Task Edit button of timeframe
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage ClickOnTaskEditButton()
        {
            //this.GetElement(EditTaskButton).Click();
            return this;
        }     

        /// <summary>
        /// Click on Add new timeframe button
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage ClickOnAddTimeFrameButton(int index)
        {
            Actions action = new Actions(Driver);
            action.MoveToElement(this.GetElement(AddTimeFrameButton)).Click().Perform();
            Assert.IsTrue(this.GetElements(TimeFrameList).Count > 0, "Time frame is added to time card");
            return this;
        }

        public NewTimesheetPage ValidatePreviousHrs(decimal previoushrs)
        {
            this.WaitUntilElementIsVisible(PreviousHrs, 15);
            decimal currentHrs = decimal.Parse(this.GetElement(PreviousHrs).Text);
            Assert.AreEqual(previoushrs, currentHrs, "Previous hours are display as expected");
            return this;
        }

        /// <summary>
        /// Expan the activity card
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage ClickOnExpandActivityButton()
        {
            Thread.Sleep(2000);
            this.GetElement(ExpandActivityButton).Click();
            return this;
        }

        /// <summary>
        /// Click on Edit Activity card Button
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage ClickOnTaskEditActivityButton()
        {
            this.GetElements(EditActivityCardButton).ElementAt(0).Click();
            return this;
        }

        public NewTimesheetPage ClickOnAddDeviationButton(int index)
        {
            Actions action = new Actions(Driver);
            action.MoveToElement(this.GetElement(AddDeviationButton)).Click().Perform();
            return this;
        }

        /// <summary>
        /// Select deviation cause from drop down
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage SelectDeviationCause(int index)
        {
            Thread.Sleep(2000);
            var isEnabled = this.GetElement(CauseDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement causeSelection = new SelectElement(this.GetElement(CauseDropDown));
                IList<IWebElement> causelist = causeSelection.Options;
                Assert.IsTrue(causelist.Count > 0, "Cause selection list is not empty");
                for (int i = 1; i < causelist.Count; i++)
                {
                    if (i == index)
                    {
                        Assert.That(causelist.ElementAt(i).Text, Is.Not.Empty);
                        causelist.ElementAt(i).Click();
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(CauseDropDown).Enabled, "User is able to select Deviation Cause from drop down list");
            }
            return this;
        }

        /// <summary>
        /// Select deviation subcause from drop down
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage SelectDeviationSubCause(int index)
        {
            Thread.Sleep(2000);
            var isEnabled = this.GetElement(SubCauseDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement subCauseSelection = new SelectElement(this.GetElement(SubCauseDropDown));
                IList<IWebElement> subcauselist = subCauseSelection.Options;
                Assert.IsTrue(subcauselist.Count > 0, "Sub-Cause selection list is not empty");
                for (int i = 1; i < subcauselist.Count; i++)
                {
                    if (i == index)
                    {
                        Assert.That(subcauselist.ElementAt(i).Text, Is.Not.Empty);
                        subcauselist.ElementAt(i).Click();
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(SubCauseDropDown).Enabled, "User is able to select Deviation Sub-Cause from drop down list");
            }
            return this;
        }

        /// <summary>
        /// Select deviation Detail from drop down
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage SelectDeviationDetail(int index)
        {
            Thread.Sleep(2000);
            var isEnabled = this.GetElement(DetailDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement detailSelection = new SelectElement(this.GetElement(DetailDropDown));
                IList<IWebElement> detaillist = detailSelection.Options;
                Assert.IsTrue(detaillist.Count > 0, "Cause deatil selection list is not empty");
                for (int i = 1; i < detaillist.Count; i++)
                {
                    if (i == index)
                    {
                        Assert.That(detaillist.ElementAt(i).Text, Is.Not.Empty);
                        detaillist.ElementAt(i).Click();
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(DetailDropDown).Enabled, "User is able to select Deviation Detail from drop down list");
            }
            return this;
        }

        /// <summary>
        /// Select deviation Impacted resource from drop down
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public NewTimesheetPage SelectimpactedResource(int index)
        {
            Thread.Sleep(2000);
            var isEnabled = this.GetElement(ImpactedResourceDropDown).Enabled;
            if (isEnabled)
            {
                SelectElement impactedResourceSelection = new SelectElement(this.GetElement(ImpactedResourceDropDown));
                IList<IWebElement> impactedResourcelist = impactedResourceSelection.Options;
                Assert.IsTrue(impactedResourcelist.Count > 0, "Impacted Resource selection list is not empty");
                for (int i = 1; i < impactedResourcelist.Count; i++)
                {
                    if (i == index)
                    {
                        Assert.That(impactedResourcelist.ElementAt(i).Text, Is.Not.Empty);
                        impactedResourcelist.ElementAt(i).Click();
                        break;
                    }
                }
            }
            else
            {
                Assert.True(this.GetElement(ImpactedResourceDropDown).Enabled, "User is able to select Impacted Resource from drop down list");
            }
            return this;
        }

        /// <summary>
        /// Add deviation comments
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage EnterDeviationComment()
        {
            this.GetElement(DeviationCommentArea).SendKeys("This is deviation");
            return this;
        }

        public NewTimesheetPage ValidateDeviationFileIsNotUploaded()
        {
            Assert.IsNull(this.GetElements(DeviationFileUpload));
            return this;
        }

        public NewTimesheetPage ValidateDeviationFileIsUploaded()
        {
            Assert.IsTrue(this.GetElements(DeviationFileUpload).Count>0);
            return this;
        }

        /// <summary>
        /// Upload deviation file
        /// </summary>
        /// <param name="filepath"></param>
        /// <returns></returns>
        public NewTimesheetPage UploadDeviationFile(string filepath)
        {
            this.GetElement(DeviationFileSelectionPanel).SendKeys(filepath);
            return this;
        }

        /// <summary>
        /// Click on File upload browser button
        /// </summary>
        /// <param name="filepath"></param>
        /// <returns></returns>
        public NewTimesheetPage ClickOnBrowerButton()
        {
            this.Driver.JavaScripts().ExecuteScript("arguments[0].scrollIntoView(true);", this.GetElement(BrowseButton));
            Assert.IsTrue(this.GetElement(BrowseButton).Displayed, "Deviation file upload browser button is display");
            this.GetElement(BrowseButton).Click();
            return this;
        }

        public NewTimesheetPage ValidateFileUploadPopUpIsPresent()
        {
            Assert.True(this.GetElement(FileUploadPopUp, 15).Displayed, "Deviation file upload pop window is visible on screen");
            return this;
        }

        /// <summary>
        /// Click on cancel button of pop up window
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage ClickOnCancelButtonOfFileUploadPopUp()
        {
            this.GetElements(DeviationFileSelectionPopUpButtons, 15).ElementAt(0).Click();         
            return this;
        }

        /// <summary>
        /// Click on save button of pop up window
        /// </summary>
        /// <returns></returns>
        public NewTimesheetPage ClickOnSaveButtonOfFileUploadPopUp()
        {
            this.GetElements(DeviationFileSelectionPopUpButtons, 15).ElementAt(1).Click();
            return this;
        }

        public NewTimesheetPage ValidateFileUploadDetailsMsg(string filename)
        {
            this.WaitUntilElementIsVisible(SuccessfullyUploadedFileName, 10);
            string actualFileName = this.GetElements(SuccessfullyUploadedFileName).ElementAt(1).Text;
            Assert.That(actualFileName.Contains(filename), "Uploaded file name is display as expected");

            string fileUploadedBy = this.GetElement(UploadedByName).Text;
            Assert.That(fileUploadedBy.Contains("admin"), "File Uploaded by name is display as expected");

            String fileUploadedDate = this.GetElements(UploadedByName).ElementAt(1).Text;
            string todaysDate = DateTime.Now.ToString("d/M/yyyy");
            Assert.That(fileUploadedDate.Contains(todaysDate), "File Uploaded date is display as expected");
            return this;
        }
        public NewTimesheetPage DeleteDeviationFileIsUploaded()
        {
            Thread.Sleep(2000);
            this.Driver.JavaScripts().ExecuteScript("arguments[0].scrollIntoView(true);", this.GetElement(SaveTaskButton));
            Assert.IsTrue(this.GetElements(DeviationFileUpload).Count > 0);
            int previousCount = this.GetElements(DeviationFileUpload).Count;
            this.GetElement(DeviationFileUpload).Click();
            return this;
        }

        public NewTimesheetPage ValidateDeviationFileCount(int index)
        {           
            if (index == 3)
            {
                Assert.IsNull(this.GetElements(DeviationFileUpload));
            }
            else
            {
                Assert.IsNotNull(this.GetElements(DeviationFileUpload));

            }

            return this;
        }
    }
}
