﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DocDb.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace SGRE.SmartSite.Tests.Bdd.Executors
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Linq;
    using System.Threading.Tasks;
    using global::Bdd.Core.DataSources;
    using Microsoft.Azure.Cosmos;
    using Microsoft.Azure.Documents.Client;

    public class DocDb : DocDbDataSource
    {
        private readonly NameValueCollection endpointUriSection = ConfigurationManager.GetSection("docDb") as NameValueCollection;

        public async Task DeleteDocumentWithIdAsync(string partitionKey, string id, string collection)
        {
            Database database;
            Container container;
            using (CosmosClient cosmosClient = new CosmosClient(this.endpointUriSection["EndPointUrl"], this.endpointUriSection["AuthorizationKey"]))
            {
                database = cosmosClient.GetDatabase(this.endpointUriSection["DatabaseName"]);
                container = database.GetContainer(collection);

                // Delete an item. Note we must provide the partition key value and id of the item to delete
                await container.DeleteItemStreamAsync(id, new PartitionKey(partitionKey)).ConfigureAwait(false);
            }
        }

        public IEnumerable<T> ReadAllInternal<T>(string input = null, string collectionName = null)
        {
            using (var client = new DocumentClient(new Uri(this.endpointUriSection["EndPointUrl"]), this.endpointUriSection["AuthorizationKey"], new ConnectionPolicy { ConnectionMode = Microsoft.Azure.Documents.Client.ConnectionMode.Gateway, ConnectionProtocol = Protocol.Https }))
            {
                var collectionUri = UriFactory.CreateDocumentCollectionUri(this.endpointUriSection["DatabaseName"], collectionName);
                var result = client.CreateDocumentQuery<T>(collectionUri, input).ToList();
                return result.AsEnumerable();
            }
        }
    }
}
