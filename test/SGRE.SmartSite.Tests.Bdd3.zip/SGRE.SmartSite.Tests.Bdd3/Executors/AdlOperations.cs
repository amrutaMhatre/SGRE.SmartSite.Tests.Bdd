﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AdlOperations.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace SGRE.SmartSite.Tests.Bdd.Executors
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Diagnostics.Contracts;
    using System.Linq;
    using System.Net;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Microsoft.WindowsAzure.Storage;
    using Microsoft.WindowsAzure.Storage.Auth;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;

    public static class AdlOperations
    {
        private static readonly string StorageKey = (ConfigurationManager.GetSection("dataLake") as NameValueCollection)["DataLakeKey"];
        private static readonly StorageCredentials StorageCredentials = new StorageCredentials((ConfigurationManager.GetSection("dataLake") as NameValueCollection)["AccountName"], StorageKey);
        private static readonly CloudStorageAccount StorageAccount = new CloudStorageAccount(StorageCredentials, true);
        private static readonly string Sas = StorageAccount.GetSharedAccessSignature(new SharedAccessAccountPolicy()
        {
            Permissions = SharedAccessAccountPermissions.Add | SharedAccessAccountPermissions.Create | SharedAccessAccountPermissions.Delete | SharedAccessAccountPermissions.List |
                            SharedAccessAccountPermissions.ProcessMessages | SharedAccessAccountPermissions.Read | SharedAccessAccountPermissions.Update | SharedAccessAccountPermissions.Write,
            Services = SharedAccessAccountServices.Blob | SharedAccessAccountServices.File | SharedAccessAccountServices.Queue |
                        SharedAccessAccountServices.Table,
            Protocols = SharedAccessProtocol.HttpsOnly,
            ResourceTypes = SharedAccessAccountResourceTypes.Container | SharedAccessAccountResourceTypes.Object |
                            SharedAccessAccountResourceTypes.Service,
            SharedAccessStartTime = DateTime.Now,
            SharedAccessExpiryTime = DateTime.UtcNow.AddMinutes(20),
        });

        public static HttpWebResponse GetResponseUsingList(string filePath, string valueLike)
        {
            try
            {
                Contract.Requires(filePath != null, "x");
                List<JObject> paths = GetListOfFilesFromAdls(filePath, valueLike);
                string uri = (ConfigurationManager.GetSection("dataLake") as NameValueCollection)["DataLakeUri"]
                        + filePath.Substring(0, filePath.IndexOf('?'))
                        + "/"
                        + paths.Last()["name"];
                HttpWebRequest req = (System.Net.HttpWebRequest)WebRequest.CreateDefault(new Uri(uri + Sas));
                req.Method = "GET";
                return (HttpWebResponse)req.GetResponse();
            }
            catch (WebException e)
            {
                HttpWebResponse subResponse = (HttpWebResponse)e.Response;
                if (e.Status == WebExceptionStatus.ProtocolError)
                {
                    Assert.Fail("Errorcode: {0}", (int)subResponse.StatusCode);
                }
                else
                {
                    Assert.Fail("Error: {0}", e.Status);
                }

                return subResponse;
            }
        }

        public static void DeleteFileFromAdl(string filePath, string valueLike)
        {
            try
            {
                List<JObject> jObjects = GetListOfFilesFromAdls(filePath, valueLike);
                foreach (JObject jObject in jObjects)
                {
                    string uri = (ConfigurationManager.GetSection("dataLake") as NameValueCollection)["DataLakeUri"]
                            + filePath.Substring(0, filePath.IndexOf('?'))
                            + "/"
                            + jObject["name"];

                    HttpWebRequest req = (System.Net.HttpWebRequest)WebRequest.CreateDefault(new Uri(uri + Sas));
                    req.Method = "DELETE";
                    req.GetResponse();
                }
            }
            catch (WebException e)
            {
                if (e.Status == WebExceptionStatus.ProtocolError)
                {
                    HttpWebResponse subResponse = (HttpWebResponse)e.Response;
                    Assert.Fail("Errorcode: {0}", (int)subResponse.StatusCode);
                }
                else
                {
                    Assert.Fail("Error: {0}", e.Status);
                }
            }
        }

        private static List<JObject> GetListOfFilesFromAdls(string filePath, string valueLike)
        {
            try
            {
                string uri = (ConfigurationManager.GetSection("dataLake") as NameValueCollection)["DataLakeUri"] + filePath;
                string continuationToken = nameof(continuationToken);
                string responseText = string.Empty;
                while (!string.IsNullOrEmpty(continuationToken))
                {
                    HttpWebRequest req = continuationToken == nameof(continuationToken) ? (HttpWebRequest)WebRequest.CreateDefault(new Uri(uri + "&" + Sas.Substring(1))) :
                        (System.Net.HttpWebRequest)WebRequest.CreateDefault(new Uri(uri + "&continuation=" + continuationToken + "&resource=filesystem" + "&" + Sas.Substring(1)));
                    req.Method = "GET";
                    HttpWebResponse httpWebResponse = (HttpWebResponse)req.GetResponse();
                    continuationToken = httpWebResponse.GetResponseHeader("x-ms-continuation");
                    continuationToken = continuationToken.Replace("=", "%3D");
                    using (var reader = new System.IO.StreamReader(httpWebResponse.GetResponseStream()))
                    {
                        responseText = reader.ReadToEnd();
                    }
                }

                JObject listOfObjects = (JObject)JsonConvert.DeserializeObject(responseText);
                return listOfObjects["paths"].Values<JObject>().Where(m => m["name"].Value<string>().Contains(valueLike)).ToList();
            }
            catch (WebException e)
            {
                if (e.Status == WebExceptionStatus.ProtocolError)
                {
                    Assert.Fail("Errorcode: {0}", (int)((HttpWebResponse)e.Response).StatusCode);
                }
                else
                {
                    Assert.Fail("Error: {0}", e.Status);
                }

                return null;
            }
        }
    }
}
