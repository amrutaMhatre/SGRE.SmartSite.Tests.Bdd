﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SendServiceBusMessages.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace SGRE.SmartSite.Tests.Bdd.Executors
{
    using System;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Globalization;
    using System.Text;
    using System.Threading.Tasks;
    using Microsoft.Azure.ServiceBus;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    public class SendServiceBusMessages
    {
        private static readonly NameValueCollection ServiceBusSection = ConfigurationManager.GetSection("serviceBus") as NameValueCollection;
        private readonly string serviceBusConnectionString = ServiceBusSection["ConnectionStringKey"];
        private ITopicClient topicClient;

        public async Task SendMessagesAsync(string topicName, string testData)
        {
            this.topicClient = new TopicClient(this.serviceBusConnectionString, topicName);

            try
            {
                // Create a new message to send to the topic.
                string messageBody = testData;
                var message = new Message(Encoding.UTF8.GetBytes(messageBody));

                // Send the message to the topic.
                await this.topicClient.SendAsync(message).ConfigureAwait(false);
            }
            catch (UnauthorizedAccessException exception)
            {
                Assert.Fail(DateTime.Now.ToString(new CultureInfo("en-US")) + exception.Message);
            }
        }
    }
}
