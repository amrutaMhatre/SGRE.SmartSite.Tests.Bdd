﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RandomNumbersGeneration.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace SGRE.SmartSite.Tests.Bdd.Executors
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    internal static class RandomNumbersGeneration
    {
        public static List<int> GetRandomNumbers(int sourceRecordsCount)
        {
            if (sourceRecordsCount == 0)
            {
                return null;
            }

            List<int> randomList = new List<int>();
            Random random = new Random();
            for (int i = 0; i < 100; i++)
            {
                randomList.Add(random.Next(0, sourceRecordsCount - 1));
            }

            randomList = randomList.Distinct().ToList();

            return randomList;
        }
    }
}
