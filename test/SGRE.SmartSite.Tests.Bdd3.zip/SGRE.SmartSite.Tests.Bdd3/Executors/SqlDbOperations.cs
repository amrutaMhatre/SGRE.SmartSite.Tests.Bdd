﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SqlDbOperations.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace SGRE.SmartSite.Tests.Bdd.Executors
{
    using System.Data;
    using System.Data.SqlClient;
    using global::Bdd.Core.DataSources;
    using SGRE.SmartSite.Tests.Bdd.Entities;

    internal class SqlDbOperations : SqlDataSource
    {
        public bool WriteToSqlDb(string table, params string[] paramters)
        {
            using (SqlConnection connection = new SqlConnection(this.GetConnectionBuilder(string.Empty).ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = connection.CreateCommand())
                {
                    if (table == Constants.Equipment)
                    {
                        command.Parameters.Add("@equipmentId", SqlDbType.BigInt).Value = paramters[0];
                        command.CommandText = "INSERT INTO [dbo].[Equipment] (EquipmentId, Description, ObjectType, Manufacturer, ModelNumber, FunctionalGeoLocationID, SystemStatus, UserStatus, IsActive, CreatedBy, CreatedDateTime, LastUpdatedBy, LastUpdatedDateTime) " +
                                                            "VALUES(@equipmentId, 'TestEquipment', 'TestObjectType', 'TestManufacturer', 'TestModelName', 150, 'INST', 'TEST', 1, 'VG', GETDATE(), 'VG', GETDATE())";
                    }
                    else if (table == Constants.BeaconEquipment)
                    {
                        command.Parameters.Add("@beaconId", SqlDbType.NVarChar).Value = paramters[0];
                        command.Parameters.Add("@equipmentId", SqlDbType.BigInt).Value = paramters[1];
                        command.Parameters.Add("@isActive", SqlDbType.Bit).Value = paramters[2];
                        command.CommandText = "INSERT INTO [dbo].[BeaconEquipment] (BeaconId, EquipmentId, IsActive, CreatedBy, CreatedDateTime, LastUpdatedBy, LastUpdatedDateTime) VALUES(@beaconId, @equipmentId, @isActive, 'VG', GETDATE(), 'VG', GETDATE())";
                    }

                    command.CommandType = CommandType.Text;
                    if (command.ExecuteNonQuery() > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }

        public void DeleteFromSqlDb(string table, params string[] paramters)
        {
            using (SqlConnection connection = new SqlConnection(this.GetConnectionBuilder(string.Empty).ConnectionString))
            {
                connection.Open();
                using (SqlCommand command = connection.CreateCommand())
                {
                    if (table == Constants.Equipment)
                    {
                        command.Parameters.Add("@equipmentId", SqlDbType.BigInt).Value = paramters[0];
                        command.CommandText = "DELETE FROM [dbo].[Equipment] WHERE EquipmentId = @equipmentId";
                    }
                    else if (table == Constants.BeaconEquipment)
                    {
                        command.Parameters.Add("@beaconId", SqlDbType.NVarChar).Value = paramters[0];
                        command.Parameters.Add("@equipmentId", SqlDbType.BigInt).Value = paramters[1];
                        command.CommandText = "DELETE FROM [dbo].[BeaconEquipment] WHERE BeaconId = @beaconId AND EquipmentId = @equipmentId";
                    }
                    else if (table == Constants.EquipmentLocation)
                    {
                        command.Parameters.Add("@beaconEquipmentId", SqlDbType.BigInt).Value = paramters[0];
                        command.CommandText = "DELETE FROM [dbo].[EquipmentLocation] WHERE BeaconEquipmentId = @beaconEquipmentId";
                    }
                    else if (table == Constants.Antenna)
                    {
                        command.Parameters.Add("@antennaId", SqlDbType.NVarChar).Value = paramters[0];
                        command.CommandText = "DELETE FROM [dbo].[Antenna] WHERE Id = @antennaId";
                    }

                    command.CommandType = CommandType.Text;
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
