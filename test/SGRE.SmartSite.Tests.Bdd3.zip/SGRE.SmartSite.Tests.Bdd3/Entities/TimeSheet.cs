﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SGRE.SmartSite.Tests.Bdd.Entities
{
   
    public class TimeSheet
    {
        public class AddActivityTaskDetail
        {
            public string startingTime { get; set; }
            public string finishTime { get; set; }
            public string staff { get; set; }
            public string totalHours { get; set; }
            public string mainCraneTime { get; set; }
            public string tn500CraneTime { get; set; }
            public string auxCraneTime { get; set; }
            public bool isNightShift { get; set; }
            public bool isComplete { get; set; }
            public bool isExtrawork { get; set; }
            public bool isActive { get; set; }
        }

        public class AddActivityDeviationDetail
        {
            public int deviationId { get; set; }
            public string nccId { get; set; }
            public string startingTime { get; set; }
            public string endTime { get; set; }
            public string fteTime { get; set; }
            public int mainCraneTime { get; set; }
            public int tn500CraneTime { get; set; }
            public string auxCraneTime { get; set; }
            public string comments { get; set; }
            public string impactedResourceId { get; set; }
            public List<object> files { get; set; }
            public bool isActive { get; set; }
            public string fileIdentifier { get; set; }
        }
        public class AddTimeSheet
        {
            public int projectConfigTowerMappingId { get; set; }
            public string phaseId { get; set; }
            public string taskId { get; set; }
            public List<AddActivityTaskDetail> addActivityTaskDetails { get; set; }
            public List<AddActivityDeviationDetail> addActivityDeviationDetails { get; set; }
            public int id { get; set; }
            public bool edit { get; set; }
            public bool expand { get; set; }
            public int projectConfigDetailsId { get; set; }
            public string date { get; set; }
            public string projectId { get; set; }
            public int projectTimesheetId { get; set; }
            public string subContractorId { get; set; }
        }

        //Get TimeSheetConfig Tower details
        public class TimeSheetConfigTowerDetails
        {
            public int id { get; set; }
            public object projectConfigDetails { get; set; }
            public int projectConfigDetailsId { get; set; }
            public object project { get; set; }
            public int projectId { get; set; }
            public int tower { get; set; }
            public object subContractorResourceTowerMapping { get; set; }
            public string createdBy { get; set; }
            public DateTime createdDateTime { get; set; }
            public object modifiedBy { get; set; }
            public object modifiedDateTime { get; set; }
        }

        public class Root
        {
            public int activityId { get; set; }
        }

        //
        public class ProjectConfigTowerMapping
        {
            public int id { get; set; }
            public object projectConfigDetails { get; set; }
            public int projectConfigDetailsId { get; set; }
            public object project { get; set; }
            public int projectId { get; set; }
            public int tower { get; set; }
            public object subContractorResourceTowerMapping { get; set; }
            public string createdBy { get; set; }
            public DateTime createdDateTime { get; set; }
            public object modifiedBy { get; set; }
            public object modifiedDateTime { get; set; }
        }

        public class Phase
        {
            public int id { get; set; }
            public string phaseName { get; set; }
            public string createdBy { get; set; }
            public DateTime createdDateTime { get; set; }
            public object modifiedBy { get; set; }
            public object modifiedDateTime { get; set; }
        }

        public class TaskDetails
        {
            public int id { get; set; }
            public string taskName { get; set; }
            public object taskDesc { get; set; }
            public object masterPhase { get; set; }
            public int phaseId { get; set; }
            public string createdBy { get; set; }
            public DateTime createdDateTime { get; set; }
            public object modifiedBy { get; set; }
            public object modifiedDateTime { get; set; }
        }

        public class ActivityTaskDetail
        {
            public int id { get; set; }
            public object activityDetails { get; set; }
            public int activityDetailsId { get; set; }
            public string startingTime { get; set; }
            public string finishTime { get; set; }
            public int staff { get; set; }
            public int totalHours { get; set; }
            public int mainCraneTime { get; set; }
            public int tn500CraneTime { get; set; }
            public int auxCraneTime { get; set; }
            public bool isNightShift { get; set; }
            public bool isComplete { get; set; }
            public bool isExtrawork { get; set; }
            public string createdBy { get; set; }
            public DateTime createdDateTime { get; set; }
            public object modifiedBy { get; set; }
            public object modifiedDateTime { get; set; }
        }

        public class MasterDeviation
        {
            public int id { get; set; }
            public string type { get; set; }
            public string subType { get; set; }
            public string detail { get; set; }
            public string createdBy { get; set; }
            public DateTime createdDateTime { get; set; }
            public object modifiedBy { get; set; }
            public object modifiedDateTime { get; set; }
        }

        public class ImpactedResource
        {
            public int id { get; set; }
            public string impactedResourceName { get; set; }
            public string createdBy { get; set; }
            public DateTime createdDateTime { get; set; }
            public object modifiedBy { get; set; }
            public object modifiedDateTime { get; set; }
        }

        public class ActivityDeviationDetail
        {
            public int id { get; set; }
            public object activityDetails { get; set; }
            public int activityDetailsId { get; set; }
            public MasterDeviation masterDeviation { get; set; }
            public int deviationId { get; set; }
            public string nccId { get; set; }
            public string startingTime { get; set; }
            public string endTime { get; set; }
            public int fteTime { get; set; }
            public int mainCraneTime { get; set; }
            public int tn500CraneTime { get; set; }
            public int auxCraneTime { get; set; }
            public string comments { get; set; }
            public ImpactedResource impactedResource { get; set; }
            public int impactedResourceId { get; set; }
            public object impactedParty { get; set; }
            public object impactedPartyId { get; set; }
            public object originatingParty { get; set; }
            public object originatingPartyId { get; set; }
            public object correctiveAction { get; set; }
            public object correctiveActionId { get; set; }
            public string createdBy { get; set; }
            public DateTime createdDateTime { get; set; }
            public object modifiedBy { get; set; }
            public object modifiedDateTime { get; set; }
        }

        public class TimeSheetActivityDetails
        {
            public int id { get; set; }
            public object projectTimesheet { get; set; }
            public int projectTimesheetId { get; set; }
            public ProjectConfigTowerMapping projectConfigTowerMapping { get; set; }
            public int projectConfigTowerMappingId { get; set; }
            public Phase phase { get; set; }
            public int phaseId { get; set; }
            public TaskDetails taskdetails { get; set; }
            public int taskId { get; set; }
            public object isStatusValid { get; set; }
            public object comments { get; set; }
            public object validatedBy { get; set; }
            public List<ActivityTaskDetail> activityTaskDetails { get; set; }
            public List<ActivityDeviationDetail> activityDeviationDetails { get; set; }
            public string createdBy { get; set; }
            public DateTime createdDateTime { get; set; }
            public object modifiedBy { get; set; }
            public object modifiedDateTime { get; set; }
        }

        public class TimesheetPrevioushrs
        {
            public int totalHrs { get; set; }
            public int mainCraneHrs { get; set; }
            public int auxCraneHrs { get; set; }
            public int tn500CraneHrs { get; set; }
            public bool isDeviationPresent { get; set; }
        }

        //Get timesheet id by project id and date
        public class ProjectTimesheet
        {
            public int id { get; set; }
            public int projectId { get; set; }
            public string status { get; set; }
            public string timesheetSubmittedOn { get; set; }
            public string timesheetValidatedOn { get; set; }
            public string timesheetSubmittedBy { get; set; }
        }

        public class Activity
        {
            public int activityDetailId { get; set; }
            public string name { get; set; }
            public object status { get; set; }
            public int tower { get; set; }
            public string phase { get; set; }
            public string task { get; set; }
            public object siteManagerComment { get; set; }
            public string fteHours { get; set; }
            public string mainCraneHours { get; set; }
            public string t500CraneHours { get; set; }
            public string auxCraneHours { get; set; }
            public string isNightShift { get; set; }
            public string isComplete { get; set; }
            public string isDeviation { get; set; }
            public string isExtraWork { get; set; }
            public object startingTime { get; set; }
            public object finishTime { get; set; }
            public int staff { get; set; }
        }

        public class TimesheetDetails
        {
            public ProjectTimesheet projectTimesheet { get; set; }
            public List<Activity> activities { get; set; }
        }

        //Get timesheet activity details by Activity id 
        public class TaskDetail
        {
            public string fteHours { get; set; }
            public string mainCraneHours { get; set; }
            public string t500CraneHours { get; set; }
            public string auxCraneHours { get; set; }
            public string isNightShift { get; set; }
            public string isComplete { get; set; }
            public object isDeviation { get; set; }
            public string isExtraWork { get; set; }
            public string startingTime { get; set; }
            public string finishTime { get; set; }
            public int staff { get; set; }
        }

        public class DeviationDetail
        {
            public int activityDeviationId { get; set; }
            public string cause { get; set; }
            public string subCause { get; set; }
            public string detail { get; set; }
            public string fteHours { get; set; }
            public string nccId { get; set; }
            public string mainCraneHours { get; set; }
            public string auxCraneHours { get; set; }
            public string tn500CraneHours { get; set; }
            public int totalHours { get; set; }
            public string impactedResource { get; set; }
            public string comment { get; set; }
            public object impactedParty { get; set; }
            public object originalParty { get; set; }
            public object correctiveAction { get; set; }
            public object impactedPartyName { get; set; }
            public object originalPartyName { get; set; }
            public object correctiveActionName { get; set; }
        }

        public class TimesheetDetailsByActivityId
        {
            public int activityId { get; set; }
            public int wtg { get; set; }
            public string phase { get; set; }
            public string task { get; set; }
            public int configTowerMappingId { get; set; }
            public int projectConfigDetailsId { get; set; }
            public int phaseId { get; set; }
            public int taskId { get; set; }
            public string comments { get; set; }
            public bool isValid { get; set; }
            public List<TaskDetail> taskDetails { get; set; }
            public List<DeviationDetail> deviationDetails { get; set; }
        }

        //Get Timesheet report
        public class Effort
        {
            public int timesheetId { get; set; }
            public string timesheetDate { get; set; }
            public string subContractor { get; set; }
            public string humanEffort { get; set; }
            public string nightShift { get; set; }
            public string mainCraine { get; set; }
            public string t500Crane { get; set; }
            public string auxCrane { get; set; }
            public string deviations { get; set; }
            public string status { get; set; }
        }

        public class TimesheetReport
        {
            public string date { get; set; }
            public List<Effort> efforts { get; set; }
        }

        //Update Timesheet
        public class AddActivityTaskDetailUpdate
        {
            public int activityDetailsId { get; set; }
            public int id { get; set; }
            public string startingTime { get; set; }
            public string finishTime { get; set; }
            public int staff { get; set; }
            public int totalHours { get; set; }
            public int mainCraneTime { get; set; }
            public int tn500CraneTime { get; set; }
            public int auxCraneTime { get; set; }
            public bool isNightShift { get; set; }
            public bool isComplete { get; set; }
            public bool isExtrawork { get; set; }
            public bool isActive { get; set; }
        }

        public class AddActivityDeviationDetailUpdate
        {
            public int id { get; set; }
            public int activityDetailsId { get; set; }
            public int deviationId { get; set; }
            public string nccId { get; set; }
            public string startingTime { get; set; }
            public string endTime { get; set; }
            public int fteTime { get; set; }
            public int mainCraneTime { get; set; }
            public int tn500CraneTime { get; set; }
            public int auxCraneTime { get; set; }
            public string comments { get; set; }
            public int impactedResourceId { get; set; }
            public object subCause { get; set; }
            public object detail { get; set; }
            public object impactedResourceName { get; set; }
            public string fileIdentifier { get; set; }
            public object fileNames { get; set; }
            public bool isActive { get; set; }
        }

        public class UpdateTimesheet
        {
            public bool expand { get; set; }
            public int id { get; set; }
            public string projectId { get; set; }
            public string date { get; set; }
            public int projectTimesheetId { get; set; }
            public int projectConfigTowerMappingId { get; set; }
            public int phaseId { get; set; }
            public int taskId { get; set; }
            public string subContractorId { get; set; }
            public List<AddActivityTaskDetailUpdate> addActivityTaskDetails { get; set; }
            public List<AddActivityDeviationDetailUpdate> addActivityDeviationDetails { get; set; }
            public int projectConfigDetailsId { get; set; }
            public object comments { get; set; }
            public bool edit { get; set; }
        }

        //Get activity details for edit
        public class Getactivityforedit
        {
            public int id { get; set; }
            public int projectId { get; set; }
            public object date { get; set; }
            public int projectTimesheetId { get; set; }
            public int projectConfigTowerMappingId { get; set; }
            public int phaseId { get; set; }
            public int taskId { get; set; }
            public object subContractorId { get; set; }
            public List<AddActivityTaskDetailUpdate> addActivityTaskDetails { get; set; }
            public List<AddActivityDeviationDetailUpdate> addActivityDeviationDetails { get; set; }
            public int projectConfigDetailsId { get; set; }
            public object comments { get; set; }
        }


        //Timesheet submit for validation
        public class SubmitForValidation
        {
        }

        //Validate Timesheet
        public class UpdateActivityDeviationDetailModel
        {
            public int activityDeviationDetailId { get; set; }
            public string impactedPartyId { get; set; }
            public string originatingPartyId { get; set; }
            public int correctiveActionId { get; set; }
        }

        public class ValidateTimesheet
        {
            public int activityDetailsId { get; set; }
            public bool isValid { get; set; }
            public int actedBy { get; set; }
            public string comment { get; set; }
            public List<UpdateActivityDeviationDetailModel> updateActivityDeviationDetailModels { get; set; }
        }

        //Timesheet submit for review
        public class SubmitForReview
        {
        }

        //Timesheet export
        public class ExportTimesheet
        {
            public string fileType { get; set; }
            public List<int> timesheetIds { get; set; }
        }
    }
}
