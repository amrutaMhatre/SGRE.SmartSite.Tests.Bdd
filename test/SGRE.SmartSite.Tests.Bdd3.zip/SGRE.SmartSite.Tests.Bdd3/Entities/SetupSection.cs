﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SGRE.SmartSite.Tests.Bdd.Entities
{
   
    public class WTGModel
        {
            [JsonProperty("_1")]
            public string _1 { get; set; }
            [JsonProperty("_2")]
            public string _2 { get; set; }
            [JsonProperty("_3")]
            public string _3 { get; set; }
            [JsonProperty("_4")]
            public string _4 { get; set; }
            [JsonProperty("_5")]
            public string _5 { get; set; }
            [JsonProperty("_6")]
            public string _6 { get; set; }
            [JsonProperty("_7")]
            public string _7 { get; set; }
            [JsonProperty("_8")]
            public string _8 { get; set; }
            [JsonProperty("_9")]
            public string _9 { get; set; }
            [JsonProperty("_10")]
            public string _10 { get; set; }
            [JsonProperty("_11")]
            public string _11 { get; set; }
            [JsonProperty("_12")]
            public string _12 { get; set; }
            [JsonProperty("_13")]
            public string _13 { get; set; }
            [JsonProperty("_14")]
            public string _14 { get; set; }
            [JsonProperty("_15")]
            public string _15 { get; set; }
            [JsonProperty("_16")]
            public string _16 { get; set; }
        }

        public class TowerHeightM
        {
            [JsonProperty("_1")]
            public string _1 { get; set; }
            [JsonProperty("_2")]
            public string _2 { get; set; }
            [JsonProperty("_3")]
            public string _3 { get; set; }
            [JsonProperty("_4")]
            public string _4 { get; set; }
            [JsonProperty("_5")]
            public string _5 { get; set; }
            [JsonProperty("_6")]
            public string _6 { get; set; }
            [JsonProperty("_7")]
            public string _7 { get; set; }
        }

        public class Towersections
        {
            [JsonProperty("_1")]
            public string _1 { get; set; }
            [JsonProperty("_2")]
            public string _2 { get; set; }
            [JsonProperty("_3")]
            public string _3 { get; set; }
            [JsonProperty("_4")]
            public string _4 { get; set; }
            [JsonProperty("_5")]
            public string _5 { get; set; }
            [JsonProperty("_6")]
            public string _6 { get; set; }
            [JsonProperty("_7")]
            public string _7 { get; set; }
            [JsonProperty("_8")]
            public string _8 { get; set; }
            [JsonProperty("_9")]
            public string _9 { get; set; }
            [JsonProperty("_10")]
            public string _10 { get; set; }
            [JsonProperty("_11")]
            public string _11 { get; set; }
            [JsonProperty("_12")]
            public string _12 { get; set; }
        }

        public class InstallationStrategy
        {
            [JsonProperty("_1")]
            public string _1 { get; set; }
            [JsonProperty("_2")]
            public string _2 { get; set; }
            [JsonProperty("_3")]
            public string _3 { get; set; }
            [JsonProperty("_4")]
            public string _4 { get; set; }
            [JsonProperty("_5")]
            public string _5 { get; set; }
        }

        public class AssemblyPhases
        {
            [JsonProperty("_1")]
            public string _1 { get; set; }
            [JsonProperty("_2")]
            public string _2 { get; set; }
            [JsonProperty("_3")]
            public string _3 { get; set; }
            [JsonProperty("_4")]
            public string _4 { get; set; }
            [JsonProperty("_5")]
            public string _5 { get; set; }
            [JsonProperty("_6")]
            public string _6 { get; set; }
            [JsonProperty("_7")]
            public string _7 { get; set; }
        }

        public class Nacelletype
        {
            [JsonProperty("_1")]
            public string _1 { get; set; }
            [JsonProperty("_2")]
            public string _2 { get; set; }
            [JsonProperty("_3")]
            public string _3 { get; set; }
        }

        public class BladeType
        {
            [JsonProperty("_1")]
            public string _1 { get; set; }
            [JsonProperty("_2")]
            public string _2 { get; set; }
        }

        public class DTType
        {
            [JsonProperty("_1")]
            public string _1 { get; set; }
            [JsonProperty("_2")]
            public string _2 { get; set; }
            [JsonProperty("_3")]
            public string _3 { get; set; }
        }

        public class ElevatorType
        {
        [JsonProperty("_1")]
        public string _1 { get; set; }
        [JsonProperty("_2")]
        public string _2 { get; set; }
        [JsonProperty("_3")]
        public string _3 { get; set; }
        [JsonProperty("_4")]
        public string _4 { get; set; }
    }

        public class Towertighteningprocesstype
        {
            [JsonProperty("_1")]
            public string _1 { get; set; }
            [JsonProperty("_2")]
            public string _2 { get; set; }
        }

        public class Gearboxtype
        {
            [JsonProperty("_1")]
            public string _1 { get; set; }
            [JsonProperty("_2")]
            public string _2 { get; set; }
            [JsonProperty("_3")]
            public string _3 { get; set; }
        }

        public class AdditionalWTGFeatures
        {
            [JsonProperty("_1")]
            public string _1 { get; set; }
            [JsonProperty("_2")]
            public string _2 { get; set; }
            [JsonProperty("_3")]
            public string _3 { get; set; }
            [JsonProperty("_4")]
            public string _4 { get; set; }
            [JsonProperty("_5")]
            public string _5 { get; set; }
            [JsonProperty("6")]
            public string _6 { get; set; }
            [JsonProperty("_7")]
            public string _7 { get; set; }
            [JsonProperty("_8")]
            public string _8 { get; set; }
            [JsonProperty("_9")]
            public string _9 { get; set; }
            [JsonProperty("_10")]
            public string _10 { get; set; }
            [JsonProperty("_11")]
            public string _11 { get; set; }
            [JsonProperty("_12")]
            public string _12 { get; set; }
            [JsonProperty("_13")]
            public string _13 { get; set; }
            [JsonProperty("_14")]
            public string _14 { get; set; }
            [JsonProperty("_15")]
            public string _15 { get; set; }
            [JsonProperty("_16")]
            public string _16 { get; set; }
        }

        public class Data
        {
            [JsonProperty("WTGModel")]    
            public WTGModel WTGModel { get; set; }

            [JsonProperty("TowerHeight(m)")]
            public TowerHeightM TowerHeightM { get; set; }

            [JsonProperty("#Towersections")]
            public Towersections Towersections { get; set; }

            [JsonProperty("InstallationStrategy")]
            public InstallationStrategy InstallationStrategy { get; set; }

            [JsonProperty("AssemblyPhases")]
            public AssemblyPhases AssemblyPhases { get; set; }

            [JsonProperty("Nacelletype")]
            public Nacelletype Nacelletype { get; set; }

            [JsonProperty("BladeType")]
            public BladeType BladeType { get; set; }

            [JsonProperty("DTType")]
            public DTType DTType { get; set; }

            [JsonProperty("ElevatorType")]
            public ElevatorType ElevatorType { get; set; }

            [JsonProperty("Towertighteningprocesstype")]
            public Towertighteningprocesstype Towertighteningprocesstype { get; set; }

            [JsonProperty("Gearboxtype")]
            public Gearboxtype Gearboxtype { get; set; }

            [JsonProperty("AdditionalWTGFeatures")]
            public AdditionalWTGFeatures AdditionalWTGFeatures { get; set; }
        }

        public class Setup
        {
            [JsonProperty("data")]
            public Data data { get; set; }
        }

    
}
