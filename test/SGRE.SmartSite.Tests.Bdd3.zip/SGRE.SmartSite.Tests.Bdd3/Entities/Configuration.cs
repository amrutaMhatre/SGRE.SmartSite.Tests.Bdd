﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AntennaData.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace SGRE.SmartSite.Tests.Bdd.Entities
{
    using System;
    using System.Collections.Generic;
    using Newtonsoft.Json;

    public class ProjectConfigDtls
    {
        public int projectId { get; set; }
        public string configName { get; set; }
        public string wtgs { get; set; }
        public string wtgPlatform { get; set; }       
        public string installationStrategy { get; set; }        
        public double towerHeight { get; set; }       
        public string towerSections { get; set; }      
        public string assemblyPhases { get; set; }      
        public string nazzleType { get; set; }       
        public string bladeType { get; set; }      
        public string dtType { get; set; }       
        public string elevatorType { get; set; }       
        public string towerTightingProcessType { get; set; }    
        public string gearboxType { get; set; }      
        public string additionalWtgFeatures { get; set; }     
        public string createdBy { get; set; }     
        public string createdDateTime { get; set; }
        public string modifiedBy { get; set; }
        public string modifiedDateTime { get; set; }
    }

    public class ConfigDtls
    {
        public ProjectConfigDtls projectConfigDtls { get; set; }
    }

    //Create project configuration
    public class ProjectConfig
    {
        public int id { get; set; }
        public object project { get; set; }
        public string configName { get; set; }
        public List<int> wtgs { get; set; }
        public string wtgPlatform { get; set; }
        public string installationStrategy { get; set; }
        public string nazzleType { get; set; }
        public string towerHeight { get; set; }
        public string towerSections { get; set; }
        public string assemblyPhases { get; set; }
        public string elevatorType { get; set; }
        public string bladeType { get; set; }
        public string dtType { get; set; }
        public string towerTightingProcessType { get; set; }
        public string gearboxType { get; set; }
        public string additionalWtgFeatures { get; set; }
        public string projectId { get; set; }
        public string createdBy { get; set; }
        public string createdDateTime { get; set; }
        public string modifiedBy { get; set; }
        public string modifiedDateTime { get; set; }
    }


}
