﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SGRE.SmartSite.Tests.Bdd.Entities
{
   
    /*public class RoadMapPhaseTasks
    {
        [JsonProperty("id")]
        public int id { get; set; }
        [JsonProperty("taskName")]
        public string taskName { get; set; }
        [JsonProperty("taskDesc")]
        public object taskDesc { get; set; }
        [JsonProperty("masterPhase")]
        public object masterPhase { get; set; }
        [JsonProperty("phaseId")]
        public int phaseId { get; set; }
        [JsonProperty("createdBy")]
        public object createdBy { get; set; }
        [JsonProperty("createdDateTime")]
        public DateTime createdDateTime { get; set; }
        [JsonProperty("modifiedBy")]
        public object modifiedBy { get; set; }
        [JsonProperty("modifiedDateTime")]
        public object modifiedDateTime { get; set; }
    }*/

    public class RoadmapTemplate
    {
        public int id { get; set; }
        public int projectId { get; set; }
        public int projectConfigDetailsId { get; set; }
        public int phaseId { get; set; }
        public int taskId { get; set; }
        public string rmCode { get; set; }
        public string rmDesc { get; set; }
        public double mainCraneLeadTime { get; set; }
        public double tn500CraneLeadTime { get; set; }
        public double auxiliaryCraneLeadTime { get; set; }
        public double roadmapLeadTime { get; set; }
        public int technicians { get; set; }
        public double totalManHours { get; set; }
        public object masterPhase { get; set; }
        public object masterTask { get; set; }
        public string createdBy { get; set; }
        public DateTime createdDateTime { get; set; }
        public object modifiedBy { get; set; }
        public object modifiedDateTime { get; set; }
    }

    /*public class RoanMapTemplatePhases
    {
        public int id { get; set; }
        public string phaseName { get; set; }
        public string createdBy { get; set; }
        public DateTime createdDateTime { get; set; }
        public object modifiedBy { get; set; }
        public object modifiedDateTime { get; set; }
    }*/
}
