﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AntennaData.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace SGRE.SmartSite.Tests.Bdd.Entities
{
    using System;
    using System.Collections.Generic;
    using Newtonsoft.Json;

    public class Projects
    {
        [JsonProperty("id")]
        public int Id { get; set; }
        [JsonProperty("projectName")]
        public string ProjectName { get; set; }
        [JsonProperty("projectDesc")]
        public string ProjectDesc { get; set; }
        [JsonProperty("plannedStartDate")]
        public DateTime PlannedStartDate { get; set; }
        [JsonProperty("plannedEndDate")]
        public DateTime PlannedEndDate { get; set; }
        [JsonProperty("projectCreationDate")]
        public DateTime ProjectCreationDate { get; set; }
        [JsonProperty("projectPublicationDate")]
        public DateTime ProjectPublicationDate { get; set; }
        [JsonProperty("sWIActualDate")]
        public DateTime SWIActualDate { get; set; }
        [JsonProperty("sWIContractedDate")]
        public DateTime SWIContractedDate { get; set; }
        [JsonProperty("numberOfWTG")]
        public int NumberOfWTG { get; set; }
        [JsonProperty("projectStatusId")]
        public int ProjectStatusId { get; set; }
        [JsonProperty("regionId")]
        public int RegionId { get; set; }
        [JsonProperty("countryId")]
        public int CountryId { get; set; }
        [JsonProperty("area")]
        public string Area { get; set; }
        [JsonProperty("latitude")]
        public double Latitude { get; set; }
        [JsonProperty("longitude")]
        public double Longitude { get; set; }
        [JsonProperty("countryName")]
        public string CountryName { get; set; }
        [JsonProperty("regionName")]
        public string RegionName { get; set; }
        [JsonProperty("statusName")]
        public string statusName { get; set; }
        [JsonProperty("createdBy")]
        public string CreatedBy { get; set; }
        [JsonProperty("createdDateTime")]
        public DateTime CreatedDateTime { get; set; }
        [JsonProperty("modifiedBy")]
        public string ModifiedBy { get; set; }
        [JsonProperty("modifiedDateTime")]
        public DateTime ModifiedDateTime { get; set; }
        [JsonProperty("statusCode")]        
        public int StatusCode { get; set; }
    }

    public class Value
    {
        [JsonProperty("id")]
        public int Id { get; set; }
        [JsonProperty("projectName")]
        public string ProjectName { get; set; }
        [JsonProperty("projectDesc")]
        public string ProjectDesc { get; set; }
        [JsonProperty("plannedStartDate")]
        public DateTime PlannedStartDate { get; set; }
        [JsonProperty("plannedEndDate")]
        public DateTime PlannedEndDate { get; set; }
        [JsonProperty("projectCreationDate")]
        public DateTime ProjectCreationDate { get; set; }
        [JsonProperty("projectPublicationDate")]
        public DateTime? ProjectPublicationDate { get; set; }
        [JsonProperty("sWIActualDate")]
        public DateTime? SWIActualDate { get; set; }
        [JsonProperty("sWIContractedDate")]
        public DateTime SWIContractedDate { get; set; }
        [JsonProperty("numberOfWTG")]
        public int NumberOfWTG { get; set; }
        [JsonProperty("projectStatusId")]
        public int ProjectStatusId { get; set; }
        [JsonProperty("regionId")]
        public int RegionId { get; set; }
        [JsonProperty("countryId")]
        public int CountryId { get; set; }
        [JsonProperty("area")]
        public string Area { get; set; }
        [JsonProperty("latitude")]
        public double? Latitude { get; set; }
        [JsonProperty("longitude")]
        public double? Longitude { get; set; }
        [JsonProperty("countryName")]
        public string CountryName { get; set; }
        [JsonProperty("regionName")]
        public string RegionName { get; set; }
        [JsonProperty("statusName")]
        public string statusName { get; set; }
        [JsonProperty("createdBy")]
        public object CreatedBy { get; set; }
        [JsonProperty("createdDateTime")]
        public DateTime CreatedDateTime { get; set; }
        [JsonProperty("modifiedBy")]
        public object ModifiedBy { get; set; }
        [JsonProperty("modifiedDateTime")]
        public object ModifiedDateTime { get; set; }
    }

    public class Root
    {
        [JsonProperty("@odata.context")]
        public string OdataContext { get; set; }
        public List<Value> value { get; set; }
    }


}
