﻿// <copyright file="Constants.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>

namespace SGRE.SmartSite.Tests.Bdd.Entities
{
    public static class Constants
    {
        public const string Equipment = nameof(Equipment);
        public const string FunctionalLocation = nameof(FunctionalLocation);
        public const string Category = nameof(Category);
        public const string BeaconEquipment = nameof(BeaconEquipment);
        public const string Antenna = nameof(Antenna);
        public const string EquipmentLocation = nameof(EquipmentLocation);
        public const string AdfRunLog = nameof(AdfRunLog);
        public const string Delimeter = ",";
        public const string AdlFilePath = "{0}?directory=/Aalborg/TnTTE/SAPECC/{1}/{2}/{3}/{4}/&recursive=true&resource=filesystem";
        public const string DsAdlFilePath = "raw?directory=/Aalborg/TnTTE/{0}/{1}/{2}/{3}/&recursive=true&resource=filesystem";
        public const string DsMonthlyAdlFilePath = "raw?directory=/Aalborg/TnTTE/{0}/{1}/{2}/&recursive=true&resource=filesystem";
        public const string EquipmentMasterEmptyFile = nameof(EquipmentMasterEmptyFile);
        public const string FunctionalLocationMasterEmptyFile = nameof(FunctionalLocationMasterEmptyFile);
        public const string RawEquipmentBeaconMasterData = nameof(RawEquipmentBeaconMasterData);
        public const string TrustedEquipmentBeaconMasterData = nameof(TrustedEquipmentBeaconMasterData);
        public const string RawFunctionalLocationMasterData = nameof(RawFunctionalLocationMasterData);
        public const string TrustedFunctionalLocationMasterData = nameof(TrustedFunctionalLocationMasterData);
        public const string StageEquipmentBeaconMasterData = nameof(StageEquipmentBeaconMasterData);
        public const string StageFunctionalLocationMasterData = nameof(StageFunctionalLocationMasterData);
        public const string ReportFunctionalLocationMasterData = nameof(ReportFunctionalLocationMasterData);
        public const string ReportEquipmentMasterData = nameof(ReportEquipmentMasterData);
        public const string ReportCategoryMasterData = nameof(ReportCategoryMasterData);
        public const string ReportBeaconEquipmentMasterData = nameof(ReportBeaconEquipmentMasterData);
        public const string TimeStamp01 = nameof(TimeStamp01);
        public const string TimeStamp02 = nameof(TimeStamp02);
        public const string TimeStamp03 = nameof(TimeStamp03);
        public const string UpdatedTimeStamp02 = nameof(UpdatedTimeStamp02);
        public const string UpdatedTimeStamp03 = nameof(UpdatedTimeStamp03);
        public const string TimeStamp04 = nameof(TimeStamp04);
        public const string TimeStamp05 = nameof(TimeStamp05);
        public const string TimeStamp06 = nameof(TimeStamp06);
        public const string AntennaTimeStamp01 = nameof(AntennaTimeStamp01);
        public const string AntennaTimeStamp02 = nameof(AntennaTimeStamp02);
        public const string AntennaTimeStamp03 = nameof(AntennaTimeStamp03);
        public const string AntennaTimeStamp04 = nameof(AntennaTimeStamp04);
        public const string AntennaTimeStamp05 = nameof(AntennaTimeStamp05);
        public const string AntennaTimeStamp06 = nameof(AntennaTimeStamp06);
        public const string AntennaUpdatedTimeStamp06 = nameof(AntennaUpdatedTimeStamp06);
        public static readonly string FilePath = @"TestData\SampleFile.txt";
    }
}
