﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGRE.SmartSite.Tests.Bdd.Entities
{
    using System;
    using System.Collections.Generic;
    using Newtonsoft.Json;
    class SaveFileDataPayload
    {
        public string fRoadmapTemplate { get; set; }
        public string fileType { get; set; }
        public string fileLocation { get; set; }
        public int projectId { get; set; }
        public int ConfigId { get; set; }
    }
}
