﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SGRE.SmartSite.Tests.Bdd.Entities
{
    


    public class ProjectData
    {
        [JsonProperty("Id")]
        public int Id { get; set; }
        [JsonProperty("ProjectName")]
        public string ProjectName { get; set; }
        [JsonProperty("ProjectDesc")]
        public string ProjectDesc { get; set; }
        [JsonProperty("PlannedStartDate")]
        public DateTime PlannedStartDate { get; set; }
        [JsonProperty("PlannedEndDate")]
        public DateTime PlannedEndDate { get; set; }
        [JsonProperty("ProjectCreationDate")]
        public DateTime ProjectCreationDate { get; set; }
        [JsonProperty("ProjectPublicationDate")]
        public DateTime? ProjectPublicationDate { get; set; }
        [JsonProperty("SWIContractedDate")]
        public DateTime? SWIActualDate { get; set; }
        [JsonProperty("NumberOfWTG")]
        public int NumberOfWTG { get; set; }
        [JsonProperty("ProjectStatusId")]
        public int ProjectStatusId { get; set; }
        [JsonProperty("RegionId")]
        public int RegionId { get; set; }
        [JsonProperty("CountryId")]
        public int CountryId { get; set; }
        [JsonProperty("Area")]
        public string Area { get; set; }
        [JsonProperty("Latitude")]
        public double? Latitude { get; set; }
        [JsonProperty("Longitude")]
        public double? Longitude { get; set; }
        [JsonProperty("CountryName")]
        public string CountryName { get; set; }
        [JsonProperty("RegionName")]
        public string RegionName { get; set; }
        [JsonProperty("statusName")]
        public string statusName { get; set; }
        [JsonProperty("CreatedBy")]
        public object CreatedBy { get; set; }
        [JsonProperty("CreatedDateTime")]
        public DateTime CreatedDateTime { get; set; }
        [JsonProperty("ModifiedBy")]
        public object ModifiedBy { get; set; }
        [JsonProperty("ModifiedDateTime ")]
        public object ModifiedDateTime { get; set; }
        [JsonProperty("Country")]
        public object Country { get; set; }
        [JsonProperty("Region")]
        public object Region { get; set; }
        [JsonProperty("ProjectStatus")]
        public object ProjectStatus { get; set; }
    }

    public class ProjectsBySearch
    {
        [JsonProperty("@odata.context")]
        public string OdataContext { get; set; }

        [JsonProperty("@odata.count")]
        public int OdataCount { get; set; }
        public List<ProjectData> value { get; set; }
    }


}
