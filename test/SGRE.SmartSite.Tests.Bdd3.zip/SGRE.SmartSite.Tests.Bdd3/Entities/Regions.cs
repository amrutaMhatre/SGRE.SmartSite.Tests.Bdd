﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SGRE.SmartSite.Tests.Bdd.Entities
{
   
    /*public class Regions
    {
        [JsonProperty("id")]
        public int id { get; set; }
        [JsonProperty("regionName")]
        public string regionName { get; set; }
        [JsonProperty("createdBy")]
        public object createdBy { get; set; }
        [JsonProperty("createdDateTime")]
        public DateTime createdDateTime { get; set; }
        [JsonProperty("modifiedBy")]
        public object modifiedBy { get; set; }
        [JsonProperty("modifiedDateTime")]
        public object modifiedDateTime { get; set; }
        [JsonProperty("statusCode")]
        public int StatusCode { get; set; }

    }*/
}
