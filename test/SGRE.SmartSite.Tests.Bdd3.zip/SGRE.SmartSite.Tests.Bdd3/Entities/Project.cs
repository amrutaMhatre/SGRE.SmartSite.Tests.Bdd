﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SGRE.SmartSite.Tests.Bdd.Entities
{
    public class Project
    {
        //Create new project
        /*public class OtherColleague
        {
            public string name { get; set; }
            public string role { get; set; }
        }

        public class CreateProject
        {
            public string projectName { get; set; }
            public string projectCode { get; set; }
            public string regionId { get; set; }
            public string countryId { get; set; }
            public string latitude { get; set; }
            public string longitude { get; set; }
            public DateTime swiContractedDate { get; set; }
            public DateTime plannedStartDate { get; set; }
            public DateTime plannedEndDate { get; set; }
            public string area { get; set; }
            public string numberOfWTG { get; set; }
            public string projectDesc { get; set; }
            public string customerName { get; set; }
            public List<OtherColleague> otherColleagues { get; set; }
            public int projectStatusId { get; set; }
            public DateTime ProjectCreationDate { get; set; }
        }*/

        public class OtherColleague
        {
            public string name { get; set; }
            public string role { get; set; }
        }

        public class CreateProject
        {
            public string projectName { get; set; }
            public string projectCode { get; set; }
            public DateTime swiContractedDate { get; set; }
            public DateTime plannedStartDate { get; set; }
            public DateTime plannedEndDate { get; set; }
            public string regionId { get; set; }
            public string regionName { get; set; }
            public string countryId { get; set; }
            public string projectManager { get; set; }
            public string siteManager { get; set; }
            public string latitude { get; set; }
            public string longitude { get; set; }
            public string numberOfWTG { get; set; }
            public string projectDesc { get; set; }
            public string area { get; set; }
            public string customerName { get; set; }
            public List<OtherColleague> otherColleagues { get; set; }
            public int projectStatusId { get; set; }
            public DateTime ProjectCreationDate { get; set; }
        }


        //Get newly created project details
        public class AdditionalProjectStaff
        {
            public int id { get; set; }
            public object project { get; set; }
            public int projectId { get; set; }
            public string staffName { get; set; }
            public string role { get; set; }
            public string createdBy { get; set; }
            public DateTime createdDateTime { get; set; }
            public object modifiedBy { get; set; }
            public object modifiedDateTime { get; set; }
        }

        public class CustomerDetails
        {
            public int id { get; set; }
            public object project { get; set; }
            public int projectId { get; set; }
            public string customerName { get; set; }
            public string createdBy { get; set; }
            public DateTime createdDateTime { get; set; }
            public object modifiedBy { get; set; }
            public object modifiedDateTime { get; set; }
        }

        public class NewProject
        {
            public int id { get; set; }
            public string projectName { get; set; }
            public string projectCode { get; set; }
            public string projectDesc { get; set; }
            public DateTime plannedStartDate { get; set; }
            public DateTime plannedEndDate { get; set; }
            public DateTime projectCreationDate { get; set; }
            public object projectPublicationDate { get; set; }
            public object swiActualDate { get; set; }
            public DateTime swiContractedDate { get; set; }
            public int numberOfWTG { get; set; }
            public object projectStatus { get; set; }
            public int projectStatusId { get; set; }
            public object region { get; set; }
            public int regionId { get; set; }
            public object country { get; set; }
            public int countryId { get; set; }
            public string area { get; set; }
            public int latitude { get; set; }
            public int longitude { get; set; }
            public object countryName { get; set; }
            public object regionName { get; set; }
            public object statusName { get; set; }
            public List<AdditionalProjectStaff> additionalProjectStaff { get; set; }
            public CustomerDetails customerDetails { get; set; }
            public string createdBy { get; set; }
            public DateTime createdDateTime { get; set; }
            public object modifiedBy { get; set; }
            public object modifiedDateTime { get; set; }
        }

        public class CreatedProjectDetails
        {
            public NewProject project { get; set; }
        }

        //Get project list
        public class Value
        {
            public int Id { get; set; }
            public string ProjectName { get; set; }
            public string ProjectCode { get; set; }
            public string ProjectDesc { get; set; }
            public DateTime PlannedStartDate { get; set; }
            public DateTime PlannedEndDate { get; set; }
            public DateTime ProjectCreationDate { get; set; }
            public object ProjectPublicationDate { get; set; }
            public object SWIActualDate { get; set; }
            public DateTime SWIContractedDate { get; set; }
            public int NumberOfWTG { get; set; }
            public int ProjectStatusId { get; set; }
            public int RegionId { get; set; }
            public int CountryId { get; set; }
            public string Area { get; set; }
            public double? Latitude { get; set; }
            public double? Longitude { get; set; }
            public string CountryName { get; set; }
            public string RegionName { get; set; }
            public string StatusName { get; set; }
            public string CustomerName { get; set; }
            public List<OtherColleague> OtherColleagues { get; set; }
        }

        public class ProjectList
        {
            [JsonProperty("@odata.context")]
            public string OdataContext { get; set; }
            public List<Value> value { get; set; }
        }

        //Get project details by id
        public class OtherColleagueData
        {
            public string name { get; set; }
            public string role { get; set; }
            public int id { get; set; }
        }

        public class ProjectDetailsById
        {
            public int id { get; set; }
            public string projectName { get; set; }
            public string projectCode { get; set; }
            public string projectDesc { get; set; }
            public DateTime plannedStartDate { get; set; }
            public DateTime plannedEndDate { get; set; }
            public DateTime projectCreationDate { get; set; }
            public object projectPublicationDate { get; set; }
            public object swiActualDate { get; set; }
            public DateTime swiContractedDate { get; set; }
            public int numberOfWTG { get; set; }
            public int projectStatusId { get; set; }
            public int regionId { get; set; }
            public int countryId { get; set; }
            public string area { get; set; }
            public int latitude { get; set; }
            public int longitude { get; set; }
            public string countryName { get; set; }
            public string regionName { get; set; }
            public string statusName { get; set; }
            public string customerName { get; set; }
            public string projectManager { get; set; }
            public string siteManager { get; set; }
            public object commissioningLead { get; set; }
            public List<OtherColleagueData> otherColleaguesdata { get; set; }
            public object projectStatus { get; set; }
            public object region { get; set; }
            public object country { get; set; }
        }

        //Get details of MasterDropdown
        public class WtgModel
        {
            public string _1 { get; set; }
            public string _2 { get; set; }
            public string _3 { get; set; }
            public string _4 { get; set; }
            public string _5 { get; set; }
            public string _6 { get; set; }
            public string _7 { get; set; }
            public string _8 { get; set; }
            public string _9 { get; set; }
            public string _10 { get; set; }
            public string _11 { get; set; }
            public string _12 { get; set; }
            public string _13 { get; set; }
            public string _14 { get; set; }
            public string _15 { get; set; }
            public string _16 { get; set; }
        }

        public class TowerHeight
        {
            public string _1 { get; set; }
            public string _2 { get; set; }
            public string _3 { get; set; }
            public string _4 { get; set; }
            public string _5 { get; set; }
            public string _6 { get; set; }
            public string _7 { get; set; }
        }

        public class TowerSections
        {
            public string _1 { get; set; }
            public string _2 { get; set; }
            public string _3 { get; set; }
            public string _4 { get; set; }
            public string _5 { get; set; }
            public string _6 { get; set; }
            public string _7 { get; set; }
            public string _8 { get; set; }
            public string _9 { get; set; }
            public string _10 { get; set; }
            public string _11 { get; set; }
            public string _12 { get; set; }
        }

        public class InstallationStrategy
        {
            public string _1 { get; set; }
            public string _2 { get; set; }
            public string _3 { get; set; }
            public string _4 { get; set; }
            public string _5 { get; set; }
        }

        public class AssemblyPhases
        {
            public string _1 { get; set; }
            public string _2 { get; set; }
            public string _3 { get; set; }
            public string _4 { get; set; }
            public string _5 { get; set; }
            public string _6 { get; set; }
            public string _7 { get; set; }
        }

        public class NacelleType
        {
            public string _1 { get; set; }
            public string _2 { get; set; }
            public string _3 { get; set; }
        }

        public class BladeType
        {
            public string _1 { get; set; }
            public string _2 { get; set; }
        }

        public class DtType
        {
            public string _1 { get; set; }
            public string _2 { get; set; }
            public string _3 { get; set; }
        }

        public class ElevatorType
        {
            public string _1 { get; set; }
            public string _2 { get; set; }
            public string _3 { get; set; }
            public string _4 { get; set; }
            public string _5 { get; set; }
        }

        public class TowerTighteningProcessType
        {
            public string _1 { get; set; }
            public string _2 { get; set; }
        }

        public class GearboxType
        {
            public string _1 { get; set; }
            public string _2 { get; set; }
            public string _3 { get; set; }
        }

        public class AdditionalWtgFeatures
        {
            public string _1 { get; set; }
            public string _2 { get; set; }
            public string _3 { get; set; }
            public string _4 { get; set; }
            public string _5 { get; set; }
            public string _6 { get; set; }
            public string _7 { get; set; }
            public string _8 { get; set; }
            public string _9 { get; set; }
            public string _10 { get; set; }
            public string _11 { get; set; }
            public string _12 { get; set; }
            public string _13 { get; set; }
            public string _14 { get; set; }
            public string _15 { get; set; }
            public string _16 { get; set; }
        }

        public class Data
        {
            public WtgModel wtgModel { get; set; }
            public TowerHeight towerHeight { get; set; }
            public TowerSections towerSections { get; set; }
            public InstallationStrategy installationStrategy { get; set; }
            public AssemblyPhases assemblyPhases { get; set; }
            public NacelleType nacelleType { get; set; }
            public BladeType bladeType { get; set; }
            public DtType dtType { get; set; }
            public ElevatorType elevatorType { get; set; }
            public TowerTighteningProcessType towerTighteningProcessType { get; set; }
            public GearboxType gearboxType { get; set; }
            public AdditionalWtgFeatures additionalWtgFeatures { get; set; }
            public string id { get; set; }
            public string dataVersion { get; set; }
            public bool isLatest { get; set; }
            public string versionUpdateDate { get; set; }
            public string _rid { get; set; }
            public string _self { get; set; }
            public string _etag { get; set; }
            public string _attachments { get; set; }
            public string revisionNumber { get; set; }
            public bool isDeleted { get; set; }
            public int _ts { get; set; }
        }

        public class MasterDropdown
        {
            public Data data { get; set; }
        }

        //Project list by search text
        public class ProjectData
        {
            [JsonProperty("Id")]
            public int Id { get; set; }
            [JsonProperty("ProjectName")]
            public string ProjectName { get; set; }
            [JsonProperty("ProjectDesc")]
            public string ProjectDesc { get; set; }
            [JsonProperty("PlannedStartDate")]
            public DateTime PlannedStartDate { get; set; }
            [JsonProperty("PlannedEndDate")]
            public DateTime PlannedEndDate { get; set; }
            [JsonProperty("ProjectCreationDate")]
            public DateTime ProjectCreationDate { get; set; }
            [JsonProperty("ProjectPublicationDate")]
            public DateTime? ProjectPublicationDate { get; set; }
            [JsonProperty("SWIContractedDate")]
            public DateTime? SWIActualDate { get; set; }
            [JsonProperty("NumberOfWTG")]
            public int NumberOfWTG { get; set; }
            [JsonProperty("ProjectStatusId")]
            public int ProjectStatusId { get; set; }
            [JsonProperty("RegionId")]
            public int RegionId { get; set; }
            [JsonProperty("CountryId")]
            public int CountryId { get; set; }
            [JsonProperty("Area")]
            public string Area { get; set; }
            [JsonProperty("Latitude")]
            public double? Latitude { get; set; }
            [JsonProperty("Longitude")]
            public double? Longitude { get; set; }
            [JsonProperty("CountryName")]
            public string CountryName { get; set; }
            [JsonProperty("RegionName")]
            public string RegionName { get; set; }
            [JsonProperty("statusName")]
            public string statusName { get; set; }
            [JsonProperty("CreatedBy")]
            public object CreatedBy { get; set; }
            [JsonProperty("CreatedDateTime")]
            public DateTime CreatedDateTime { get; set; }
            [JsonProperty("ModifiedBy")]
            public object ModifiedBy { get; set; }
            [JsonProperty("ModifiedDateTime ")]
            public object ModifiedDateTime { get; set; }
            [JsonProperty("Country")]
            public object Country { get; set; }
            [JsonProperty("Region")]
            public object Region { get; set; }
            [JsonProperty("ProjectStatus")]
            public object ProjectStatus { get; set; }
        }

        public class ProjectsBySearch
        {
            [JsonProperty("@odata.context")]
            public string OdataContext { get; set; }

            [JsonProperty("@odata.count")]
            public int OdataCount { get; set; }
            public List<ProjectData> value { get; set; }
        }
    }
}