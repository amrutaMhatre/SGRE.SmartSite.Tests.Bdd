﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AntennaData.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace SGRE.SmartSite.Tests.Bdd.Entities
{
    using System;
    using System.Collections.Generic;
    using Newtonsoft.Json;

    //Subcontractor US
    public class ProjectStatus
    {
        public string createdBy { get; set; }
        public DateTime createdDateTime { get; set; }
        public string modifiedBy { get; set; }
        public DateTime modifiedDateTime { get; set; }
        public int id { get; set; }
        public string statusName { get; set; }
    }

    public class Region
    {
        public string createdBy { get; set; }
        public DateTime createdDateTime { get; set; }
        public string modifiedBy { get; set; }
        public DateTime modifiedDateTime { get; set; }
        public int id { get; set; }
        public string regionName { get; set; }
    }

    public class Country
    {
        public string createdBy { get; set; }
        public DateTime createdDateTime { get; set; }
        public string modifiedBy { get; set; }
        public DateTime modifiedDateTime { get; set; }
        public int id { get; set; }
        public string countryName { get; set; }
        public Region region { get; set; }
        public int regionId { get; set; }
    }


    public class Resource
    {
        public string createdBy { get; set; }
        public DateTime createdDateTime { get; set; }
        public string modifiedBy { get; set; }
        public DateTime modifiedDateTime { get; set; }
        public int id { get; set; }
        public string resourceCategory { get; set; }
        public string resourceName { get; set; }
        public List<object> subContractorResourceMapping { get; set; }
    }

    public class SubContractor
    {
        public string createdBy { get; set; }
        public DateTime createdDateTime { get; set; }
        public string modifiedBy { get; set; }
        public DateTime modifiedDateTime { get; set; }
        public int id { get; set; }
        public string subContractorName { get; set; }
        public List<object> subContractorResourceMapping { get; set; }
    }

    public class ProjectConfigDetails
    {
        public string createdBy { get; set; }
        public DateTime createdDateTime { get; set; }
        public string modifiedBy { get; set; }
        public DateTime modifiedDateTime { get; set; }
        public int id { get; set; }
        public Project project { get; set; }
        public int projectId { get; set; }
        public string wtgPlatform { get; set; }
        public string installationStrategy { get; set; }
        public int towerHeight { get; set; }
        public string towerSections { get; set; }
        public string assemblyPhases { get; set; }
        public string nazzleType { get; set; }
        public string bladeType { get; set; }
        public string dtType { get; set; }
        public string elevatorType { get; set; }
        public string towerTightingProcessType { get; set; }
        public string gearboxType { get; set; }
        public string additionalWtgFeatures { get; set; }
        public string configName { get; set; }
        public string roadmapDescriptionFile { get; set; }
    }

    public class ProjectConfigTowerMapping
    {
        public string createdBy { get; set; }
        public DateTime createdDateTime { get; set; }
        public string modifiedBy { get; set; }
        public DateTime modifiedDateTime { get; set; }
        public int id { get; set; }
        public ProjectConfigDetails projectConfigDetails { get; set; }
        public int projectConfigDetailsId { get; set; }
        public Project project { get; set; }
        public int projectId { get; set; }
        public int tower { get; set; }
        public List<object> subContractorResourceTowerMapping { get; set; }
    }

    public class SubContractorResourceTowerMapping
    {
        public string createdBy { get; set; }
        public DateTime createdDateTime { get; set; }
        public string modifiedBy { get; set; }
        public DateTime modifiedDateTime { get; set; }
        public int id { get; set; }
        public int subContractorResourceMappingId { get; set; }
        public ProjectConfigTowerMapping projectConfigTowerMapping { get; set; }
        public int projectConfigTowerMappingId { get; set; }
    }

    public class ResourceTowerMapping
    {
        public string createdBy { get; set; }
        public DateTime createdDateTime { get; set; }
        public string modifiedBy { get; set; }
        public DateTime modifiedDateTime { get; set; }
        public int id { get; set; }
        public int projectId { get; set; }
        public Resource resource { get; set; }
        public int resourceId { get; set; }
        public SubContractor subContractor { get; set; }
        public int subcontractorId { get; set; }
        public string contractType { get; set; }
        public int budgetedHours { get; set; }
        public List<int> towerIds { get; set; }
        public List<SubContractorResourceTowerMapping> subContractorResourceTowerMapping { get; set; }
    }



    //**********************new********************
    //Create SubContractor Resources Mapping
    public class SubConResourceTowerMapping
    {
        public int id { get; set; }
        public int subContractorResourceMappingId { get; set; }
        public int projectConfigTowerMappingId { get; set; }
        public bool isActive { get; set; }
    }
    public class CreateSubContractorResourcesMapping
    {
        public int id { get; set; }
        public string subcontractorId { get; set; }
        public List<int> towerIds { get; set; }
        public string contractType { get; set; }
        public int budgetedHours { get; set; }
        public List<SubConResourceTowerMapping> subConResourceTowerMappings { get; set; }
        public string projectId { get; set; }
        public int resourceId { get; set; }
    }

    //Get SubContractor Resources Mapping details with project id and resource id 
    public class GetSubContractorResourcesMapping
    {
        public int id { get; set; }
        public object project { get; set; }
        public int projectId { get; set; }
        public object resource { get; set; }
        public int resourceId { get; set; }
        public object subContractor { get; set; }
        public int subcontractorId { get; set; }
        public string contractType { get; set; }
        public int budgetedHours { get; set; }
        public List<int> towerIds { get; set; }
        public object subContractorResourceTowerMapping { get; set; }
        public object createdBy { get; set; }
        public DateTime createdDateTime { get; set; }
        public object modifiedBy { get; set; }
        public object modifiedDateTime { get; set; }
    }


    //Get resource mapping details by project id
    public class SubContractorTowerMapping
    {
        public string key { get; set; }
        public List<int> value { get; set; }
    }

    public class ResourceMappingDetails
    {
        public int resourceId { get; set; }
        public string resourceName { get; set; }
        public bool isRequiredForProject { get; set; }
        public List<SubContractorTowerMapping> subContractorTowerMappings { get; set; }
    }

    //Get subcontractor details with project id
    public class SubcontractorDetails
    {
        public int id { get; set; }
        public string subContractorName { get; set; }
        public object subContractorResourceMapping { get; set; }
        public string createdBy { get; set; }
        public DateTime createdDateTime { get; set; }
        public object modifiedBy { get; set; }
        public object modifiedDateTime { get; set; }
    }
}
