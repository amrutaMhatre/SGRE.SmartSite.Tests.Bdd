﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SGRE.SmartSite.Tests.Bdd.Entities
{
    /*public class ProjectDetailsById
    {
        [JsonProperty("id")]
        public int id { get; set; }
        [JsonProperty("projectCode")]
        public string projectCode { get; set; }
        [JsonProperty("projectName")]
        public string projectName { get; set; }
        [JsonProperty("projectDesc")]
        public string projectDesc { get; set; }
        [JsonProperty("plannedStartDate")]
        public DateTime plannedStartDate { get; set; }
        [JsonProperty("plannedEndDate")]
        public DateTime plannedEndDate { get; set; }
        [JsonProperty("projectCreationDate")]
        public DateTime projectCreationDate { get; set; }
        [JsonProperty("projectPublicationDate")]
        public object projectPublicationDate { get; set; }
        [JsonProperty("swiActualDate")]
        public object swiActualDate { get; set; }
        [JsonProperty("swiContractedDate")]
        public DateTime swiContractedDate { get; set; }
        [JsonProperty("numberOfWTG")]
        public int numberOfWTG { get; set; }
        [JsonProperty("projectStatus")]
        public object projectStatus { get; set; }
        [JsonProperty("projectStatusId")]
        public int projectStatusId { get; set; }
        [JsonProperty("region")]
        public object region { get; set; }
        [JsonProperty("regionId")]
        public int regionId { get; set; }
        [JsonProperty("country")]
        public object country { get; set; }
        [JsonProperty("countryId")]
        public int countryId { get; set; }
        [JsonProperty("area")]
        public string area { get; set; }
        [JsonProperty("latitude")]
        public object latitude { get; set; }
        [JsonProperty("longitude")]
        public object longitude { get; set; }
        [JsonProperty("countryName")]
        public string countryName { get; set; }
        [JsonProperty("regionName")]
        public string regionName { get; set; }
        [JsonProperty("statusName")]
        public string statusName { get; set; }
        [JsonProperty("createdBy")]
        public string createdBy { get; set; }
        [JsonProperty("createdDateTime")]
        public DateTime createdDateTime { get; set; }
        [JsonProperty("modifiedBy")]
        public object modifiedBy { get; set; }
        [JsonProperty("modifiedDateTime")]
        public object modifiedDateTime { get; set; }
        
    }*/

    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
   /* public class CreateProject
    {
        public string area { get; set; }
        public string country { get; set; }
        public int countryId { get; set; }
        public string countryName { get; set; }
        public string createdBy { get; set; }
        public string createdDateTime { get; set; }
        public int latitude { get; set; }
        public int longitude { get; set; }
        public string modifiedBy { get; set; }
        public string modifiedDateTime { get; set; }
        public int numberOfWTG { get; set; }
        public string plannedEndDate { get; set; }
        public string plannedStartDate { get; set; }
        public string projectCode { get; set; }
        public string projectCreationDate { get; set; }
        public string projectDesc { get; set; }
        public string projectName { get; set; }
        public string projectPublicationDate { get; set; }
        public string projectStatus { get; set; }
        public int projectStatusId { get; set; }
        public string region { get; set; }
        public int regionId { get; set; }
        public string regionName { get; set; }
        public string statusName { get; set; }
        public string swiActualDate { get; set; }
        public string swiContractedDate { get; set; }
    }*/

    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    /*public class Project
    {
        public int id { get; set; }
        public string projectName { get; set; }
        public string projectCode { get; set; }
        public object projectDesc { get; set; }
        public DateTime plannedStartDate { get; set; }
        public DateTime plannedEndDate { get; set; }
        public DateTime projectCreationDate { get; set; }
        public object projectPublicationDate { get; set; }
        public object swiActualDate { get; set; }
        public DateTime swiContractedDate { get; set; }
        public int numberOfWTG { get; set; }
        public object projectStatus { get; set; }
        public int projectStatusId { get; set; }
        public object region { get; set; }
        public int regionId { get; set; }
        public object country { get; set; }
        public int countryId { get; set; }
        public string area { get; set; }
        public int latitude { get; set; }
        public int longitude { get; set; }
        public object countryName { get; set; }
        public object regionName { get; set; }
        public object statusName { get; set; }
        public string createdBy { get; set; }
        public DateTime createdDateTime { get; set; }
        public object modifiedBy { get; set; }
        public object modifiedDateTime { get; set; }
    }*/

    public class ProjectRoot
    {
        public Project project { get; set; }
    }


    //******************************

    /*public class OtherColleague
    {
        public string name { get; set; }
        public string role { get; set; }
    }*/

    /*public class ProjectCreation
    {
        public int id { get; set; }
        public string projectName { get; set; }
        public string projectCode { get; set; }
        public string regionId { get; set; }
        public string countryId { get; set; }
        public string latitude { get; set; }
        public string longitude { get; set; }
        public string numberOfWTG { get; set; }
        public DateTime swiContractedDate { get; set; }
        public DateTime plannedStartDate { get; set; }
        public DateTime plannedEndDate { get; set; }
        public string projectDesc { get; set; }
        public string customerName { get; set; }
        //public List<OtherColleague> otherColleagues { get; set; }
        public string area { get; set; }
        public int projectStatusId { get; set; }
        public DateTime ProjectCreationDate { get; set; }
        public string countryName { get; set; }
        public string regionName { get; set; }
        public string statusName { get; set; }

        public static implicit operator List<object>(ProjectCreation v)
        {
            throw new NotImplementedException();
        }
    }*/

   

   




}

