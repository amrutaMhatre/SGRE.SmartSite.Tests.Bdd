﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SqlQueries.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace SGRE.SmartSite.Tests.Bdd.Entities
{
    public static class SqlQueries
    {
        public static string SelectAllFrom { get; } = "SELECT * FROM ";

        public static string SelectAllFromDocDbCollectionWhereId { get; } = "SELECT * FROM c WHERE c.id = '{0}'";

        public static string SelectAllFromReportEquipmentTableWhereEquipmentId { get; } = "SELECT * FROM [dbo].[Equipment] WHERE EquipmentId = {0}";

        public static string SelectAllFromReportAntennaTableWhereAntennaId { get; } = "SELECT * FROM [dbo].[Antenna] WHERE Id = '{0}'";

        public static string SelectAllFromReportBeaconEquipmentTableWhereBeaconIdAndEquipmentId { get; } = "SELECT * FROM [dbo].[BeaconEquipment] WHERE BeaconId = '{0}' AND EquipmentId = {1}";

        public static string SelectAllFromEquipmentLocation { get; } = "SELECT * FROM [dbo].[EquipmentLocation] WHERE BeaconEquipmentId = {0}";

        public static string SelectFunctionalLocationIdsFromFunctionalLocationTable { get; } = "DECLARE @Point GEOMETRY; " +
                                                                                               "SELECT @Point = geometry::STGeomFromText('POINT({0} {1})', 0); " +
                                                                                               "SELECT FunctionalGeoLocationID FROM [dbo].[FunctionalGeoLocation] WHERE Location.STContains(@Point) = 1 and IsActive = 1;";

        public static string SelectAllFromFromFunctionalLocationTable { get; } = "SELECT FunctionalGeoLocationID, FunctionalLocationKey, Description, ParentFunctionalLocationID, IsActive, SourceId FROM [dbo].[FunctionalGeoLocation]";
    }
}
