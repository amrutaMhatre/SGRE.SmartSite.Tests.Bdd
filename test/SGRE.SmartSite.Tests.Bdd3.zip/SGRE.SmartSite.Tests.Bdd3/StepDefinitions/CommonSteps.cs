﻿using Bdd.Core.Api.Executors;
using Bdd.Core.Entities;
using global::Bdd.Core.Api.StepDefinitions;    
using global::Bdd.Core.StepDefinitions;
using global::Bdd.Core.Web.StepDefinitions;
using SGRE.SmartSite.Tests.Bdd.Entities;
using SGRE.SmartSite.Tests.Bdd.PageObjects;
using System;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using static SGRE.SmartSite.Tests.Bdd.Entities.Project;

namespace SGRE.SmartSite.Tests.Bdd.StepDefinitions
{
    public class Common
    {
        public string RequestUrl { get; set; }
        public Credentials cr { get; set; }
    }

    [Binding]
    public class CommonSteps : ApiStepDefinitionBase
    {
        private readonly Common commonValues;
       

        public CommonSteps(Common commonValues)
        {
            this.commonValues = commonValues;
        }

        #region - Variable Declarations
        public static string projectName = "AMTest321";
        /*public static int projectid = 21436;
        public static string customerName = "Cristofer Jones";
        public static string AdditionalStaffName = "Williams Smith";
        public static string AdditionalStaffRole = "SubContractor";
        public static string createdByRole = "Admin";
        public static string createdDateTime = "2021-09-17T10:22:39.679709+00:00";*/
        string apiUrl = System.Configuration.ConfigurationManager.AppSettings["APIUrl"];
        Credentials crValue = new Credentials();
        
        #endregion

        #region Common Given Method
        [Given(@"I set the API endpoint ""(.*)""")]
        public async Task GivenISetTheAPIEndpoint(string urL)
        {
            Console.WriteLine("Initializing Creadentials .....");
            crValue.User = System.Configuration.ConfigurationManager.AppSettings["AutomationUser"].ToString();
            crValue.Password = "`s]Fu]j\"S4nqGMWs<xS6\\^)NzqY";
            this.commonValues.cr = this.crValue;
            await this.ApiExecutor.AddAuthInfo(this.commonValues.cr).ConfigureAwait(false);
            commonValues.RequestUrl = apiUrl + urL;
            Console.WriteLine("Request URL - " + commonValues.RequestUrl);
            this.LogToReport("Request URL - " + commonValues.RequestUrl);
        }
        #endregion


        //  [BeforeTestRun]
        public static async Task CreateTestProject()
        {
            ApiExecutor api = new ApiExecutor();
            Credentials cr = new Credentials();
            Random randomNumber = new Random();
            
            var randomNumberString = randomNumber.Next(0, 9999).ToString("0000");
            projectName = "AMTesting" + randomNumberString;

            CreateProject project = new CreateProject
            {
                projectCode = "6443",
                projectName = projectName,
                projectDesc = null,
                plannedStartDate = DateTime.Now,
                plannedEndDate = DateTime.Now,
                swiContractedDate = DateTime.Now,
                area = "ww",
                numberOfWTG = "100",
                projectStatusId = 1,
                regionId = "5",
                countryId = "11",               
                latitude = "23",
                longitude = "25"
            };
            Console.WriteLine("plannedStartDate " + project.projectName);
            string baseUrl = System.Configuration.ConfigurationManager.AppSettings["APIUrl"];
            string apiurl = baseUrl + "/project";
            var result = await api.PutAsync<object>(apiurl, project, cr);
            Console.WriteLine("result" + result);

            //await GivenGetAllProjectsListGETAPIFor();
        }

        //Get project id
        //public static async Task GivenGetAllProjectsListGETAPIFor()
        //{
        //    try
        //    {
        //        string baseUrl = System.Configuration.ConfigurationManager.AppSettings["APIUrl"];
        //        ApiExecutor api = new ApiExecutor();
        //        Credentials cr = new Credentials();

        //        #region call api and check the responce i.e. status code 
        //        string apiurl = baseUrl + "/projects";
        //        var result = await api.GetAsync<Root>(apiurl, cr);
        //        Console.WriteLine("result " + result);
        //        Console.WriteLine("responseJson " + result.value.Count);
        //        Console.WriteLine(result.value[0].ProjectName);
        //        if(result.value.Count > 0)
        //        {
        //            for(int i =0; i <= result.value.Count; i++)
        //            {
        //                if (result.value[i].ProjectName.Equals(projectName))
        //                {
        //                    projectid = result.value[i].Id;
        //                    break;
        //                }
        //            }
        //        }

        //        /*var result = await api.GetResponseAsync(url, cr);
        //        var responseBody = await result.Content.ReadAsStringAsync();
        //        var responseJson = JsonConvert.DeserializeObject<Root>(responseBody);
        //        Console.WriteLine("responseJson " + responseJson.value.Count);
        //        int APIStatusCode = (int)result.StatusCode;
        //        Assert.AreEqual(APIStatusCode, 200, "Could not get all the projects list");
        //        Assert.NotNull(responseJson, "Project List is empty");*/
        //        #endregion
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //}

    }
}
        