﻿using SGRE.SmartSite.Tests.Bdd.Entities;
using Bdd.Core.Api.Executors;
using Bdd.Core.Api.StepDefinitions;
using Bdd.Core.Entities;
using Newtonsoft.Json;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using static SGRE.SmartSite.Tests.Bdd.Entities.Meta;
using static SGRE.SmartSite.Tests.Bdd.Entities.Project;

namespace SGRE.SmartSite.Tests.Bdd.StepDefinitions
{
    [Binding]
    public class MetaAPISteps : ApiStepDefinitionBase
    {
        
        List<Regions> resionlistresponce;
        List<CountryListByRegionId> countryresponce;
        List<ProjectStatusList> status;
        List<SubContractors> subContractorsresponse;
        List<ImpactedParty> impactedpartyresponse;
        List<CorrectiveActionName> correctiveactionresponse;
        List<ImpactedResourceName> impactedresourceresponse;
        List<RoanMapTemplatePhases> phasesresponse;
        List<RoadMapPhaseTasks> taskresponse;
        ProjectsBySearch projectsearchresponse;
        string ActualCountryName;
        
        private readonly Common commonValues;
        public MetaAPISteps(Common commonValues)
        {
            this.commonValues = commonValues;
        }

        [When(@"Get the count of deviation list")]
        public async System.Threading.Tasks.Task WhenGetTheCountOfDeviationListAsync()
        {
            var deviationresponse = await this.ApiExecutor.GetAsync<List<DeviationList>>(this.commonValues.RequestUrl, this.commonValues.cr);
            Assert.IsTrue(deviationresponse.Count > 0, "Atleast one deviation type is listed in deviation list");           
        }
        
        [Then(@"List contains details for deviation data")]
        public async Task ThenListContainsDetailsForDeviationDataAsync()
        {
            var deviationresponse = await this.ApiExecutor.GetAsync<List<DeviationList>>(this.commonValues.RequestUrl, this.commonValues.cr);
            Boolean flag = true;
            for (int i = 0; i < deviationresponse.Count; i++)
            {
                if (deviationresponse[i].type.Contains("OTHERS"))
                {
                    if (deviationresponse[i].subType.Contains("EHS"))
                    {
                        if(deviationresponse[i].detail.Contains("Health and Safety talk") || deviationresponse[i].detail.Contains("Environment") || deviationresponse[i].detail.Contains("Incident") || deviationresponse[i].detail.Contains("Incident") || deviationresponse[i].detail.Contains("Safety alert"))
                        {
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].type);
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].subType);
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].detail);
                        }
                        else
                        {
                            Console.WriteLine("For index " + i + deviationresponse[i].detail + " Not found");
                            flag = false;
                        }
                    }
                    else if (deviationresponse[i].subType.Contains("COMM"))
                    {
                        if (deviationresponse[i].detail.Contains("Extra work") || deviationresponse[i].detail.Contains("Comm Training") || deviationresponse[i].detail.Contains("Comm Tools & Equipments") || deviationresponse[i].detail.Contains("Commissioning resources") || deviationresponse[i].detail.Contains("Grid Delay"))
                        {
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].type);
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].subType);
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].detail);
                        }
                        else
                        {
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].detail + " Not found");
                            flag = false;
                        }
                    }
                    else if (deviationresponse[i].subType.Contains("LOG"))
                    {
                        if (deviationresponse[i].detail.Contains("Damaged components") || deviationresponse[i].detail.Contains("Transport permits") || deviationresponse[i].detail.Contains("Equipment availability") || deviationresponse[i].detail.Contains("Equipment failure"))
                        {
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].type);
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].subType);
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].detail);
                        }
                        else
                        {
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].detail + " Not found");
                            flag = false;
                        }
                    }
                    else if (deviationresponse[i].subType.Contains("WTG"))
                    {
                        if (deviationresponse[i].detail.Contains("Retrofit") || deviationresponse[i].detail.Contains("Missing items") || deviationresponse[i].detail.Contains("Wrong design") || deviationresponse[i].detail.Contains("Quality") || deviationresponse[i].detail.Contains("Delayed production"))
                        {
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].type);
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].subType);
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].detail);
                        }
                        else
                        {
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].detail + " Not found");
                            flag = false;
                        }
                    }
                    else if (deviationresponse[i].subType.Contains("BoP"))
                    {
                        if (deviationresponse[i].detail.Contains("Electrical - BoP others") || deviationresponse[i].detail.Contains("Civil - BOP others") || deviationresponse[i].detail.Contains("Trenches") || deviationresponse[i].detail.Contains("Foundations") || deviationresponse[i].detail.Contains("Platforms") || deviationresponse[i].detail.Contains("Internal roads") || deviationresponse[i].detail.Contains("Access Road to Site"))
                        {
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].type);
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].subType);
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].detail);
                        }
                        else
                        {
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].detail + " Not found");
                            flag = false;
                        }
                    }
                    else
                    {
                        flag = false;
                    }

                }
                else if (deviationresponse[i].type.Contains("Technical Down Time"))
                {
                    if (deviationresponse[i].subType.Contains("CNS - Cranes"))
                    {
                        if (deviationresponse[i].detail.Contains("Insufficient Time Window") || deviationresponse[i].detail.Contains("Total disassembly") || deviationresponse[i].detail.Contains("Partial disassembly") || deviationresponse[i].detail.Contains("Low productivity -slow rate") || deviationresponse[i].detail.Contains("Low productivity - Lack of resources") || deviationresponse[i].detail.Contains("Breakdown") || deviationresponse[i].detail.Contains("Customer Tools &Equipment") || deviationresponse[i].detail.Contains("Supplier Tools &Equipment") || deviationresponse[i].detail.Contains("SGRE Tools &Equipment"))
                        {
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].type);
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].subType);
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].detail);
                        }
                        else
                        {
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].detail + " Not found");
                            flag = false;
                        }
                    }
                    else if (deviationresponse[i].subType.Contains("CNS - Install"))
                    {
                        if (deviationresponse[i].detail.Contains("Low productivity - slow rate") || deviationresponse[i].detail.Contains("Low productivity - Lack of resources") || deviationresponse[i].detail.Contains("Low productivity - Training") || deviationresponse[i].detail.Contains("Customer Tools & Equipment") || deviationresponse[i].detail.Contains("Supplier Tools & Equipment") || deviationresponse[i].detail.Contains("SGRE Tools & Equipment"))
                        {
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].type);
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].subType);
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].detail);
                        }
                        else
                        {
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].detail + " Not found");
                            flag = false;
                        }
                    }
                    else
                    {
                        flag = false;
                    }

                }
                else if (deviationresponse[i].type.Contains("Weather Down Time"))
                {
                    if (deviationresponse[i].subType.Contains("Weather Down Time"))
                    {
                        if (deviationresponse[i].detail.Contains("Temperature") || deviationresponse[i].detail.Contains("Lightning") || deviationresponse[i].detail.Contains("Ice") || deviationresponse[i].detail.Contains("Snow") || deviationresponse[i].detail.Contains("Sand Storm") || deviationresponse[i].detail.Contains("Fog") || deviationresponse[i].detail.Contains("Heavy rain") || deviationresponse[i].detail.Contains("Wind"))
                        {
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].type);
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].subType);
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].detail);
                        }
                        else
                        {
                            Console.WriteLine("For index " + i + " " + deviationresponse[i].detail + " Not found");
                            flag = false;
                        }
                    }
                    else
                    {
                        flag = false;
                    }
                }
                else
                {
                    flag = false;
                }
                Assert.IsTrue(flag);
            }
        }

        [When(@"Get the count of reagions list")]
        public async Task WhenGetTheCountOfReagionsListAsync()
        {
            try
            {
                resionlistresponce = await this.ApiExecutor.GetAsync<List<Regions>>(this.commonValues.RequestUrl, this.commonValues.cr);
                Assert.True(resionlistresponce.Count == 5, "Getting list of regions with less than count 5");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Then(@"List contains details for reagions data")]
        public void ThenListContainsDetailsForReagionsData()
        {
            try
            {
                Console.WriteLine("Number of regions " + resionlistresponce.Count);

                for (int i = 0; i < resionlistresponce.Count; i++)
                {

                    if (resionlistresponce[i].id == 5)
                    {
                        Assert.AreEqual(resionlistresponce[i].regionName, "SEA");
                        Console.WriteLine("Index " + i + " : " + resionlistresponce[i].regionName);
                    }
                    else if (resionlistresponce[i].id == 4)
                    {
                        Assert.AreEqual(resionlistresponce[i].regionName, "NEME");
                        Console.WriteLine("Index " + i + " : " + resionlistresponce[i].regionName);
                    }
                    else if (resionlistresponce[i].id == 3)
                    {
                        Assert.AreEqual(resionlistresponce[i].regionName, "LATAM");
                        Console.WriteLine("Index " + i + " : " + resionlistresponce[i].regionName);
                    }
                    else if (resionlistresponce[i].id == 2)
                    {
                        Assert.AreEqual(resionlistresponce[i].regionName, "INDIA");
                        Console.WriteLine("Index " + i + " : " + resionlistresponce[i].regionName);
                    }
                    else if (resionlistresponce[i].id == 1)
                    {
                        Assert.AreEqual(resionlistresponce[i].regionName, "BRA");
                        Console.WriteLine("Index " + i + " : " + resionlistresponce[i].regionName);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [When(@"Get the count of Region details by id (.*)")]
        public async Task WhenGetTheCountOfRegionDetailsByIdAsync(int regionid)
        {
            try
            {
                string apiUrl = this.commonValues.RequestUrl + "/" + regionid;
                resionlistresponce = await this.ApiExecutor.GetAsync<List<Regions>>(apiUrl, this.commonValues.cr);
                Console.WriteLine("API responce: " + resionlistresponce);
                Assert.True(resionlistresponce.Count == 1, "Could not get the list of regions");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [When(@"Get the count of country with specific region Id (.*)")]
        public async Task WhenGetTheCountOfCountryWithSpecificRegionIdAsync(int regionid)
        {
            try
            {
                string apiUrl = this.commonValues.RequestUrl + "/" + regionid;
                countryresponce = await this.ApiExecutor.GetAsync<List<CountryListByRegionId>>(apiUrl, this.commonValues.cr);
                Console.WriteLine("API responce: " + countryresponce.Count);
                Assert.IsTrue(countryresponce.Count > 0);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Then(@"Get all the details for counties")]
        public void ThenGetAllTheDetailsForCounties()
        {
            try
            {
                Console.WriteLine("Number of country " + countryresponce.Count);
                Boolean flag = true;
                for (int i = 0; i < countryresponce.Count; i++)
                {
                    if (countryresponce[i].regionId == 5)
                    {
                        Assert.True(countryresponce.Count == 7, "Could not get the expected list of country for region index " + countryresponce[i].regionId);
                        if (countryresponce[i].id == 14)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Egypt", ActualCountryName);
                        }
                        else if (countryresponce[i].id == 22)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Spain", ActualCountryName);
                        }
                        else if (countryresponce[i].id == 23)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Ethiopia", ActualCountryName);
                        }
                        else if (countryresponce[i].id == 24)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("France", ActualCountryName);
                        }
                        else if (countryresponce[i].id == 25)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Greece", ActualCountryName);
                        }
                        else if (countryresponce[i].id == 26)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Italy", ActualCountryName);
                        }
                        else if (countryresponce[i].id == 27)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Morocco", ActualCountryName);
                        }
                        else
                        {
                            flag = false;
                            Console.WriteLine("Country is not matching for region id " + countryresponce[i].id);
                        }

                    }
                    else if (countryresponce[i].regionId == 4)
                    {
                        Assert.True(countryresponce.Count == 8, "Could not get the expected list of country for region index " + countryresponce[i].regionId);
                        if (countryresponce[i].id == 13)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("UK", ActualCountryName);
                        }
                        else if (countryresponce[i].id == 12)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Sweden", ActualCountryName);
                        }
                        else if (countryresponce[i].id == 11)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Poland", ActualCountryName);
                        }
                        else if (countryresponce[i].id == 10)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Norway", ActualCountryName);
                        }
                        else if (countryresponce[i].id == 9)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Finland", ActualCountryName);
                        }
                        else if (countryresponce[i].id == 8)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Croatia", ActualCountryName);
                        }
                        else if (countryresponce[i].id == 7)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Belgium", ActualCountryName);
                        }
                        else if (countryresponce[i].id == 6)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Germany", ActualCountryName);
                        }
                        else
                        {
                            flag = false;
                            Console.WriteLine("Country is not matching for region id " + countryresponce[i].id);
                        }
                    }
                    else if (countryresponce[i].regionId == 3)
                    {
                        Assert.True(countryresponce.Count == 3, "Could not get the expected list of country for region index " + countryresponce[i].regionId);
                        if (countryresponce[i].id == 5)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Peru", ActualCountryName);
                        }
                        else if (countryresponce[i].id == 4)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Mexico", ActualCountryName);
                        }
                        else if (countryresponce[i].id == 3)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Chile", ActualCountryName);
                        }
                        else
                        {
                            flag = false;
                            Console.WriteLine("Country is not matching for region id " + countryresponce[i].id);
                        }
                    }
                    else if (countryresponce[i].regionId == 2)
                    {
                        Assert.True(countryresponce.Count == 1, "Could not get the expected list of country for region index " + countryresponce[i].regionId);
                        if (countryresponce[i].id == 2)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("India", ActualCountryName);
                        }
                        else
                        {
                            flag = false;
                            Console.WriteLine("Country is not matching for region id " + countryresponce[i].id);
                        }
                    }
                    else if (countryresponce[i].regionId == 1)
                    {
                        Assert.True(countryresponce.Count == 1, "Could not get the expected list of country for region index " + countryresponce[i].regionId);
                        if (countryresponce[i].id == 1)
                        {
                            ActualCountryName = countryresponce[i].countryName;
                            Assert.AreEqual("Brazil", ActualCountryName);
                        }
                        else
                        {
                            flag = false;
                            Console.WriteLine("Country is not matching for region id " + countryresponce[i].id);
                        }
                    }
                    else
                    {
                        flag = false;
                        Console.WriteLine("Country is not matching for region id " + countryresponce[i].id);
                    }
                    Assert.IsTrue(flag);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [When(@"Get the count of project status")]
        public async Task WhenGetTheCountOfProjectStatusAsync()
        {
            try
            {
                status = await this.ApiExecutor.GetAsync<List<ProjectStatusList>>(this.commonValues.RequestUrl, this.commonValues.cr);
                Assert.True(status.Count == 6, "Unable to get the project status list");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Then(@"Get all the details for each project status")]
        public void ThenGetAllTheDetailsForEachProjectStatus()
        {
            try
            {
                Boolean flag = true;
                for (int i = 0; i < status.Count; i++)
                {
                    if (status[i].id == 1)
                    {
                        Assert.AreEqual("Draft", status[i].statusName);
                    }
                    else if (status[i].id == 2)
                    {
                        Assert.AreEqual("Roadmap Requested", status[i].statusName);
                    }
                    else if (status[i].id == 3)
                    {
                        Assert.AreEqual("Created", status[i].statusName);
                    }
                    else if (status[i].id == 4)
                    {
                        Assert.AreEqual("Published", status[i].statusName);
                    }
                    else if (status[i].id == 5)
                    {
                        Assert.AreEqual("Finished", status[i].statusName);
                    }
                    else if (status[i].id == 6)
                    {
                        Assert.AreEqual("Archived", status[i].statusName);
                    }
                    else
                    {
                        flag = false;
                        Console.WriteLine("Got the wrong status name as " + status[i].statusName);
                    }
                    Assert.IsTrue(flag);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [When(@"Get the count of SubContractors")]
        public async Task WhenGetTheCountOfSubContractorsAsync()
        {
            try
            {
                subContractorsresponse = await this.ApiExecutor.GetAsync<List<SubContractors>>(this.commonValues.RequestUrl, this.commonValues.cr);
                Assert.True(subContractorsresponse.Count == 10, "Unable to get the SubContractors list");
            }
            catch (Exception ex)
            {
                throw ex;
            }           
        }

        [Then(@"Get all the details for each SubContractor")]
        public void ThenGetAllTheDetailsForEachSubContractor()
        {
            try
            {
                for (int i = 0; i < subContractorsresponse.Count; i++)
                {
                    Assert.IsNotNull(subContractorsresponse[i].id, "SubContractor id is null for index " + i);
                    Assert.IsNotNull(subContractorsresponse[i].subContractorName, "SubContractor Name is null for index "+ i);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [When(@"Get the count of Impacted Parties")]
        public async Task WhenGetTheCountOfImpactedPartiesAsync()
        {
            try
            {
                impactedpartyresponse = await this.ApiExecutor.GetAsync<List<ImpactedParty>>(this.commonValues.RequestUrl, this.commonValues.cr);
                Assert.True(impactedpartyresponse.Count == 16, "Unable to get the total list of Impacted Parties");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Then(@"Get all the details for each Impacted Party")]
        public void ThenGetAllTheDetailsForEachImpactedParty()
        {
            try
            {
                Boolean flag = true;
                for (int i = 0; i < impactedpartyresponse.Count; i++)
                {
                    if (impactedpartyresponse[i].id == 1)
                    {
                        Assert.AreEqual("Customer", impactedpartyresponse[i].partyName);
                    }
                    else if (impactedpartyresponse[i].id == 2)
                    {
                        Assert.AreEqual("SGRE - Procurement", impactedpartyresponse[i].partyName);
                    }
                    else if (impactedpartyresponse[i].id == 3)
                    {
                        Assert.AreEqual("SGRE - Planning", impactedpartyresponse[i].partyName);
                    }
                    else if (impactedpartyresponse[i].id == 4)
                    {
                        Assert.AreEqual("SGRE - Sales / Pre-sales", impactedpartyresponse[i].partyName);
                    }
                    else if (impactedpartyresponse[i].id == 5)
                    {
                        Assert.AreEqual("SGRE - Technology - Regions", impactedpartyresponse[i].partyName);
                    }
                    else if (impactedpartyresponse[i].id == 6)
                    {
                        Assert.AreEqual("SGRE - Technology - Corporate", impactedpartyresponse[i].partyName);
                    }
                    else if (impactedpartyresponse[i].id == 7)
                    {
                        Assert.AreEqual("SGRE - OPS - Region", impactedpartyresponse[i].partyName);
                    }
                    else if (impactedpartyresponse[i].id == 8)
                    {
                        Assert.AreEqual("SGRE - WF Development", impactedpartyresponse[i].partyName);
                    }
                    else if (impactedpartyresponse[i].id == 9)
                    {
                        Assert.AreEqual("SGRE - BOP", impactedpartyresponse[i].partyName);
                    }
                    else if (impactedpartyresponse[i].id == 10)
                    {
                        Assert.AreEqual("SGRE - Logistics", impactedpartyresponse[i].partyName);
                    }
                    else if (impactedpartyresponse[i].id == 11)
                    {
                        Assert.AreEqual("SGRE - Logistics Maritime", impactedpartyresponse[i].partyName);
                    }
                    else if (impactedpartyresponse[i].id == 12)
                    {
                        Assert.AreEqual("SGRE - Construction", impactedpartyresponse[i].partyName);
                    }
                    else if (impactedpartyresponse[i].id == 13)
                    {
                        Assert.AreEqual("SGRE - Service", impactedpartyresponse[i].partyName);
                    }
                    else if (impactedpartyresponse[i].id == 14)
                    {
                        Assert.AreEqual("External supplier - Crane subcontractor", impactedpartyresponse[i].partyName);
                    }
                    else if (impactedpartyresponse[i].id == 15)
                    {
                        Assert.AreEqual("External supplier - Installation subcontractor", impactedpartyresponse[i].partyName);
                    }
                    else if (impactedpartyresponse[i].id == 16)
                    {
                        Assert.AreEqual("External supplier - Transport subcontractor", impactedpartyresponse[i].partyName);
                    }
                    else
                    {
                        flag = false;
                        Console.WriteLine("Got the wrong Impacted party name as " + impactedpartyresponse[i].partyName + " for id "+ impactedpartyresponse[i].id);
                    }
                    Assert.IsTrue(flag);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [When(@"Get the count of Corrective Actions")]
        public async Task WhenGetTheCountOfCorrectiveActionsAsync()
        {
            try
            {
                correctiveactionresponse = await this.ApiExecutor.GetAsync<List<CorrectiveActionName>>(this.commonValues.RequestUrl, this.commonValues.cr);
                Assert.True(correctiveactionresponse.Count > 0, "Unable to get the list of Corrective Action Name");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Then(@"Get all the details for each Corrective Action")]
        public void ThenGetAllTheDetailsForEachCorrectiveAction()
        {
            try
            {
                for (int i = 0; i < correctiveactionresponse.Count; i++)
                {
                    Assert.IsNotNull(correctiveactionresponse[i].id, "Corrective Action id is null for index " + i);
                    Assert.IsNotNull(correctiveactionresponse[i].correctiveActionName, "Corrective Action Name is null for index " + i);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [When(@"Get the count of Impacted Resources")]
        public async Task WhenGetTheCountOfImpactedResourcesAsync()
        {
            try
            {
                impactedresourceresponse = await this.ApiExecutor.GetAsync<List<ImpactedResourceName>>(this.commonValues.RequestUrl, this.commonValues.cr);
                Assert.True(impactedresourceresponse.Count == 15, "Unable to get the total list of Impacted Resources");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [Then(@"Get all the details for each Resource")]
        public void ThenGetAllTheDetailsForEachResource()
        {
            try
            {
                Boolean flag = true;
                for (int i = 0; i < impactedresourceresponse.Count; i++)
                {
                    if (impactedresourceresponse[i].id == 1)
                    {
                        Assert.AreEqual("Main crane w/o crew", impactedresourceresponse[i].impactedResourceName);
                    }
                    else if (impactedresourceresponse[i].id == 2)
                    {
                        Assert.AreEqual("Main crane with crew", impactedresourceresponse[i].impactedResourceName);
                    }
                    else if (impactedresourceresponse[i].id == 3)
                    {
                        Assert.AreEqual("Pre-assembly crane w/o crew", impactedresourceresponse[i].impactedResourceName);
                    }
                    else if (impactedresourceresponse[i].id == 4)
                    {
                        Assert.AreEqual("Pre-assembly crane with crew", impactedresourceresponse[i].impactedResourceName);
                    }
                    else if (impactedresourceresponse[i].id == 5)
                    {
                        Assert.AreEqual("Auxiliary crane", impactedresourceresponse[i].impactedResourceName);
                    }
                    else if (impactedresourceresponse[i].id == 6)
                    {
                        Assert.AreEqual("Cherry picker", impactedresourceresponse[i].impactedResourceName);
                    }
                    else if (impactedresourceresponse[i].id == 7)
                    {
                        Assert.AreEqual("Generator", impactedresourceresponse[i].impactedResourceName);
                    }
                    else if (impactedresourceresponse[i].id == 8)
                    {
                        Assert.AreEqual("Forklift", impactedresourceresponse[i].impactedResourceName);
                    }
                    else if (impactedresourceresponse[i].id == 9)
                    {
                        Assert.AreEqual("Subcontractor tools", impactedresourceresponse[i].impactedResourceName);
                    }
                    else if (impactedresourceresponse[i].id == 10)
                    {
                        Assert.AreEqual("SGRE tools", impactedresourceresponse[i].impactedResourceName);
                    }
                    else if (impactedresourceresponse[i].id == 11)
                    {
                        Assert.AreEqual("Mechanical technicians", impactedresourceresponse[i].impactedResourceName);
                    }
                    else if (impactedresourceresponse[i].id == 12)
                    {
                        Assert.AreEqual("Electrical technicians", impactedresourceresponse[i].impactedResourceName);
                    }
                    else if (impactedresourceresponse[i].id == 13)
                    {
                        Assert.AreEqual("Commissioners", impactedresourceresponse[i].impactedResourceName);
                    }
                    else if (impactedresourceresponse[i].id == 14)
                    {
                        Assert.AreEqual("SGRE resources", impactedresourceresponse[i].impactedResourceName);
                    }
                    else if (impactedresourceresponse[i].id == 15)
                    {
                        Assert.AreEqual("Installation resources", impactedresourceresponse[i].impactedResourceName);
                    }
                    else
                    {
                        flag = false;
                        Console.WriteLine("Got the wrong Impacted resource name as " + impactedresourceresponse[i].impactedResourceName + " for id " + impactedresourceresponse[i].id);
                    }
                    Assert.IsTrue(flag);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [When(@"Get the count of RoadMap Phases")]
        public async Task WhenGetTheCountOfRoadMapPhasesAsync()
        {
            try
            {
                phasesresponse = await this.ApiExecutor.GetAsync<List<RoanMapTemplatePhases>>(this.commonValues.RequestUrl, this.commonValues.cr);
                Assert.True(phasesresponse.Count == 9, "Unable to get the total list of Roadmap phases");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Then(@"Get all the details for each Phase")]
        public void ThenGetAllTheDetailsForEachPhase()
        {
            try
            {
                Boolean flag = true;
                for (int i = 0; i < phasesresponse.Count; i++)
                {
                    if (phasesresponse[i].id == 1)
                    {
                        Assert.AreEqual("UNLOADING", phasesresponse[i].phaseName);
                    }
                    else if (phasesresponse[i].id == 2)
                    {
                        Assert.AreEqual("PREPARATIONS", phasesresponse[i].phaseName);
                    }
                    else if (phasesresponse[i].id == 3)
                    {
                        Assert.AreEqual("PRE-ASSEMBLY", phasesresponse[i].phaseName);
                    }
                    else if (phasesresponse[i].id == 4)
                    {
                        Assert.AreEqual("MAIN ERECTION", phasesresponse[i].phaseName);
                    }
                    else if (phasesresponse[i].id == 5)
                    {
                        Assert.AreEqual("MECHANICAL & ELECTRICAL COMPLETION", phasesresponse[i].phaseName);
                    }
                    else if (phasesresponse[i].id == 6)
                    {
                        Assert.AreEqual("MECHANICAL WALKDOWN", phasesresponse[i].phaseName);
                    }
                    else if (phasesresponse[i].id == 7)
                    {
                        Assert.AreEqual("COMMISSIONING", phasesresponse[i].phaseName);
                    }
                    else if (phasesresponse[i].id == 8)
                    {
                        Assert.AreEqual("GENERAL TASKS", phasesresponse[i].phaseName);
                    }
                    else if (phasesresponse[i].id == 9)
                    {
                        Assert.AreEqual("EXTRA TASK OR ADMINISTRATION TASKS", phasesresponse[i].phaseName);
                    }
                    else
                    {
                        flag = false;
                        Console.WriteLine("Got the wrong roadmap phase name as " + phasesresponse[i].phaseName + " for id " + phasesresponse[i].id);
                    }
                    Assert.IsTrue(flag);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [When(@"Get the count of RoadMap Phases task")]
        public async Task WhenGetTheCountOfRoadMapPhasesTaskAsync()
        {
            try
            {
                taskresponse = await this.ApiExecutor.GetAsync<List<RoadMapPhaseTasks>>(this.commonValues.RequestUrl, this.commonValues.cr);
                Assert.True(taskresponse.Count == 156, "Unable to get the total list of Roadmap phases Task ");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Then(@"Get all the task details for each Phase")]
        public void ThenGetAllTheTaskDetailsForEachPhase()
        {
            try
            {
                Boolean flag = true;
                for (int i = 0; i < taskresponse.Count; i++)
                {
                    if (taskresponse[i].phaseId == 1)
                    {
                        if (taskresponse[i].taskName.Contains("1st Section") || taskresponse[i].taskName.Contains("2nd Section") || taskresponse[i].taskName.Contains("3rd Section") || taskresponse[i].taskName.Contains("4th Section") || taskresponse[i].taskName.Contains("5th Section") || taskresponse[i].taskName.Contains("6th Section") || taskresponse[i].taskName.Contains("7th Section") || taskresponse[i].taskName.Contains("8th Section") || taskresponse[i].taskName.Contains("Nacelle") || taskresponse[i].taskName.Contains("Hub") || taskresponse[i].taskName.Contains("Drive Train") || taskresponse[i].taskName.Contains("Blade 1") || taskresponse[i].taskName.Contains("Blade 2") || taskresponse[i].taskName.Contains("Blade 3") || taskresponse[i].taskName.Contains("Spinners") || taskresponse[i].taskName.Contains("Material Container #1") || taskresponse[i].taskName.Contains("Material Container #2") || taskresponse[i].taskName.Contains("Switchgear") || taskresponse[i].taskName.Contains("Ground") || taskresponse[i].taskName.Contains("PU") || taskresponse[i].taskName.Contains("Transformer Unit") || taskresponse[i].taskName.Contains("Cooling system") || taskresponse[i].taskName.Contains("Low Speed Shaft") || taskresponse[i].taskName.Contains("Gearbox") || taskresponse[i].taskName.Contains("Crane mats preparations & packing") || taskresponse[i].taskName.Contains("Other components") || taskresponse[i].taskName.Contains("Short Section") || taskresponse[i].taskName.Contains("Nacelle Roof"))
                        {
                            Assert.IsNotNull(taskresponse[i].id);
                        }
                        else
                        {
                            Console.WriteLine("For Task id " + taskresponse[i].id + " " +taskresponse[i].taskName + " task name not found");
                            flag = false;
                        }
                    }
                    else if (taskresponse[i].phaseId == 2)
                    {
                        if (taskresponse[i].taskName.Contains("NACELLE ROOF LIFTING & TU INSTALLATION INSIDE NACELLE") || taskresponse[i].taskName.Contains("NACELLE PREPARATION") || taskresponse[i].taskName.Contains("ASSEMBLY SCAFFOLD FOR NACELLE ASSEMBLY") || taskresponse[i].taskName.Contains("Remove Provisional Roof Of The Nacelle") || taskresponse[i].taskName.Contains("Assembly Of Nacelle Components Without Roof") || taskresponse[i].taskName.Contains("Assembly Of The Nacelle Roof") || taskresponse[i].taskName.Contains("SPLIT NACELLE PREPARATION") || taskresponse[i].taskName.Contains("Dismount Scaffold For Nacelle Assembly") || taskresponse[i].taskName.Contains("LIGHT NACELLE PREPARATION") || taskresponse[i].taskName.Contains("Assembly Of Transformer & Fill Generator Coolers In Nacelle") || taskresponse[i].taskName.Contains("ASSEMBLY OF LOW SPEED SHAFT+ GEARBOX") || taskresponse[i].taskName.Contains("GENERATOR ASSEMBLY IN NACELLE") || taskresponse[i].taskName.Contains("External Preparation Of Nacelle") || taskresponse[i].taskName.Contains("Rout & Connect Generator And Transformer In Nacelle") || taskresponse[i].taskName.Contains("LSS + GEARBOX INSTALLATION ON GROUND") || taskresponse[i].taskName.Contains("DT + HUB INSTALLATION ON GROUND") || taskresponse[i].taskName.Contains("SPINNER INSTALLATION OVER DT+HUB") || taskresponse[i].taskName.Contains("SPINNER INSTALLATION OVER HUB") || taskresponse[i].taskName.Contains("BLADES PREPARATIONS") || taskresponse[i].taskName.Contains("TOWER SECTIONS PREPARATION") || taskresponse[i].taskName.Contains("HELICAL STRAKES INSTALLATION ON GROUND") || taskresponse[i].taskName.Contains("MAIN ASSEMBLY UPPER PART PREPARATION") || taskresponse[i].taskName.Contains("NAC + HUB INSTALLATION ON GROUND") || taskresponse[i].taskName.Contains("ROTOR ASSEMBLY ON GROUND") || taskresponse[i].taskName.Contains("ADDITIONAL/SPECIAL PREPARATIONS ON GROUND") || taskresponse[i].taskName.Contains("Test Complete Nacelle On Ground") || taskresponse[i].taskName.Contains("Maritime Transport Tool") || taskresponse[i].taskName.Contains("Lifeline") || taskresponse[i].taskName.Contains("Assembly Dt In Nacelle On Ground") || taskresponse[i].taskName.Contains("Fix Dt+ Blade Preparations_Turn Gear") || taskresponse[i].taskName.Contains("Rout And Connect Dt On Ground"))
                        {
                            Assert.IsNotNull(taskresponse[i].id);
                        }
                        else
                        {
                            Console.WriteLine("For Task id " + taskresponse[i].id + " " + taskresponse[i].taskName + " task name not found");
                            flag = false;
                        }
                    }
                    else if (taskresponse[i].phaseId == 3)
                    {
                        if (taskresponse[i].taskName.Contains("1st Section") || taskresponse[i].taskName.Contains("2nd Section") || taskresponse[i].taskName.Contains("3rd Section") || taskresponse[i].taskName.Contains("Relocation") || taskresponse[i].taskName.Contains("FIX BOTTOM SECTION") || taskresponse[i].taskName.Contains("LOWER TOWER SECTION TORQUES") || taskresponse[i].taskName.Contains("INTRODUCE EXTERNAL BOLTS IN T1-T2 T-FLANGE") || taskresponse[i].taskName.Contains("Grounting") || taskresponse[i].taskName.Contains("MV and FO connection"))
                        {
                            Assert.IsNotNull(taskresponse[i].id);
                        }
                        else
                        {
                            Console.WriteLine("For Task id " + taskresponse[i].id + " " + taskresponse[i].taskName + " task name not found");
                            flag = false;
                        }

                    }
                    else if (taskresponse[i].phaseId == 4)
                    {
                        if (taskresponse[i].taskName.Contains("1st Section") || taskresponse[i].taskName.Contains("2nd Section") || taskresponse[i].taskName.Contains("3rd Section") || taskresponse[i].taskName.Contains("4th Section") || taskresponse[i].taskName.Contains("FIX BOTTOM SECTION") || taskresponse[i].taskName.Contains("LOWER TOWER SECTION TORQUES") || taskresponse[i].taskName.Contains("5th Section") || taskresponse[i].taskName.Contains("6th Section") || taskresponse[i].taskName.Contains("7th Section") || taskresponse[i].taskName.Contains("8th Section") || taskresponse[i].taskName.Contains("Nacelle") || taskresponse[i].taskName.Contains("Dt+Hub") || taskresponse[i].taskName.Contains("DT") || taskresponse[i].taskName.Contains("FIX DT & PREPARATIONS FOR SBI") || taskresponse[i].taskName.Contains("HUB") || taskresponse[i].taskName.Contains("Blade 1") || taskresponse[i].taskName.Contains("Blade 2") || taskresponse[i].taskName.Contains("Blade 3") || taskresponse[i].taskName.Contains("Complete Rotor Installtion Final Tasks") || taskresponse[i].taskName.Contains("Relocation") || taskresponse[i].taskName.Contains("Final Single Blade Installation Task") || taskresponse[i].taskName.Contains("Complete Rotor Installation (Crane Tasks)"))
                        {
                            Assert.IsNotNull(taskresponse[i].id);      
                        }
                        else
                        {
                            Console.WriteLine("For Task id " + taskresponse[i].id + " " + taskresponse[i].taskName + " task name not found");
                            flag = false;
                        }
                    }
                    else if (taskresponse[i].phaseId == 5)
                    {
                        if (taskresponse[i].taskName.Contains("MAIN INSTALLATION FINAL TASKS") || taskresponse[i].taskName.Contains("UPPER TOWER SECTION TORQUES") || taskresponse[i].taskName.Contains("BLADES TENSIONING") || taskresponse[i].taskName.Contains("GEARBOX ALIGNMENT") || taskresponse[i].taskName.Contains("GENERATOR ALIGNMENT") || taskresponse[i].taskName.Contains("NACELLE & DT & HUB WIRING") || taskresponse[i].taskName.Contains("HELICAL STRAKES DEINSTALLATION") || taskresponse[i].taskName.Contains("MV CABLE INSTALLATION") || taskresponse[i].taskName.Contains("TRANSFORMER CONNECTIONS") || taskresponse[i].taskName.Contains("SWITCHGEAR & GROUND INSTALLATION AND CONNECTIONS") || taskresponse[i].taskName.Contains("TOWER CONTROL CABLES WIRING") || taskresponse[i].taskName.Contains("DISMOUNT AND LOWERING TK FA MTG ELEVATOR GAP COVER") || taskresponse[i].taskName.Contains("SERVICE LIFT INSTALLATION") || taskresponse[i].taskName.Contains("LIGTHNING PROTECTION SYSTEM INSTALLATION") || taskresponse[i].taskName.Contains("PREPARATIONS FOR TRANSPORT EQUIPMENT RETURN") || taskresponse[i].taskName.Contains("MOVE SWITCH & GROUND IN BS THROUGHT ACCESS DOOR") || taskresponse[i].taskName.Contains("CONNECTION SWITCHGEAR TO EXTERNAL LINE") || taskresponse[i].taskName.Contains("PAINTING TOWER FLANGES (INNER)") || taskresponse[i].taskName.Contains("PAINTING TOWER FLANGES (OUTER)"))
                        {
                            Assert.IsNotNull(taskresponse[i].id);
                        }
                        else
                        {
                            Console.WriteLine("For Task id " + taskresponse[i].id + " " + taskresponse[i].taskName + " task name not found");
                            flag = false;
                        }

                    }
                    else if (taskresponse[i].phaseId == 6)
                    {
                        if (taskresponse[i].taskName.Contains("Mechanical Walkdown With C&L Supplier") || taskresponse[i].taskName.Contains("Quality Inspection") || taskresponse[i].taskName.Contains("Snagging Works (C&I Supplier) until Ready to Commissioning"))
                        {
                            Assert.IsNotNull(taskresponse[i].id);
                        }
                        else
                        {
                            Console.WriteLine("For Task id " + taskresponse[i].id + " " + taskresponse[i].taskName + " task name not found");
                            flag = false;
                        }
                    }
                    else if (taskresponse[i].phaseId == 7)
                    {
                        if (taskresponse[i].taskName.Contains("Pre-commissioning") || taskresponse[i].taskName.Contains("Pre-energization tests") || taskresponse[i].taskName.Contains("Energization")     || taskresponse[i].taskName.Contains("Commissioning") || taskresponse[i].taskName.Contains("72h reliability") || taskresponse[i].taskName.Contains("Quality Inspection (FWD)") || taskresponse[i].taskName.Contains("RTs – TOC (Availability test)"))
                        {
                            Assert.IsNotNull(taskresponse[i].id);
                        }
                        else
                        {
                            Console.WriteLine("For Task id " + taskresponse[i].id + " " + taskresponse[i].taskName + " task name not found");
                            flag = false;
                        }
                    }
                    else if (taskresponse[i].phaseId == 8)
                    {
                        if (taskresponse[i].taskName.Contains("General Tasks"))
                        {
                            Assert.IsNotNull(taskresponse[i].id);
                        }
                        else
                        {
                            Console.WriteLine("For Task id " + taskresponse[i].id + " " + taskresponse[i].taskName + " task name not found");
                            flag = false;
                        }
                    }
                    else if (taskresponse[i].phaseId == 9)
                    {
                        if (taskresponse[i].taskName.Contains("Ass Ground Air Conditioner") || taskresponse[i].taskName.Contains("Ass Enviromental Kit Under P0") || taskresponse[i].taskName.Contains("Green Certificate (Poland)") || taskresponse[i].taskName.Contains("Rout Magnetic Presence Sensor") || taskresponse[i].taskName.Contains("Wtg Low Temperatures") || taskresponse[i].taskName.Contains("3m Tape (Lm Blades)") || taskresponse[i].taskName.Contains("Ass Ice Sensor") || taskresponse[i].taskName.Contains("Dust Filter") || taskresponse[i].taskName.Contains("Ass Air Conditioner System") || taskresponse[i].taskName.Contains("Installation Of Fire-Fighting System") || taskresponse[i].taskName.Contains("Assembly Shadow Sensor") || taskresponse[i].taskName.Contains("Assembly Beacon Visibility Sensor") || taskresponse[i].taskName.Contains("Assembly Of A Exterior Light Of The Tower") || taskresponse[i].taskName.Contains("Assembly Protective Caps Bolt Hc Sect") || taskresponse[i].taskName.Contains("Assembly And Route Hygrometer") || taskresponse[i].taskName.Contains("Assembly And Route Hygrometer_Nacelle And Tower") || taskresponse[i].taskName.Contains("Seal Bolts And Flange Joint In Hc Tower") || taskresponse[i].taskName.Contains("Assembly Protective Caps Bolt Hc Nac-Sect") || taskresponse[i].taskName.Contains("Rout&Conect Switch Signal Status") || taskresponse[i].taskName.Contains("Adjust Rotor Brush") || taskresponse[i].taskName.Contains("Op Door For Tower Access Stair") || taskresponse[i].taskName.Contains("Ass Batshield") || taskresponse[i].taskName.Contains("Ass Grease Exhaust Bottles") || taskresponse[i].taskName.Contains("Rout Lubrication System") || taskresponse[i].taskName.Contains("Apply Dinitrol J.E Hub-Bld Hc") || taskresponse[i].taskName.Contains("Assembly Precipitation Sensor") || taskresponse[i].taskName.Contains("Ass Dinotails") || taskresponse[i].taskName.Contains("De-Icing System Electrical Connections") || taskresponse[i].taskName.Contains("Op Ass 1st Aid And Eyewash Kit Sgxx") || taskresponse[i].taskName.Contains("Ass Beacon Mi (On Ground, With Ups Cabinet, With Gps)") || taskresponse[i].taskName.Contains("Ass Beacon Mi (On Ground, Without Ups Cabinet)") || taskresponse[i].taskName.Contains("Dismount Cage Of Transport Of Blades") || taskresponse[i].taskName.Contains("Ass And Wiring X 2 Special Beacons (Nacelle Placed On Ground)") || taskresponse[i].taskName.Contains("Ass And Wiring Tower Special Beacons") || taskresponse[i].taskName.Contains("Dispense Of The Fire Extinguishers") || taskresponse[i].taskName.Contains("Dispense Of The Emergency Descenders"))
                        {
                            Assert.IsNotNull(taskresponse[i].id);
                        }
                        else
                        {
                            Console.WriteLine("For Task id " + taskresponse[i].id + " " + taskresponse[i].taskName + " task name not found");
                            flag = false;
                        }
                    }
                    else
                    {
                        flag = false;
                        Console.WriteLine("Got the wrong roadmap phase name as " + taskresponse[i].taskName + " for id " + taskresponse[i].id);
                    }
                    Assert.IsTrue(flag);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [When(@"Add new corrective action")]
        public async Task WhenAddNewCorrectiveActionAsync()
        {
            try
            {
                AddCorrectiveActionName action = new AddCorrectiveActionName
                {
                    MyArray = new List<string>(new string[] { "Performance #02" })
                };

                var result = await this.ApiExecutor.PutWithResponseAsync(this.commonValues.RequestUrl, action, this.commonValues.cr);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Then(@"corrective action list is updated successfully")]
        public void ThenCorrectiveActionListIsUpdatedSuccessfully()
        {
            try
            {
                Console.WriteLine("tested");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [When(@"Send API request for specific search keyword (.*)")]
        public async Task WhenSendAPIRequestForSpecificSearchKeywordAsync(string search)
        {
            try
            {
                string searchtext = search.ToLower();
                string apiurl = this.commonValues.RequestUrl + "?$filter=contains(tolower(ProjectName),%27" + searchtext + "%27)%20or%20contains(tolower(RegionName),%27" + searchtext + "%27)%20or%20contains(tolower(CountryName),%27" + searchtext + "%27)%20or%20contains(tolower(StatusName),%27" + searchtext + "%27)&$orderby=id%20desc&$count=true&$top=20&$skip=0";
                projectsearchresponse = await this.ApiExecutor.GetAsync<ProjectsBySearch>(apiurl, this.commonValues.cr);
                Console.WriteLine("API responce: " + projectsearchresponse);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Then(@"Get the all the details of project by search")]
        public void ThenGetTheAllTheDetailsOfProjectBySearch()
        {
            try
            {
                if (projectsearchresponse.value.Count > 0)
                {
                    Assert.True(projectsearchresponse.OdataCount > 0, "Get the list of Search result");
                    Assert.True(projectsearchresponse.value.Count > 0, "Get the list of Search result");
                    Console.WriteLine("Number of search count " + projectsearchresponse.value.Count);
                }
                else
                {
                    Console.WriteLine("Number of search count " + projectsearchresponse.value.Count);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
