﻿using Bdd.Core.Api.Executors;
using Bdd.Core.Entities;
using Bdd.Core.StepDefinitions;
using SGRE.SmartSite.Tests.Bdd.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace SGRE.SmartSite.Tests.Bdd.StepDefinitions
{
    [Binding]
    class CommonStepsUI : StepDefinitionBase
    {
        #region - Variable Declarations
        public static string projectName = "AutomationProCreate";
        public static int projectid = 54459;
        public static string customerName = "Cristofer Jones";
        public static string AdditionalStaffName = "Williams Smith";
        public static string AdditionalStaffRole = "SubContractor";
        public static string createdByRole = "Admin";
        public static string createdDateTime = "2021-09-17T10:22:39.679709+00:00";
        string apiUrl = System.Configuration.ConfigurationManager.AppSettings["APIUrl"];

        #endregion

        [Given(@"""(.*)"" user has logged in to Smart Site application")]
        public void GivenUserHasLoggedInToSmartSiteApplication(string userrole)
        {
            var login = new LoginPage(this.DriverContext)
            .LoginToSmartApplication(userrole);
        }

        [Given(@"User has logged into Smart Site Application with user role as (.*)")]
        public void GivenUserHasLoggedIntoSmartSiteApplicationWithUserRoleAs(string userrole)
        {
            var login = new LoginPage(this.DriverContext)
             .LoginToSmartApplication(userrole);
        }

        [When(@"Navigate to the Project Details Tab and select Turbine Tab")]
        public void WhenNavigateToTheProjectDetailsTabAndSelectTurbineTab()
        {
            var SiteSettings = new SiteSettingsPage(this.DriverContext)
               .ValidatePageTitle(projectName)
               .ValidateTurbineTab();
        }

        [When(@"Select Project from left menu pannel")]
        public void WhenSelectProjectFromLeftMenuPannel()
        {
            var SiteSettings = new SiteSettingsPage(this.DriverContext)
              .SelectProjectMenu();
        }

        [When(@"Select project from list")]
        public void WhenSelectProjectFromList()
        {
            var home = new HomePage(this.DriverContext)
                .ValidateSelectProject(projectName);
        }

        [When(@"Click on Create new Project from the Project Dashboard")]
        public void WhenClickOnCreateNewProjectFromTheProjectDashboard()
        {
            var home = new HomePage(this.DriverContext)
               .ValidateCreateNewProjectButton();
        }

        [When(@"Navigate to the Project Details Tab of Site Setting Page")]
        public void WhenNavigateToTheProjectDetailsTabOfSiteSettingPage()
        {
            var SiteSettings = new SiteSettingsPage(this.DriverContext)
               .ValidatePageTitle();
        }

        [Then(@"Select Turbine Tab")]
        public void ThenSelectTurbineTab()
        {
            var SiteSettings = new SiteSettingsPage(this.DriverContext)
               .ValidateTurbineTab();
        }

        [When(@"Select Turbine Tab")]
        public void WhenSelectTurbineTab()
        {
            var SiteSettings = new SiteSettingsPage(this.DriverContext)
               .ValidateTurbineTab();
        }

        [When(@"Navigate to the Project Details Tab and select Resources tab")]
        public void WhenNavigateToTheProjectDetailsTabAndSelectResourcesTab()
        {
            var SiteSettings = new SiteSettingsPage(this.DriverContext)
                .ValidatePageTitle(projectName)
                .ValidateResourcesTab();
        }

        //  [BeforeTestRun]
       /* public static async Task CreateTestProject()
        {
            ApiExecutor api = new ApiExecutor();
            Credentials cr = new Credentials();
            Random randomNumber = new Random();

            var randomNumberString = randomNumber.Next(0, 9999).ToString("0000");
            projectName = "AMTesting" + randomNumberString;

            CreateProject project = new CreateProject
            {
                projectCode = "6443",
                projectName = projectName,
                projectDesc = null,
                plannedStartDate = DateTime.Now,
                plannedEndDate = DateTime.Now,
                swiContractedDate = DateTime.Now,
                area = "ww",
                numberOfWTG = "100",
                projectStatusId = 1,
                regionId = "5",
                countryId = "11",
                latitude = "23",
                longitude = "25"
            };
            Console.WriteLine("plannedStartDate " + project.projectName);
            string baseUrl = System.Configuration.ConfigurationManager.AppSettings["APIUrl"];
            string apiurl = baseUrl + "/project";
            var result = await api.PutAsync<object>(apiurl, project, cr);
            Console.WriteLine("result" + result);

            //await GivenGetAllProjectsListGETAPIFor();
        }*/

        //Get project id
        //public static async Task GivenGetAllProjectsListGETAPIFor()
        //{
        //    try
        //    {
        //        string baseUrl = System.Configuration.ConfigurationManager.AppSettings["APIUrl"];
        //        ApiExecutor api = new ApiExecutor();
        //        Credentials cr = new Credentials();

        //        #region call api and check the responce i.e. status code 
        //        string apiurl = baseUrl + "/projects";
        //        var result = await api.GetAsync<Root>(apiurl, cr);
        //        Console.WriteLine("result " + result);
        //        Console.WriteLine("responseJson " + result.value.Count);
        //        Console.WriteLine(result.value[0].ProjectName);
        //        if(result.value.Count > 0)
        //        {
        //            for(int i =0; i <= result.value.Count; i++)
        //            {
        //                if (result.value[i].ProjectName.Equals(projectName))
        //                {
        //                    projectid = result.value[i].Id;
        //                    break;
        //                }
        //            }
        //        }

        //        /*var result = await api.GetResponseAsync(url, cr);
        //        var responseBody = await result.Content.ReadAsStringAsync();
        //        var responseJson = JsonConvert.DeserializeObject<Root>(responseBody);
        //        Console.WriteLine("responseJson " + responseJson.value.Count);
        //        int APIStatusCode = (int)result.StatusCode;
        //        Assert.AreEqual(APIStatusCode, 200, "Could not get all the projects list");
        //        Assert.NotNull(responseJson, "Project List is empty");*/
        //        #endregion
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //}
    }
}
