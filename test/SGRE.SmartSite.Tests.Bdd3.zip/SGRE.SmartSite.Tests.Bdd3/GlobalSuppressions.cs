﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="GlobalSuppressions.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

// [assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Performance", "CA1822:Mark members as static", Justification = "<Pending>", Scope = "member", Target = "~M:SGRE.SmartSite.Tests.Bdd.StepDefinitions.NanolinkAPIsSteps.ThenDeleteItemFromCosmosDB")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Usage", "CA2237:Mark ISerializable types with serializable", Justification = "Unable to Use Serialize", Scope = "type", Target = "~T:SGRE.SmartSite.Tests.Bdd.Entities.LocationHistoryDictionary")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Usage", "CA2227:Collection properties should be read only", Justification = "Not sure why only getter is allowed", Scope = "member", Target = "~P:SGRE.SmartSite.Tests.Bdd.Entities.LocationData.LocationHistory")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Security", "SCS0005:Weak random generator", Justification = "Week Random Number Generator Error", Scope = "member", Target = "~M:SGRE.SmartSite.Tests.Bdd.Executors.RandomNumbersGeneration.GetRandomNumbers(System.Int32)~System.Collections.Generic.List{System.Int32}")]