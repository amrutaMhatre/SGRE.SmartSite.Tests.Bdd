﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IDataSource.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.DataSources
{
    using System.Collections.Generic;
    using System.Threading.Tasks;

    using TechTalk.SpecFlow;

    public interface IDataSource
    {
        string Input { get; set; }

#pragma warning disable CA2227 // Collection properties should be read only
        ScenarioContext ScenarioContext { get; set; }

        FeatureContext FeatureContext { get; set; }
#pragma warning restore CA2227 // Collection properties should be read only

        Task<IEnumerable<T>> ReadAllAsync<T>(string input = null, string keyPrefix = null, params object[] args);

        Task<T> ReadAsync<T>(string input = null, string keyPrefix = null, params object[] args);
    }
}