﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ServiceBusDataSource.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.DataSources
{
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Globalization;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;

    using Bdd.Core.Entities;
    using Bdd.Core.Utils;

    using Microsoft.Azure.ServiceBus;
    using Microsoft.Azure.ServiceBus.Core;

    using Newtonsoft.Json;

    public class ServiceBusDataSource : StorageDataSource
    {
        private static readonly ConcurrentDictionary<string, string> Connections = new ConcurrentDictionary<string, string>();

        protected static NameValueCollection Settings => ConfigurationManager.GetSection("serviceBus") as NameValueCollection;

        public async Task WriteAllAsync(string queueName, dynamic[] data, string keyPrefix = null)
        {
            var sender = new MessageSender(this.GetConnection(keyPrefix), queueName);
            for (int i = 0; i < data.Length; i++)
            {
                var message = new Message(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(data[i])))
                {
                    ContentType = HttpHeaders.JsonContentKey,
                    MessageId = i.ToString(CultureInfo.InvariantCulture),
                };

                await sender.SendAsync(message).ConfigureAwait(false);
            }
        }

        public async Task<IEnumerable<dynamic>> PeakAllAsync(string queueName, string keyPrefix = null)
        {
            var receiver = new MessageReceiver(this.GetConnection(keyPrefix), queueName, ReceiveMode.PeekLock);
            var messages = new List<Message>();
            while (true)
            {
                var message = await receiver.PeekAsync().ConfigureAwait(false);
                if (message != null)
                {
                    // var body = Encoding.UTF8.GetString(message.Body);
                    messages.Add(message);
                }
                else
                {
                    break;
                }
            }

            await receiver.CloseAsync().ConfigureAwait(false);
            return messages;
        }

        public async Task ReadAllAsync(string queueName, CancellationToken cancellationToken, string keyPrefix = null)
        {
            var messages = new List<Message>();
            var receiver = new MessageReceiver(this.GetConnection(keyPrefix), queueName, ReceiveMode.PeekLock);
            var doneReceiving = new TaskCompletionSource<bool>();
            cancellationToken.Register(
                async () =>
                {
                    await receiver.CloseAsync().ConfigureAwait(false);
                    doneReceiving.SetResult(true);
                });

            receiver.RegisterMessageHandler(
                async (message, cancellationToken1) =>
                {
                    if (message != null && message.ContentType.EqualsIgnoreCase(HttpHeaders.JsonContentKey))
                    {
                        messages.Add(message);
                        await receiver.CompleteAsync(message.SystemProperties.LockToken).ConfigureAwait(false);
                    }
                    else
                    {
                        await receiver.DeadLetterAsync(message.SystemProperties.LockToken).ConfigureAwait(false);
                    }
                },
                new MessageHandlerOptions((e) => throw e.Exception) { AutoComplete = false, MaxConcurrentCalls = 1 });

            await doneReceiving.Task.ConfigureAwait(false);
        }

#pragma warning disable CA1725 // Parameter names should match base declaration
        protected override Task<T> ReadInternalAsync<T>(string queueName = null, string keyPrefix = null, params object[] args)
        {
            throw new System.NotImplementedException();
        }

        protected override Task<IEnumerable<T>> ReadAllInternalAsync<T>(string queueName = null, string keyPrefix = null, params object[] args)
        {
            throw new System.NotImplementedException();
        }
#pragma warning restore CA1725 // Parameter names should match base declaration

        private string GetConnection(string keyPrefix = "")
        {
            var key = $"{nameof(ServiceBusDataSource)}." + (string.IsNullOrWhiteSpace(keyPrefix) ? this.DefaultKeyPrefix : keyPrefix);
            var connString = Connections.GetOrAdd(key, k =>
            {
                var account = this.SetConnection(key, Settings);
                return account.ConnectionString;
            });

            return connString;
        }
    }
}
