﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="StorageDataSource.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.DataSources
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Specialized;
    using System.Linq;
    using System.Threading.Tasks;

    using Bdd.Core.Utils;

    using Microsoft.WindowsAzure.Storage;

    using NLog;

    public abstract class StorageDataSource : DataSourceBase
    {
        protected static readonly ConcurrentDictionary<string, (CloudStorageAccount StorageAccount, string ConnectionString)> StorageAccounts = new ConcurrentDictionary<string, (CloudStorageAccount StorageAccount, string ConnectionString)>();

        protected virtual (CloudStorageAccount StorageAccount, string ConnectionString) SetConnection(string key, NameValueCollection settings)
        {
            var storageAccount = StorageAccounts.GetOrAdd(key, k =>
            {
                var connectionString = this.GetStorageConnectionString(key, settings).GetAwaiter().GetResult();
                CloudStorageAccount account = null;
                try
                {
                    account = CloudStorageAccount.Parse(connectionString); // GetStorageAccount()
                }
#pragma warning disable CA1031 // Do not catch general exception types
                catch (Exception ex)
                {
                    Logger.Warn(ex);
                }
#pragma warning restore CA1031 // Do not catch general exception types

                return (account, connectionString);
            });

            return storageAccount;
        }

        ////private static CloudStorageAccount GetStorageAccount(string accountName, string key, bool useHttps = true)
        ////{
        ////    var storageCredentials = new StorageCredentials(accountName, key);
        ////    var storageAccount = new CloudStorageAccount(storageCredentials, useHttps: useHttps);
        ////    return storageAccount;
        ////}

        private async Task<string> GetStorageConnectionString(string keyPrefix, NameValueCollection settings)
        {
            // Remove the xxxDataSource. prefix that was added to the key in ConcurrentDictionary
            var connectionStringSecretName = settings.GetValue("ConnectionStringKey", string.IsNullOrWhiteSpace(keyPrefix) ? this.DefaultKeyPrefix : keyPrefix.Split(new[] { '.' }, 2).LastOrDefault());
            if (connectionStringSecretName.ContainsIgnoreCase("Endpoint"))
            {
                return connectionStringSecretName;
            }

            var connectionString = (await KeyVaultHelper.GetKeyVaultSecretAsync(connectionStringSecretName).ConfigureAwait(false)).Value;
            return connectionString;
        }
    }
}
