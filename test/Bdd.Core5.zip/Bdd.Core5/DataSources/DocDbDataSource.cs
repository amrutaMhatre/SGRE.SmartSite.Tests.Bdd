﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DocDbDataSource.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.DataSources
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Linq;
    using System.Threading.Tasks;

    using Bdd.Core.Utils;

    using Microsoft.Azure.Documents;
    using Microsoft.Azure.Documents.Client;
    using Microsoft.Azure.KeyVault.Models;

    public class DocDbDataSource : DataSourceBase
    {
        private const string SelectFrom = "SELECT * FROM ";

        private static readonly string DatabaseName = Settings["DatabaseName"];

        private static readonly string CollectionName = Settings["CollectionName"];

        private static readonly string EndpointUrl = Settings["EndPointUrl"];

        private static readonly string SecretKey = Settings["AuthorizationKey"];

        private static readonly FeedOptions DefaultOptions = new FeedOptions { EnableCrossPartitionQuery = true };

        private SecretBundle authKey;

        private static NameValueCollection Settings => ConfigurationManager.GetSection("docDb") as NameValueCollection;

        /// <summary>
        /// This method will upload the specified document to the desired collection - Use this when there is a only one Cosmos Db account for the project
        /// </summary>
        /// <param name="databaseName">Name of the Database where the Collection resides</param>
        /// <param name="collectionName">Name of the collection where the Document should be uploaded</param>
        /// <param name="document">Document object; usually of JObject type</param>
        /// <returns>void</returns>
        public async Task CreateAsync(string databaseName, string collectionName, object document)
        {
            using (var client = new DocumentClient(new Uri(EndpointUrl), await this.GetAuthorizationKey().ConfigureAwait(false), new ConnectionPolicy { ConnectionMode = ConnectionMode.Gateway, ConnectionProtocol = Protocol.Https }))
            {
                await this.CreateAsync(client, databaseName, collectionName, document).ConfigureAwait(false);
            }
        }

        /// <summary>
        /// This method will upload the specified document to the desired collection - - Use this when there are multiple Cosmos DB accounts hence DocumentClient object has to be passed as argument
        /// </summary>
        /// <param name="client">DocumentClient instance</param>
        /// <param name="databaseName">Name of the Database where the Collection resides</param>
        /// <param name="collectionName">Name of the collection where the Document should be uploaded</param>
        /// <param name="document">Document object; usually of JObject type</param>
        /// <returns>void</returns>
        public async Task CreateAsync(DocumentClient client, string databaseName, string collectionName, object document)
        {
            await client.CreateDocumentAsync(UriFactory.CreateDocumentCollectionUri(databaseName, collectionName), document).ConfigureAwait(false);
        }

        /// <summary>
        /// This method deletes all the documents in a collection that match the SQL query result- Use this when there is a only one Cosmos Db account for the project
        /// </summary>
        /// <param name="databaseName">Name of the Database where the Collection resides</param>
        /// <param name="collectionName">Name of the collection where the Document should be uploaded</param>
        /// <param name="partionKeyValue">Value of the Partition key for the collection</param>
        /// <returns>void</returns>
        public async Task DeleteAsync(string databaseName, string collectionName, string partionKeyValue)
        {
            using (var client = new DocumentClient(new Uri(EndpointUrl), await this.GetAuthorizationKey().ConfigureAwait(false), new ConnectionPolicy { ConnectionMode = ConnectionMode.Gateway, ConnectionProtocol = Protocol.Https }))
            {
                await this.DeleteAsync(client, databaseName, collectionName, partionKeyValue).ConfigureAwait(false);
            }
        }

        /// <summary>
        /// This method deletes all the documents in a collection that match the SQL query result - Use this when there are multiple Cosmos DB accounts hence DocumentClient object has to be passed as argument
        /// </summary>
        /// <param name="client">DocumentClient instance</param>
        /// <param name="databaseName">Name of the Database where the Collection resides</param>
        /// <param name="collectionName">Name of the collection where the Document should be uploaded</param>
        /// <param name="partionKeyValue">Value of the Partition key for the collection</param>
        /// <returns>void</returns>
        public async Task DeleteAsync(DocumentClient client, string databaseName, string collectionName, string partionKeyValue)
        {
            foreach (Document document in client.CreateDocumentQuery(
                UriFactory.CreateDocumentCollectionUri(databaseName, collectionName), new SqlQuerySpec(SelectFrom + collectionName), new FeedOptions { EnableCrossPartitionQuery = true }))
            {
                await client.DeleteDocumentAsync(UriFactory.CreateDocumentUri(databaseName, collectionName, document.Id), new RequestOptions { PartitionKey = new PartitionKey(partionKeyValue) }).ConfigureAwait(false);
            }
        }

        /// <summary>
        /// Replaces the Document that matches the Query result with the updated document
        /// </summary>
        /// <param name="client">DocumentClient instance</param>
        /// <param name="databaseName">Name of the Database where the Collection resides</param>
        /// <param name="collectionName">Name of the collection where the Document should be uploaded</param>
        /// <param name="key">key to be used in the WHERE clause of the SQL query</param>
        /// <param name="paramValue">value to filtered for the given KEY</param>
        /// <param name="updatedDoc">json object of the replacement document</param>
        /// <returns>void</returns>
        public async Task UpdateAsync(DocumentClient client, string databaseName, string collectionName, string key, string paramValue, object updatedDoc)
        {
            var option = new FeedOptions { EnableCrossPartitionQuery = true };
            foreach (Document document in GetDocuments(client, databaseName, collectionName, key, paramValue))
            {
                await client.ReplaceDocumentAsync(UriFactory.CreateDocumentUri(databaseName, collectionName, document.Id), updatedDoc).ConfigureAwait(false);
            }
        }

        /// <summary>
        /// Upserts the Document that matches the Query result with the updated document
        /// </summary>
        /// <param name="client">DocumentClient instance</param>
        /// <param name="databaseName">Name of the Database where the Collection resides</param>
        /// <param name="collectionName">Name of the collection where the Document should be uploaded</param>
        /// <param name="key">key to be used in the WHERE clause of the SQL query</param>
        /// <param name="paramValue">value to filtered for the given KEY</param>
        /// <param name="updatedDoc">json object of the updated document</param>
        /// <returns>void</returns>
        public async Task UpsertAsync(DocumentClient client, string databaseName, string collectionName, string key, string paramValue, object updatedDoc)
        {
            var option = new FeedOptions { EnableCrossPartitionQuery = true };
            foreach (Document document in GetDocuments(client, databaseName, collectionName, key, paramValue))
            {
                await client.UpsertDocumentAsync(UriFactory.CreateDocumentUri(databaseName, collectionName, document.Id), updatedDoc).ConfigureAwait(false);
            }
        }

        protected override async Task<IEnumerable<T>> ReadAllInternalAsync<T>(string input = null, string keyPrefix = null, params object[] args)
        {
            using (var client = new DocumentClient(new Uri(EndpointUrl), await this.GetAuthorizationKey().ConfigureAwait(false), new ConnectionPolicy { ConnectionMode = ConnectionMode.Gateway, ConnectionProtocol = Protocol.Https }))
            {
                var collectionUri = UriFactory.CreateDocumentCollectionUri(DatabaseName, CollectionName);
                var queryText = System.IO.File.Exists(input.GetFullPath()) ? input.GetFullPath().GetContent() : input;
                var result = client.CreateDocumentQuery<T>(collectionUri, queryText, DefaultOptions).ToList();
                return result.AsEnumerable();
            }
        }

        protected override async Task<T> ReadInternalAsync<T>(string input = null, string keyPrefix = null, params object[] args)
        {
            using (var client = new DocumentClient(new Uri(EndpointUrl), await this.GetAuthorizationKey().ConfigureAwait(false), new ConnectionPolicy { ConnectionMode = ConnectionMode.Gateway, ConnectionProtocol = Protocol.Https }))
            {
                var collectionUri = UriFactory.CreateDocumentUri(DatabaseName, CollectionName, input);
                var result = await client.ReadDocumentAsync(collectionUri).ConfigureAwait(false);
                return (dynamic)result.Resource;
            }
        }

        private static IQueryable<dynamic> GetDocuments(DocumentClient client, string databaseName, string collectionName, string key, string paramValue)
        {
            return client.CreateDocumentQuery(UriFactory.CreateDocumentCollectionUri(databaseName, collectionName), new SqlQuerySpec(SelectFrom + collectionName + " c WHERE c." + key + " = @param", new SqlParameterCollection(new[] { new SqlParameter { Name = "@param", Value = paramValue } })), new FeedOptions { EnableCrossPartitionQuery = true });
        }

        private async Task<string> GetAuthorizationKey()
        {
            try
            {
                if (this.authKey == null)
                {
                    this.authKey = await KeyVaultHelper.GetKeyVaultSecretAsync(SecretKey).ConfigureAwait(false);
                }

                return this.authKey.Value;
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
            {
                Logger.Warn(ex, ex.Message);
                return SecretKey;
            }
#pragma warning restore CA1031 // Do not catch general exception types
        }
    }
}
