﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AppInsightsDataSource.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.DataSources
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Threading.Tasks;

    using Bdd.Core.Utils;

    using Flurl.Http;

    public class AppInsightsDataSource : DataSourceBase
    {
        private readonly string url = Settings["Url"];

        private readonly string apiKey = Settings["ApiKey"];

        private readonly string apiValue = Settings["ApiValue"];

        private readonly string appId = Settings["AppId"];

        public enum Type
        {
            /// <summary>
            /// Exceptions
            /// </summary>
            Exceptions,

            /// <summary>
            /// Requests
            /// </summary>
            Requests,

            /// <summary>
            /// Traces
            /// </summary>
            Traces,

            /// <summary>
            /// Dependencies
            /// </summary>
            Dependencies,

            /// <summary>
            /// CustomEvents
            /// </summary>
            CustomEvents,

            /// <summary>
            /// CustomMetrics
            /// </summary>
            CustomMetrics,

            /// <summary>
            /// PerformanceCounters
            /// </summary>
            PerformanceCounters,
        }

        private static NameValueCollection Settings => ConfigurationManager.GetSection("appInsights") as NameValueCollection;

        /// <summary>
        /// Method to read logs from application insights using type of log and correlation id.
        /// </summary>
        /// <param name="type"> Type of logs to read.</param>
        /// <param name="operationId"> Correlation Id.</param>
        /// <returns>Logs.</returns>
        public async Task<IEnumerable<dynamic>> ReadAll(Type type, Guid operationId)
        {
            var result = await this.ReadAllInternalAsync<dynamic>(query: type.ToString().ToCamelCase() + " | where operation_Id == '" + operationId + "'").ConfigureAwait(false);
            return result;
        }

#pragma warning disable CA1725 // Parameter names should match base declaration
        public override Task<IEnumerable<T>> ReadAllAsync<T>(string query = null, string keyPrefix = null, params object[] args)
        {
            return base.ReadAllAsync<T>(query, keyPrefix, args);
        }

        public override Task<T> ReadAsync<T>(string query = null, string keyPrefix = null, params object[] args)
        {
            return base.ReadAsync<T>(query, keyPrefix, args);
        }

        protected override async Task<T> ReadInternalAsync<T>(string query = null, string keyPrefix = null, params object[] args)
        {
            var result = await this.url
                        .WithHeader(this.apiKey, this.apiValue)
                        .AppendPathSegment(this.appId)
                        .AppendPathSegment(nameof(query))
                        .SetQueryParam(nameof(query), query)
                        .GetJsonAsync<dynamic>()
                        .ConfigureAwait(false);
            return result;
        }

        protected override async Task<IEnumerable<T>> ReadAllInternalAsync<T>(string query = null, string keyPrefix = null, params object[] args)
        {
            var result = await this.ReadInternalAsync<IEnumerable<T>>(query).ConfigureAwait(false);
            return result;
        }
#pragma warning restore CA1725 // Parameter names should match base declaration
    }
}