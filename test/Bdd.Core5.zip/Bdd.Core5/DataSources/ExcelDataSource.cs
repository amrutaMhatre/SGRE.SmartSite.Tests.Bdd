﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ExcelDataSource.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.DataSources
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Dynamic;
    using System.IO;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    using Bdd.Core.Utils;

    using ExcelDataReader;

    /// <summary>
    /// Excel Data Provider
    /// </summary>
    public class ExcelDataSource : DataSourceBase
    {
        private static readonly SemaphoreSlim Lock = new SemaphoreSlim(1, 1);

        public ExcelDataSource()
            : this(false)
        {
        }

        public ExcelDataSource(bool removeSpacesFromColumnNames, bool hasHeaderRecord = true, Dictionary<string, string> columnMappings = null)
        {
            this.RemoveSpacesFromColumnNames = removeSpacesFromColumnNames;
            this.HasHeaderRecord = hasHeaderRecord;
            this.ColumnMappings = columnMappings;
        }

        public bool RemoveSpacesFromColumnNames { get; set; }

        public bool HasHeaderRecord { get; set; }

#pragma warning disable CA2227 // Collection properties should be read only
        public Dictionary<string, string> ColumnMappings { get; set; }
#pragma warning restore CA2227 // Collection properties should be read only

        protected override async Task<IEnumerable<T>> ReadAllInternalAsync<T>(string input = null, string keyPrefix = null, params object[] args)
        {
            var result = await this.ReadAsync<IEnumerable<T>>(input).ConfigureAwait(false);
            return result;
        }

        protected override async Task<T> ReadInternalAsync<T>(string input = null, string keyPrefix = null, params object[] args)
        {
            try
            {
                var value = input.GetFullPath();
                await Lock.WaitAsync().ConfigureAwait(false);
                //// var temp = Path.Combine(Path.GetDirectoryName(input), DateTime.Now.Ticks + ".xlsx");
                //// Console.WriteLine(temp);
                //// File.Copy(input, temp, true);
                using (var stream = File.Open(value, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    using (var reader = ExcelReaderFactory.CreateReader(stream))
                    {
                        do
                        {
                            while (reader.Read())
                            {
                                // reader.GetDouble(0);
                            }
                        }
                        while (reader.NextResult());

                        var options = new ExcelDataSetConfiguration
                        {
                            UseColumnDataType = true,
                            ConfigureDataTable = tableReader => new ExcelDataTableConfiguration
                            {
                                EmptyColumnNamePrefix = "Column",
                                UseHeaderRow = this.HasHeaderRecord,
                                FilterRow = rowReader => true,
                            },
                        };

                        DataTable table = string.IsNullOrWhiteSpace(keyPrefix) ? reader.AsDataSet(options).Tables[0] : reader.AsDataSet(options).Tables[keyPrefix];
                        var result = table.Select().ToList<ExpandoObject>(this.RemoveSpacesFromColumnNames, this.ColumnMappings);
                        return (dynamic)result;
                    }
                }

                //// File.Delete(temp);
            }
            finally
            {
                Lock.Release();
            }
        }
    }
}