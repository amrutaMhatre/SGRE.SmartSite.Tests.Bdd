﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CsvDataSource.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.DataSources
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    using Bdd.Core.Utils;

    using CsvHelper;

    public class CsvDataSource : DataSourceBase
    {
        private static readonly SemaphoreSlim Lock = new SemaphoreSlim(1, 1);

        public CsvDataSource()
            : this(false)
        {
        }

        public CsvDataSource(bool removeSpacesFromColumnNames, bool hasHeaderRecord = true, Dictionary<string, string> columnMappings = null)
        {
            this.RemoveSpacesFromColumnNames = removeSpacesFromColumnNames;
            this.HasHeaderRecord = hasHeaderRecord;
            this.ColumnMappings = columnMappings;
        }

        public bool RemoveSpacesFromColumnNames { get; set; }

        public bool HasHeaderRecord { get; set; }

#pragma warning disable CA2227 // Collection properties should be read only
        public Dictionary<string, string> ColumnMappings { get; set; }
#pragma warning restore CA2227 // Collection properties should be read only

        public async Task WriteAll<T>(IEnumerable<T> records, string output)
        {
            try
            {
                await Lock.WaitAsync().ConfigureAwait(false);
                using (var textWriter = new StreamWriter(output))
                {
                    using (var csvWriter = new CsvWriter(textWriter))
                    {
                        csvWriter.WriteRecords(records);
                    }
                }
            }
            finally
            {
                Lock.Release();
            }
        }

        public async Task WriteAll(IEnumerable records, string output, List<string> columnNames)
        {
            try
            {
                await Lock.WaitAsync().ConfigureAwait(false);
                using (var writer = new StreamWriter(output))
                {
                    using (var csv = new CsvWriter(writer))
                    {
                        columnNames.ForEach(item => csv.WriteField(item));
                        csv.NextRecord();

                        foreach (var item in records)
                        {
                            foreach (var v in (IDictionary<string, object>)item)
                            {
                                csv.WriteField(v.Value);
                            }

                            csv.NextRecord();
                        }

                        writer.Flush();
                    }
                }
            }
            finally
            {
                Lock.Release();
            }
        }

        protected override async Task<IEnumerable<T>> ReadAllInternalAsync<T>(string input = null, string keyPrefix = null, params object[] args)
        {
            var result = default(IEnumerable<T>);
            try
            {
                await Lock.WaitAsync().ConfigureAwait(false);
                using (var textReader = new StreamReader(input.GetFullPath()))
                {
                    using (var csvReader = this.ColumnMappings?.Count > 0 || this.RemoveSpacesFromColumnNames ? new CsvReader(textReader, new CsvHelper.Configuration.Configuration { HasHeaderRecord = this.HasHeaderRecord, PrepareHeaderForMatch = this.HandleColumnHeaders() }) : new CsvReader(textReader))
                    {
                        var list = csvReader.GetRecords<T>().ToList();
                        result = list.AsEnumerable();
                    }
                }
            }
            finally
            {
                Lock.Release();
            }

            return result;
        }

        protected override async Task<T> ReadInternalAsync<T>(string input = null, string keyPrefix = null, params object[] args)
        {
            var result = default(T);
            try
            {
                await Lock.WaitAsync().ConfigureAwait(false);
                using (var textReader = new StreamReader(input.GetFullPath()))
                {
                    using (var csvReader = this.ColumnMappings?.Count > 0 || this.RemoveSpacesFromColumnNames ? new CsvReader(textReader, new CsvHelper.Configuration.Configuration { HasHeaderRecord = this.HasHeaderRecord, PrepareHeaderForMatch = this.HandleColumnHeaders() }) : new CsvReader(textReader))
                    {
                        result = csvReader.GetRecord<T>();
                    }
                }
            }
            finally
            {
                Lock.Release();
            }

            return result;
        }

        private Func<string, int, string> HandleColumnHeaders()
        {
            // TODO: Handle ColumnMappings
            return (header, i) => this.ColumnMappings?.ContainsKey(header) == true ? this.ColumnMappings[header] : (this.RemoveSpacesFromColumnNames ? header.Replace(" ", string.Empty) : header);
        }
    }
}