﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="TableStorageDataSource.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.DataSources
{
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Linq;
    using System.Net;
    using System.Threading.Tasks;

    using Bdd.Core.Utils;

    using Microsoft.WindowsAzure.Storage.Table;

    public class TableStorageDataSource : StorageDataSource
    {
        protected static readonly ConcurrentDictionary<string, CloudTableClient> Clients = new ConcurrentDictionary<string, CloudTableClient>();

        private static NameValueCollection Settings => ConfigurationManager.GetSection("tableStorage") as NameValueCollection;

        public List<DynamicTableEntity> ReadAll(string tableName, string keyPrefix = null)
        {
            var table = this.GetTableClient(keyPrefix).GetTableReference(tableName);
            var entities = table.ExecuteQuery(new TableQuery<DynamicTableEntity>()).ToList();
            return entities;
        }

        public async Task<IEnumerable<TableEntity>> ReadAllSegmented<TEntity>(string tableName, string keyPrefix = null)
                    where TEntity : TableEntity, new()
        {
            var result = new List<TEntity>();
            var table = this.GetTableClient(keyPrefix).GetTableReference(tableName);
            TableContinuationToken token = null;
            do
            {
                var queryResult = await table.ExecuteQuerySegmentedAsync(new TableQuery<TEntity>(), token).ConfigureAwait(false);
                result.AddRange(queryResult.Results);
                token = queryResult.ContinuationToken;
            }
            while (token != null);
            return result;
        }

        public async Task<int> DeleteAllAsync<TEntity>(string tableName, IEnumerable<TEntity> entities, string keyPrefix = null)
            where TEntity : TableEntity, new()
        {
            var table = this.GetTableClient(keyPrefix).GetTableReference(tableName);
            var batches = new Dictionary<string, TableBatchOperation>();
            int deletedRecordsCount = 0;
            foreach (var entity in entities)
            {
                TableBatchOperation batch = null;
                if (!batches.TryGetValue(entity.PartitionKey, out batch))
                {
                    batches[entity.PartitionKey] = batch = new TableBatchOperation();
                }

                batch.Add(TableOperation.Delete(entity));

                // When the batch size reaches 100, delete this batch and proceed further
                if (batch.Count == 100)
                {
                    var result = await table.ExecuteBatchAsync(batch).ConfigureAwait(false);
                    deletedRecordsCount += result.Count(r => r.HttpStatusCode == (int)HttpStatusCode.NoContent);
                    batches[entity.PartitionKey] = new TableBatchOperation();
                }
            }

            // delete the last batch which would have less than 100 records by now
            foreach (var batch in batches.Values)
            {
                if (batch.Count > 0)
                {
                    var result = await table.ExecuteBatchAsync(batch).ConfigureAwait(false);
                    deletedRecordsCount += result.Count(r => r.HttpStatusCode == (int)HttpStatusCode.NoContent);
                }
            }

            return deletedRecordsCount;
        }

        public async Task<IEnumerable<TEntity>> ReadAllAsync<TEntity>(string tableName, string keyPrefix = null)
            where TEntity : TableEntity, new()
        {
            List<TEntity> result = new List<TEntity>();
            var table = this.GetTableClient(keyPrefix).GetTableReference(tableName);
            TableContinuationToken token = null;
            do
            {
                var queryResult = await table.ExecuteQuerySegmentedAsync(new TableQuery<TEntity>(), token).ConfigureAwait(false);
                result.AddRange(queryResult.Results);
                token = queryResult.ContinuationToken;
            }
            while (token != null);
            return result;
        }

#pragma warning disable CA1725 // Parameter names should match base declaration
        protected override Task<T> ReadInternalAsync<T>(string tableName = null, string keyPrefix = null, params object[] args)
        {
            throw new System.NotImplementedException();
        }

        protected override Task<IEnumerable<T>> ReadAllInternalAsync<T>(string tableName = null, string keyPrefix = null, params object[] args)
        {
            throw new System.NotImplementedException();
        }
#pragma warning restore CA1725 // Parameter names should match base declaration

        private CloudTableClient GetTableClient(string keyPrefix = "")
        {
            var key = $"{nameof(TableStorageDataSource)}." + (string.IsNullOrWhiteSpace(keyPrefix) ? this.DefaultKeyPrefix : keyPrefix);
            var client = Clients.GetOrAdd(key, k =>
            {
                var account = this.SetConnection(key, Settings);
                return account.StorageAccount.CreateCloudTableClient();
            });

            return client;
        }
    }
}