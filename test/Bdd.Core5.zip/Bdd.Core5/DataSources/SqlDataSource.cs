﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SqlDataSource.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.DataSources
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Dynamic;
    using System.Globalization;
    using System.Linq;
    using System.Threading.Tasks;

    using Bdd.Core.Hooks;
    using Bdd.Core.Utils;

    using Dapper;

    using NLog;

    using SmartFormat;

    public class SqlDataSource : DataSourceBase
    {
        protected static readonly ConcurrentDictionary<string, SqlConnectionStringBuilder> ConnectionStrings = new ConcurrentDictionary<string, SqlConnectionStringBuilder>();

        protected static readonly ConcurrentDictionary<string, string> AccessTokens = new ConcurrentDictionary<string, string>();

        private SqlConnectionStringBuilder connection = null;

        private string accessToken = null;

        public static Func<string, Task<string>> AccessTokenCallback { get; set; }

        public static Func<string, Task<SqlConnectionStringBuilder>> ConnectionBuilderCallback { get; set; }

        // Single-Row with Multiple-Columns when the Key can only be provided at runtime
        public async Task<IDictionary<string, object>> ReadAsDictionaryAsync(string input, string keyPrefix = null, params object[] args)
        {
            // return this.ReadAsync<IDictionary<string, object>>(input, keyPrefix, args);
            return (IDictionary<string, object>)await this.ReadAsync<dynamic>(input, keyPrefix, args).ConfigureAwait(false);
        }

        public async Task<IDictionary<string, string>> ReadAsStringDictionaryAsync(string input, string keyPrefix = null, params object[] args)
        {
            return (await this.ReadAsDictionaryAsync(input, keyPrefix, args).ConfigureAwait(false))?.ToStringDictionary();
        }

        // Single-Row with Multiple-Columns when the Key can be provided at compile-time
        public async Task<dynamic> ReadAsExpandoAsync(string input, string keyPrefix = null, params object[] args)
        {
            // return (await this.ReadSqlAsDictionaryAsync(input, keyPrefix, args).ConfigureAwait(false)).ToExpando();
            object result = await this.ReadAsync<dynamic>(input, keyPrefix, args).ConfigureAwait(false);
            return result.ToObject<ExpandoObject>();
        }

        // Multiple-Rows with Multiple-Columns when the Key can only be provided at runtime
        public async Task<IEnumerable<IDictionary<string, object>>> ReadAllAsDictionaryAsync(string input, string keyPrefix = null, params object[] args)
        {
            // return this.ReadAllAsync<IDictionary<string, object>>(input, keyPrefix, args);
            return (await this.ReadAllAsync<dynamic>(input, keyPrefix, args).ConfigureAwait(false)).Cast<IDictionary<string, object>>();
        }

        // Multiple-Rows with Multiple-Columns when the Key can be provided at compile-time
        public async Task<IEnumerable<dynamic>> ReadAllAsExpandoAsync(string input, string keyPrefix = null, params object[] args)
        {
            // return (await this.ReadAllSqlAsDictionaryAsync(input, keyPrefix, args).ConfigureAwait(false)).ToExpandoList();
            IEnumerable<object> result = await this.ReadAllAsync<dynamic>(input, keyPrefix, args).ConfigureAwait(false);
            return result.Select(x => x.ToObject<ExpandoObject>());
        }

        protected override async Task<IEnumerable<T>> ReadAllInternalAsync<T>(string input = null, string keyPrefix = null, params object[] args)
        {
            var value = System.IO.File.Exists(input.GetFullPath()) ? input.GetFullPath().GetContent() : Smart.Format(CultureInfo.InvariantCulture, input, args);
            this.SetConnection(keyPrefix);
            using (var db = new SqlConnection(this.connection?.ConnectionString))
            {
                if (!string.IsNullOrWhiteSpace(this.accessToken))
                {
                    db.AccessToken = this.accessToken;
                }

                IEnumerable<T> result;

                if (args?.Length > 0)
                {
                    result = (await db.QueryAsync<T>(value, args[0]).ConfigureAwait(false)).ToList();
                }
                else
                {
                    result = (await db.QueryAsync<T>(value).ConfigureAwait(false)).ToList();
                }

                return result;
            }
        }

        protected override async Task<T> ReadInternalAsync<T>(string input = null, string keyPrefix = null, params object[] args)
        {
            var value = System.IO.File.Exists(input.GetFullPath()) ? input.GetFullPath().GetContent() : Smart.Format(CultureInfo.InvariantCulture, input, args);
            this.SetConnection(keyPrefix);
            using (var db = new SqlConnection(this.connection?.ConnectionString))
            {
                if (!string.IsNullOrWhiteSpace(this.accessToken))
                {
                    db.AccessToken = this.accessToken;
                }

                if (args?.Length > 0)
                {
                    return await db.QuerySingleOrDefaultAsync<T>(value, args[0]).ConfigureAwait(false);
                }

                return await db.QuerySingleOrDefaultAsync<T>(value).ConfigureAwait(false);
            }
        }

        protected virtual SqlConnectionStringBuilder SetConnectionBuilder(string keyPrefix = null)
        {
            if (this.connection == null)
            {
                try
                {
                    if (keyPrefix == null)
                    {
                        keyPrefix = this.DefaultKeyPrefix;
                    }

                    this.connection = this.GetConnectionBuilder(keyPrefix);
                }
                catch (Exception ex)
                {
                    Logger.Warn(ex);
                }
            }

            return this.connection;
        }

        protected virtual void SetAccessToken(string keyPrefix)
        {
            if (string.IsNullOrWhiteSpace(this.accessToken))
            {
                try
                {
                    if (keyPrefix == null)
                    {
                        keyPrefix = this.DefaultKeyPrefix;
                    }

                    this.accessToken = this.GetAccessToken(keyPrefix);
                }
                catch (Exception ex)
                {
                    Logger.Warn(ex);
                }
            }
        }

        protected virtual string GetAccessToken(string key)
        {
            if (AccessTokenCallback == null)
            {
                // Fall back to default implementation
                AccessTokenCallback = SqlConnectionConfig.AccessTokenCallback;
            }

            var accessToken = AccessTokens.GetOrAdd(key, k => AccessTokenCallback(k).GetAwaiter().GetResult());
            return accessToken;
        }

        protected virtual SqlConnectionStringBuilder GetConnectionBuilder(string key)
        {
            if (ConnectionBuilderCallback == null)
            {
                // Fall back to default implementation
                ConnectionBuilderCallback = SqlConnectionConfig.ConnectionBuilderCallback;
            }

            var connBuilder = ConnectionStrings.GetOrAdd(key, k => ConnectionBuilderCallback(k).GetAwaiter().GetResult());
            return connBuilder;
        }

        private void SetConnection(string keyPrefix)
        {
            this.SetConnectionBuilder(keyPrefix);
            this.SetAccessToken(keyPrefix);
        }
    }
}