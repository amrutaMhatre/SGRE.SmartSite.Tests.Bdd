﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RuntimeInvocationDataSource.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.DataSources
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Threading.Tasks;

    using Bdd.Core.Hooks;
    using Bdd.Core.Utils;

    using NLog;

    using TechTalk.SpecFlow;

#pragma warning disable SA1008 // Opening parenthesis must be spaced correctly
#pragma warning disable SA1101 // Prefix local calls with this
    public class RuntimeInvocationDataSource : DataSourceBase
    {
        private const string SpaceDelimiter = "^";
        private const string Space = " ";
        private const char ParametersDelimiter = ',';
        private static readonly char[] ParametersContainer = new char[] { '(', ')' };
        private static readonly Type[] BeforeAfterExecutorsTypes = AppDomain.CurrentDomain.GetAssemblies().Where(p => !p.IsDynamic)
                                                                .SelectMany(x => x.GetExportedTypes())
                                                                .Where(t => t.IsClass && t.GetCustomAttribute(typeof(RuntimeInvocationAttribute), true) != null).ToArray();

        private static Dictionary<Type, MethodInfo[]> beforeAfterExecutorMethods = null;

        public static Dictionary<Type, MethodInfo[]> BeforeAfterExecutorMethods
        {
            get
            {
                if (beforeAfterExecutorMethods == null)
                {
                    beforeAfterExecutorMethods = BeforeAfterExecutorsTypes.ToDictionary(t => t, t => t.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly).ToArray()); //// BindingFlags.IgnoreCase
                }

                return beforeAfterExecutorMethods;
            }
        }

        protected override Task<IEnumerable<T>> ReadAllInternalAsync<T>(string input = null, string keyPrefix = null, params object[] args)
        {
            var result = this.Execute<IEnumerable<T>>(input);
            return result;
        }

        protected override Task<T> ReadInternalAsync<T>(string input = null, string keyPrefix = null, params object[] args)
        {
            var result = this.Execute<T>(input);
            return result;
        }

        // ------------------------------------------------------------------------------------
        // NOTE: The @before/@after tag-values should not have SPACES (even between the args)!
        // To have a SPACE, use the ^ symbol
        // e.g.:
        // WRONG: @before=SomeMethod(1, vamsi)
        // RIGHT: @before=SomeMethod(1,vamsi)
        // WRONG: @before=SomeMethod(1, "vamsi tp")
        // RIGHT: @before=SomeMethod(1,vamsi^tp)
        // ------------------------------------------------------------------------------------
        protected async Task<T> Execute<T>(string input)
        {
            var inputs = input.Split('=');
            var tag = inputs.FirstOrDefault();
            var tagValue = inputs.LastOrDefault();
            try
            {
                if (!string.IsNullOrEmpty(tagValue))
                {
                    var split = tagValue.Split(ParametersContainer, StringSplitOptions.RemoveEmptyEntries);
                    var typeNameAndMethodName = split.FirstOrDefault().Split(new[] { '.' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                    var methodName = typeNameAndMethodName.LastOrDefault();
                    var typeName = typeNameAndMethodName.Count > 1 ? string.Join(".", typeNameAndMethodName.Take(typeNameAndMethodName.Count - 1)) : string.Empty;
                    var parameters = new List<string>();
                    if (split.Length > 1)
                    {
                        parameters = split.LastOrDefault().Split(new[] { ParametersDelimiter }, StringSplitOptions.None).Select(x => x?.Trim()?.Replace(SpaceDelimiter, Space))?.ToList();
                    }

                    var typesWithMethods = BeforeAfterExecutorMethods.Select(y => (Type: y.Key, Method: y.Value.SingleOrDefault(x => IsMatch(x, methodName, typeName, parameters))));
                    var count = typesWithMethods.Count(x => x.Method != null);
                    if (count == 1)
                    {
                        var typeAndMethod = typesWithMethods.SingleOrDefault(x => x.Method != null);
                        var args = PopulateArgs(tag, parameters, typeAndMethod.Method);

                        // var constructorParams = typeAndMethod.Type.GetConstructorContextParameters(this.ScenarioContext, this.FeatureContext);
                        var instance = Activator.CreateInstance(typeAndMethod.Type);
                        foreach (var property in typeAndMethod.Type.GetProperties())
                        {
                            if (property.PropertyType == typeof(ScenarioContext))
                            {
                                property.SetValue(instance, this.ScenarioContext, null);
                            }
                            else if (property.PropertyType == typeof(FeatureContext))
                            {
                                property.SetValue(instance, this.FeatureContext, null);
                            }
                        }

                        dynamic result = typeAndMethod.Method?.Invoke(
                            typeAndMethod.Method.IsStatic ? null : instance, //// (constructorParams != null ? Activator.CreateInstance(typeAndMethod.Type, constructorParams) : Activator.CreateInstance(typeAndMethod.Type)),
                            args.ToArray());

                        // Only return if it has a return-type or a generic-Task
                        var finalResult = default(T);
                        if (typeAndMethod.Method.ReturnType != null)
                        {
                            if (typeAndMethod.Method.IsTask())
                            {
                                if (typeAndMethod.Method.ReturnType.GenericTypeArguments.Length > 0)
                                {
                                    var waitedResult = await result;
                                    finalResult = (T)waitedResult;
                                }
                                else
                                {
                                    await result;
                                }
                            }
                            else
                            {
                                finalResult = (T)result;
                            }
                        }

                        return finalResult;
                    }
                    else if (count == 0)
                    {
                        var warn = $"'{split.FirstOrDefault()}' with no/given parameters does not exist.";
                        throw new MissingMethodException(warn);
                    }
                    else if (count > 1)
                    {
                        var warn = $"Prefix/qualify '{split.FirstOrDefault()}' with {string.Join(" (or) ", typesWithMethods.Select(x => x.Type.FullName))} as it's defined with the same name/parameters in multiple classes.";
                        throw new MethodAccessException(warn);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error(await ex.ToFullStringAsync().ConfigureAwait(false));
                throw;
            }

            return default(T);
        }

        private static bool IsMatch(MethodInfo runtimeMethod, string methodName, string typeName, List<string> parameters)
        {
            var match = false;
            var matches = MatchMethod(runtimeMethod, methodName, typeName);

            if (matches == 1)
            {
                match = true;
            }
            else if (matches > 1)
            {
                match = MatchParameters(runtimeMethod, parameters.Count);
            }

            return match;
        }

        private static int MatchMethod(MethodInfo runtimeMethod, string methodName, string typeName)
        {
            var fullMethodName = string.IsNullOrWhiteSpace(typeName) ? methodName : $"{typeName}.{methodName}";
            var result = BeforeAfterExecutorMethods.Count(x => x.Value.Any(y =>
            {
                var match = false;
                if (y.Equals(runtimeMethod))
                {
                    if (!string.IsNullOrWhiteSpace(typeName))
                    {
                        if (typeName.Contains(".")) //// Namespace & Type-name
                        {
                            match = fullMethodName.Equals($"{y.ReflectedType.Namespace}.{y.ReflectedType.Name}.{y.Name}", StringComparison.OrdinalIgnoreCase);
                        }
                        else //// Just Type-name
                        {
                            match = fullMethodName.Equals($"{y.ReflectedType.Name}.{y.Name}", StringComparison.OrdinalIgnoreCase);
                        }
                    }
                    else //// Just Method-name
                    {
                        match = fullMethodName.Equals(y.Name, StringComparison.OrdinalIgnoreCase);
                    }
                }

                return match;
            }));

            return result;
        }

        private static bool MatchParameters(MethodInfo runtimeMethod, int parametersCount)
        {
            // var isArrayType = runtimeMethod.GetParameters().Any(arg => arg.GetCustomAttribute(typeof(ParamArrayAttribute)) != null);
            var isArrayType = runtimeMethod.GetParameters()?.LastOrDefault()?.ParameterType?.IsArray;
            var match = isArrayType.HasValue && isArrayType.Value ? runtimeMethod.GetParameters().Count() <= parametersCount : runtimeMethod.GetParameters().Count() == parametersCount;
            return match;
        }

        private List<object> PopulateArgs(string tag, List<string> parameters, MethodInfo method)
        {
            var args = new List<object>();
            var parameterTypes = method?.GetParameters()?.Select(x => (Name: x.Name, Type: x.ParameterType))?.ToArray();
            if (parameterTypes.Length > 0)
            {
                for (var i = 0; i < parameterTypes.Length; i++)
                {
                    var paramType = parameterTypes[i];
                    if (paramType.Type.IsArray)
                    {
                        args.Add(Convert.ChangeType(parameters.GetRange(i, parameters.Count - i).ToArray(), paramType.Type, CultureInfo.InvariantCulture));
                    }
                    else
                    {
                        var arg = i < parameters.Count ? parameters[i] : null;
                        object p = null;
                        if (arg == null)
                        {
                            var val = p?.ToString();
                            p = paramType.Name.GetContextValue<dynamic>(val, this.ScenarioContext, this.FeatureContext) ?? p;
                        }
                        else if (SpecFlowExtensions.DataSources.Any(x => x.Key.Equals(Path.GetExtension(arg), StringComparison.OrdinalIgnoreCase)) && arg.IndexOfAny(new[] { '/', '\\' }) == -1)
                        {
                            // If there's a file with supported extension and it does not have a parent-path (just file-name with no '/' or '\'), get the parent-folder from AppSettings based on the Before/After tag
                            var folder = ConfigurationManager.AppSettings[tag];
                            p = Convert.ChangeType(Path.Combine(folder, arg), paramType.Type, CultureInfo.InvariantCulture);
                        }
                        else
                        {
                            p = Convert.ChangeType(arg, paramType.Type, CultureInfo.InvariantCulture);
                        }

                        args.Add(p);
                    }
                }
            }

            return args;
        }
    }
#pragma warning restore SA1101 // Prefix local calls with this
#pragma warning restore SA1008 // Opening parenthesis must be spaced correctly
}