﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DataLakeDataSource.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.DataSources
{
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Net.Http;
    using System.Threading.Tasks;

    using Bdd.Core.Utils;

    using Flurl.Http;

    using Microsoft.Identity.Client;

    /// <summary>
    /// Data Lake Utility class.
    /// </summary>
    public class DataLakeDataSource
    {
        /// <summary>
        /// Client Id.
        /// </summary>
        private static readonly string ClientId = Settings.GetValue(nameof(ClientId));

        /// <summary>
        /// Client Secret.
        /// </summary>
        private static readonly string ClientSecret = Settings.GetValue(nameof(ClientSecret), string.Empty, true);

        /// <summary>
        /// Tenant Id.
        /// </summary>
        private static readonly string TenantId = Settings.GetValue(nameof(TenantId));

        private static NameValueCollection Settings => ConfigurationManager.GetSection("dataLake") as NameValueCollection;

        /// <summary>
        /// Reads file from ADL Gen2 storage
        /// </summary>
        /// <param name="accountName">Account Name</param>
        /// <param name="dnsSuffix">DNS Suffix</param>
        /// <param name="fileSystem">File System</param>
        /// <param name="filePath">File Path</param>
        /// <returns>Returns the http response</returns>
        public async Task<HttpResponseMessage> Read(string accountName, string dnsSuffix, string fileSystem, string filePath)
        {
            var accessToken = await this.GenerateAccessTokenAsync().ConfigureAwait(false);
            var endpoint = "https://" + accountName + "." + dnsSuffix + "/" + fileSystem + "/" + filePath;
            var response = await endpoint.WithOAuthBearerToken(accessToken).WithHeader("x-ms-version", "2018-11-09").GetAsync().ConfigureAwait(false);
            return response;
        }

        private async Task<string> GenerateAccessTokenAsync()
        {
            var cca = ConfidentialClientApplicationBuilder.Create(ClientId)
                 .WithClientSecret(ClientSecret)
                 .WithTenantId(TenantId)
                 .Build();
            var scopes = new string[] { "https://storage.azure.com/.default" };
            var result = await cca.AcquireTokenForClient(scopes).ExecuteAsync().ConfigureAwait(false);
            return result.AccessToken;
        }
    }
}