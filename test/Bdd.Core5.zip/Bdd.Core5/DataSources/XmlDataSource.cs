﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="XmlDataSource.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.DataSources
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using System.Xml;
    using System.Xml.Serialization;

    using Bdd.Core.Utils;

    public class XmlDataSource : DataSourceBase
    {
        protected override Task<IEnumerable<T>> ReadAllInternalAsync<T>(string input = null, string keyPrefix = null, params object[] args)
        {
            IEnumerable<T> value;
#pragma warning disable SG0018 // Path traversal
#pragma warning disable CA3075 // Insecure DTD processing in XML
            using (var reader = XmlReader.Create(input.GetFullPath(), new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit }))
#pragma warning restore CA3075 // Insecure DTD processing in XML
#pragma warning restore SG0018 // Path traversal
            {
                try
                {
                    var ser = new XmlSerializer(typeof(T), new XmlRootAttribute()); // TODO: Take rootName as param
                    value = (IEnumerable<T>)ser.Deserialize(reader);
                }
                catch (InvalidOperationException ex) //// Due to not providing root-name
                {
                    Logger.Warn(input + ": " + ex.Message);
                    var ser = new XmlSerializer(typeof(T), new XmlRootAttribute(reader.Name) { IsNullable = true });
                    value = (IEnumerable<T>)ser.Deserialize(reader);
                }
            }

            return Task.FromResult(value);
        }

        protected override Task<T> ReadInternalAsync<T>(string input = null, string keyPrefix = null, params object[] args)
        {
            T value;
#pragma warning disable SG0018 // Path traversal
#pragma warning disable CA3075 // Insecure DTD processing in XML
            using (var reader = XmlReader.Create(input.GetFullPath(), new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit }))
#pragma warning restore CA3075 // Insecure DTD processing in XML
#pragma warning restore SG0018 // Path traversal
            {
                try
                {
                    var ser = new XmlSerializer(typeof(T), new XmlRootAttribute());
                    value = (T)ser.Deserialize(reader);
                }
                catch (InvalidOperationException ex) //// Due to not providing root-name
                {
                    Logger.Warn(input + ": " + ex.Message);
                    var ser = new XmlSerializer(typeof(T), new XmlRootAttribute(reader.Name) { IsNullable = true });
                    value = (T)ser.Deserialize(reader);
                }
            }

            return Task.FromResult(value);
        }
    }
}