﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BlobStorageDataSource.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.DataSources
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;

    using Bdd.Core.Utils;

    using Microsoft.WindowsAzure.Storage;
    using Microsoft.WindowsAzure.Storage.Blob;

    public class BlobStorageDataSource : StorageDataSource
    {
        protected static readonly ConcurrentDictionary<string, CloudBlobClient> Clients = new ConcurrentDictionary<string, CloudBlobClient>();

        private static NameValueCollection Settings => ConfigurationManager.GetSection("blobStorage") as NameValueCollection;

        public async Task<CloudBlockBlob> UploadAsync(CloudBlobContainer cloudBlobContainer, string blobName, string filePath)
        {
            var cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(blobName);
            await cloudBlockBlob.UploadFromFileAsync(filePath).ConfigureAwait(false);
            return cloudBlockBlob;
        }

        public IEnumerable<CloudBlobContainer> ReadAll(string keyPrefix = null)
        {
            return this.GetBlobClient(keyPrefix).ListContainers().OfType<CloudBlobContainer>();
        }

        public IEnumerable<CloudBlockBlob> ReadAll(CloudBlobContainer cloudBlobContainer)
        {
            return cloudBlobContainer.ListBlobs().OfType<CloudBlockBlob>();
        }

        public CloudBlobContainer Read(string containerName, string keyPrefix = null)
        {
            return this.GetBlobClient(keyPrefix).GetContainerReference(containerName);
        }

        public Task<CloudBlockBlob> Read(CloudBlobContainer cloudBlobContainer, string blobName)
        {
            return Task.FromResult(cloudBlobContainer.GetBlockBlobReference(blobName));
        }

        public async Task Download(CloudBlockBlob cloudBlockBlob, string path)
        {
            await cloudBlockBlob.DownloadToFileAsync(path, FileMode.Create).ConfigureAwait(false);
        }

        public async Task Delete(CloudBlockBlob cloudBlockBlob)
        {
            await cloudBlockBlob.DeleteIfExistsAsync().ConfigureAwait(false);
        }

        public async Task<bool> CleanAsync(string containerName, string keyPrefix = null)
        {
            try
            {
                var cloudBlobClient = this.GetBlobClient(keyPrefix);
                if (string.IsNullOrEmpty(containerName))
                {
                    BlobContinuationToken containerToken = null;
                    do
                    {
                        var containers = await cloudBlobClient.ListContainersSegmentedAsync(containerToken).ConfigureAwait(false);
                        containerToken = containers.ContinuationToken;
                        containers.Results
                            .ToList()
                            .ForEach(async c => await CleanAsync(cloudBlobClient, c.Name).ConfigureAwait(false));
                    }
                    while (containerToken != null);
                }
                else
                {
                    await CleanAsync(cloudBlobClient, containerName).ConfigureAwait(false);
                }

                return true;
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        public async Task<bool> CopyAsync(
            string sourceStorageAccountConnectionString,
            string destinationStorageAccountConnectionString,
            string sourceContainerName,
            string destinationContainerName,
            string sourceBlobName,
            string destinationBlobName)
        {
            try
            {
                var sourceCloudBlobClient = CloudStorageAccount.Parse(sourceStorageAccountConnectionString).CreateCloudBlobClient();
                var destinationCloudBlobClient = CloudStorageAccount.Parse(destinationStorageAccountConnectionString).CreateCloudBlobClient();
                var sourceContainer = sourceCloudBlobClient.GetContainerReference(sourceContainerName);
                var destinationContainer = destinationCloudBlobClient.GetContainerReference(destinationContainerName);
                await destinationContainer.CreateIfNotExistsAsync().ConfigureAwait(false);
                var sourceCloudBlockBlob = sourceContainer.GetBlockBlobReference(sourceBlobName);
                var destinationCloudBlockBlob = destinationContainer.GetBlockBlobReference(destinationBlobName);

                var sourceFile = string.Empty;
                using (var reader = new StreamReader(await sourceCloudBlockBlob.OpenReadAsync().ConfigureAwait(false)))
                {
                    sourceFile = await reader.ReadToEndAsync().ConfigureAwait(false);
                }

                using (var writer = new StreamWriter(await destinationCloudBlockBlob.OpenWriteAsync().ConfigureAwait(false)))
                {
                    await writer.WriteAsync(sourceFile).ConfigureAwait(false);
                }

                return true;
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
            {
                Logger.Error(ex);
                return false;
            }
#pragma warning restore CA1031 // Do not catch general exception types
        }

        public Task DeleteAsync(string containerName, string blobName, string keyPrefix = null)
        {
            var container = this.GetBlobClient(keyPrefix).GetContainerReference(containerName);
            var blob = container.GetBlockBlobReference(blobName);
            return blob.DeleteIfExistsAsync();
        }

        public async Task<Stream> ReadAsync(string containerName, string blobName, FileAccess fileAccessMode = FileAccess.Read, string keyPrefix = null)
        {
            var container = this.GetBlobClient(keyPrefix).GetContainerReference(containerName);
            if (fileAccessMode == FileAccess.Write)
            {
                await container.CreateIfNotExistsAsync().ConfigureAwait(false);
            }

            var blob = container.GetBlockBlobReference(blobName);
            switch (fileAccessMode)
            {
                case FileAccess.Read:
                    return await blob.OpenReadAsync().ConfigureAwait(false);
                case FileAccess.Write:
                    return await blob.OpenWriteAsync().ConfigureAwait(false);
                default:
                    return null;
            }
        }

        public Task<bool> Exists(string containerName, string blobName, string keyPrefix = null)
        {
            var container = this.GetBlobClient(keyPrefix).GetContainerReference(containerName);
            var blobFile = container.GetBlockBlobReference(blobName);
            return blobFile.ExistsAsync();
        }

        public Task<bool> CreateAsync(string containerName, string keyPrefix = null)
        {
            var container = this.GetBlobClient(keyPrefix).GetContainerReference(containerName);
            return container.CreateIfNotExistsAsync();
        }

        public async Task<Tuple<string, string>> ReadSasTokenAsync(string containerName, string blobFileName, int accessExpiryTime, string keyPrefix = null, params string[] permissions)
        {
            var container = this.GetBlobClient(keyPrefix).GetContainerReference(containerName);
            await container.CreateIfNotExistsAsync().ConfigureAwait(false);
            var blob = container.GetBlockBlobReference(blobFileName);
            var sasPolicy = new SharedAccessBlobPolicy { Permissions = SharedAccessBlobPermissions.Read, SharedAccessExpiryTime = DateTime.UtcNow.AddHours(accessExpiryTime) };
            foreach (var permission in permissions)
            {
                if (Enum.TryParse(permission, out SharedAccessBlobPermissions sharedAccessBlobPermission))
                {
                    sasPolicy.Permissions |= sharedAccessBlobPermission;
                }
            }

            return new Tuple<string, string>(blob.StorageUri.PrimaryUri.Host.Split('.')[0], blob.GetSharedAccessSignature(sasPolicy));
        }

        public async Task<dynamic> DownloadRangeAsync(string containerName, string blobName, int index, long? offset, long? length, string keyPrefix = null)
        {
            var container = this.GetBlobClient(keyPrefix).GetContainerReference(containerName);
            var blobFile = container.GetBlockBlobReference(blobName);
            var result = (Data: default(byte[]), Length: default(int));
            result.Length = await blobFile.DownloadRangeToByteArrayAsync(result.Data, index, offset, length).ConfigureAwait(false);
            return result;
        }

        public async Task UploadAsync(string containerName, string blobName, Stream fileStream, string keyPrefix = null)
        {
            var container = this.GetBlobClient(keyPrefix).GetContainerReference(containerName);
            var blobFile = container.GetBlockBlobReference(blobName);
            fileStream.Seek(0, SeekOrigin.Begin);
            await blobFile.UploadFromStreamAsync(fileStream).ConfigureAwait(false);
        }
#pragma warning disable CA1725 // Parameter names should match base declaration

        /// <summary>
        /// Not implemented.
        /// </summary>
        /// <typeparam name="T">The type.</typeparam>
        /// <param name="containerName">Container name.</param>
        /// <param name="keyPrefix">Blob name.</param>
        /// <param name="args">Empty args.</param>
        /// <returns>The Blob.</returns>
        protected override Task<T> ReadInternalAsync<T>(string containerName = null, string keyPrefix = null, params object[] args)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Gets all Blobs within a Container. Use CloudBlockBlob for T.
        /// </summary>
        /// <typeparam name="T">The type.</typeparam>
        /// <param name="containerName">Container name.</param>
        /// <param name="keyPrefix">Empty.</param>
        /// <param name="args">Empty args.</param>
        /// <returns>The Blobs.</returns>
        protected override Task<IEnumerable<T>> ReadAllInternalAsync<T>(string containerName = null, string keyPrefix = null, params object[] args)
        {
            var cloudBlobContainer = this.GetBlobClient(keyPrefix).GetContainerReference(containerName);
            return Task.FromResult(cloudBlobContainer.ListBlobs().OfType<T>());
        }
#pragma warning restore CA1725 // Parameter names should match base declaration

        private static async Task CleanAsync(CloudBlobClient cloudBlobClient, string containerName)
        {
            var container = cloudBlobClient.GetContainerReference(containerName);
            BlobContinuationToken fileToken = null;
            do
            {
                var result = await container.ListBlobsSegmentedAsync(fileToken).ConfigureAwait(false);
                fileToken = result.ContinuationToken;
                result.Results
                    .Where(r => r.GetType() == typeof(CloudBlockBlob) && (((CloudBlockBlob)r).Properties.Created.Value.DateTime < DateTime.Now.Subtract(TimeSpan.FromDays(90))))
                    .ToList()
                    .ForEach(async r => await ((CloudBlockBlob)r).DeleteIfExistsAsync().ConfigureAwait(false));
            }
            while (fileToken != null);
        }

        private CloudBlobClient GetBlobClient(string keyPrefix = "")
        {
            var key = $"{nameof(BlobStorageDataSource)}." + (string.IsNullOrWhiteSpace(keyPrefix) ? this.DefaultKeyPrefix : keyPrefix);
            var client = Clients.GetOrAdd(key, k =>
            {
                var storageAccount = this.SetConnection(key, Settings);
                return storageAccount.StorageAccount.CreateCloudBlobClient();
            });

            return client;
        }
    }
}
