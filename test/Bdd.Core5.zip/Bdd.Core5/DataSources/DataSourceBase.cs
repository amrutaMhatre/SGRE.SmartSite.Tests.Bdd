﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DataSourceBase.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.DataSources
{
    using System.Collections.Generic;
    using System.Configuration;
    using System.Threading.Tasks;

    using NLog;

    using TechTalk.SpecFlow;

    public abstract class DataSourceBase : IDataSource
    {
        protected static readonly Logger Logger = LogManager.GetCurrentClassLogger();

#pragma warning disable CA2227 // Collection properties should be read only
        public ScenarioContext ScenarioContext { get; set; }

        public FeatureContext FeatureContext { get; set; }
#pragma warning restore CA2227 // Collection properties should be read only

        /// <inheritdoc />
        public string Input { get; set; }

        protected string DefaultKeyPrefix => ConfigurationManager.AppSettings[nameof(this.DefaultKeyPrefix)];

        /// <inheritdoc />
        public virtual Task<T> ReadAsync<T>(string input = null, string keyPrefix = null, params object[] args)
        {
            return this.ReadInternalAsync<T>(input ?? this.Input, keyPrefix, args);
        }

        /// <inheritdoc />
        public virtual Task<IEnumerable<T>> ReadAllAsync<T>(string input = null, string keyPrefix = null, params object[] args)
        {
            return this.ReadAllInternalAsync<T>(input ?? this.Input, keyPrefix, args);
        }

        protected abstract Task<T> ReadInternalAsync<T>(string input = null, string keyPrefix = null, params object[] args);

        protected abstract Task<IEnumerable<T>> ReadAllInternalAsync<T>(string input = null, string keyPrefix = null, params object[] args);
    }
}