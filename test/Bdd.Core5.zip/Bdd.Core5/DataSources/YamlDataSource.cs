﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="YamlDataSource.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.DataSources
{
    using System.Collections.Generic;
    using System.IO;
    using System.Threading.Tasks;

    using Bdd.Core.Utils;

    using YamlDotNet.Core;
    using YamlDotNet.Serialization;

    public class YamlDataSource : DataSourceBase
    {
        protected override Task<IEnumerable<T>> ReadAllInternalAsync<T>(string input = null, string keyPrefix = null, params object[] args)
        {
            var value = input.GetFullPath().GetContent();
            var parser = GetYamlParser(value);
            return Task.FromResult(new Deserializer().Deserialize<IEnumerable<T>>(parser));
        }

        protected override Task<T> ReadInternalAsync<T>(string input = null, string keyPrefix = null, params object[] args)
        {
            var value = input.GetFullPath().GetContent();
            var parser = GetYamlParser(value);
            return Task.FromResult(new Deserializer().Deserialize<T>(parser));
        }

        private static MergingParser GetYamlParser(string value)
        {
            return new MergingParser(new Parser(new StringReader(value)));
        }
    }
}