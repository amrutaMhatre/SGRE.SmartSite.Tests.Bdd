﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DocProcessor.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.Docs
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Threading.Tasks;
    using System.Web;
    using System.Windows.Forms;

    using AdysTech.CredentialManager;

    using Bdd.Core.Executors;

    using CsvHelper;

    using Flurl.Http;
    using Flurl.Http.Content;

    using global::Bdd.Core.Entities.Tags;
    using global::Bdd.Core.Utils;

    using Humanizer;

    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;

    using NLog;

    using NUnit.Framework;

    public class DocProcessor
    {
        public static readonly IReadOnlyList<string> ClosedReasons = new[] { "Obsolete", "Duplicate" };

        protected static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        private const string Automated = "Automated";

        private const string NotAutomated = "Not Automated";

        //// private const string Planned = "Planned";

        private const string AuthorizationHeader = "Authorization";

        private const string RequirementTestSuiteType = "RequirementTestSuite";

        private const string QuotedStringFont = "<FONT color=\"#a31515\">{0}</FONT>";

        private const string ActionStepContentBegin = "<step type=\"ActionStep\" id=\"{0}\"><parameterizedString isformatted=\"true\">";

        private const string ActionStepContentEnd = "</parameterizedString><parameterizedString isformatted=\"true\">&lt;DIV&gt;&lt;P&gt;&amp;nbsp;&lt;/P&gt;&lt;/DIV&gt;</parameterizedString><description /></step>";

        private const string ValidateStepContentBegin = "<step type=\"ValidateStep\" id=\"{0}\"><parameterizedString isformatted=\"true\">";

        private const string ValidateStepContentEnd = "</parameterizedString><parameterizedString isformatted=\"true\">{0}</parameterizedString><description /></step>";

        private const string ActionStepHtml = "<DIV><P><FONT face=\"Consolas\" size=\"2\"><FONT color=\"#0078d7\">{0}</FONT> {1}</FONT></P></DIV>";

        private const string ExpectedResultStepHtml = "<P><FONT face=\"Consolas\" size=\"2\"><FONT color=\"#0078d7\">{0}</FONT> {1}</FONT></P>";

        private const string JsonPatchMediaType = "application/json-patch+json";

        private const string JsonBatchHttpRequestMediaType = "application/json";

        private const string OctetStreamMediaType = "application/octet-stream";

        private const string Fields = "/fields/";

        private const string SystemTitle = Fields + "System.Title";

        private const string SystemTags = Fields + "System.Tags";

        private const string SystemAreaPath = Fields + "System.AreaPath";

        private const string SystemIterationPath = Fields + "System.IterationPath";

        private const string SystemAssignedTo = Fields + "System.AssignedTo";

        private const string TcmSteps = Fields + "Microsoft.VSTS.TCM.Steps";

        private const string AutomationStatus = Fields + "Microsoft.VSTS.TCM.AutomationStatus";

        private const string AutomatedTestType = Fields + "Microsoft.VSTS.TCM.AutomatedTestType";

        private const string AutomatedTestId = Fields + "Microsoft.VSTS.TCM.AutomatedTestId";

        private const string AutomatedTestName = Fields + "Microsoft.VSTS.TCM.AutomatedTestName";

        private const string AutomatedTestStorage = Fields + "Microsoft.VSTS.TCM.AutomatedTestStorage";

        private const string TestedByRequirement = "Microsoft.VSTS.Common.TestedBy-Reverse";

        private const string SharedStepReferencedBy = "Microsoft.VSTS.TestCase.SharedStepReferencedBy-Reverse";

        private const string TestPriority = Fields + "Microsoft.VSTS.Common.Priority";

        private const string WorkItemRelations = "/relations/-";

        private const string DefaultPriority = "2";

        private const string PicklesFile = "pickledFeatures.json";

        private const string ApiVersion = "?api-version=5.0"; // api-version=6.0-preview.3

        private const int MaxLimit = 200;

        private const string PreviewSuffix = "-preview";

        private const string AttachedFile = "AttachedFile";

        private const string ContentTypeHeader = "Content-Type";

        private const string ContentSizeHeader = "Content-Size";

        private const string ContentRangeHeader = "Content-Range";

        private const string ContentRangeValue = "bytes 0-{0}/{1}";

        private const string SharedSteps = "Shared Steps";

        private static readonly NameValueCollection VstsDocTargetSettings = ConfigurationManager.GetSection("vstsDocTarget") as NameValueCollection ?? throw new ConfigurationErrorsException("vstsDocTarget");

        private static readonly bool TreatBddThenAsVstsExpectedResult = VstsDocTargetSettings.AllKeys.Contains(nameof(TreatBddThenAsVstsExpectedResult)) && bool.Parse(VstsDocTargetSettings[nameof(TreatBddThenAsVstsExpectedResult)]);

        private static readonly string Account = VstsDocTargetSettings.GetValue(nameof(Account));

        private static readonly string Project = VstsDocTargetSettings.GetValue(nameof(Project));

        private static readonly string AreaPath = VstsDocTargetSettings.GetValue("System.AreaPath");

        private static readonly string IterationPath = VstsDocTargetSettings.GetValue("System.IterationPath");

        private static readonly string AssignedTo = VstsDocTargetSettings.GetValue("System.AssignedTo");

        private static readonly string AdditionalFields = VstsDocTargetSettings[nameof(AdditionalFields)];

        private static readonly string BaseUrl = $"https://dev.azure.com/{Account}/_apis/";

        private static readonly string BaseProjectUrl = BaseUrl.Replace("_apis", $"{Project}/_apis");

        private static readonly string TestCaseCreateUrl = BaseProjectUrl + "wit/workitems/$Test Case" + ApiVersion;

        private static readonly string TestCaseBatchDeleteUrl = BaseUrl + "wit/$batch" + ApiVersion;

        private static readonly string ProjectsUrl = BaseUrl + "projects" + ApiVersion;

        private static readonly string TagsUrl = BaseUrl + "tagging/scopes/{0}/tags?includeInactive=False" + ApiVersion.TrimStart('?') + PreviewSuffix;

        private static readonly string TagUrl = BaseUrl + "tagging/scopes/{0}/tags/{1}" + ApiVersion + PreviewSuffix;

        private static readonly string CreateAttachmentUrl = BaseUrl + "wit/attachments?fileName={0}&" + ApiVersion.TrimStart('?');

        private static readonly string SharedStepsCreateUrl = BaseProjectUrl + "wit/workitems/$Shared Steps" + ApiVersion;

        private static readonly string TestPlansUrl = BaseProjectUrl + "test/plans" + ApiVersion;

        private static readonly string TestSuitesUrl = TestPlansUrl.Replace(ApiVersion, string.Empty) + "/{0}/suites" + ApiVersion;

        private static readonly string TestSuiteUrl = TestSuitesUrl.Replace(ApiVersion, string.Empty) + "/{1}" + ApiVersion;

        private static readonly string TestCasesUrl = TestSuitesUrl.Replace(ApiVersion, string.Empty) + "/{1}/testcases" + ApiVersion;

        private static readonly string TestCasesAddUrl = TestSuitesUrl.Replace(ApiVersion, string.Empty) + "/{1}/testcases/{2}" + ApiVersion;

        private static readonly string WorkItemUrl = BaseProjectUrl + "wit/workItems/{0}" + ApiVersion;

        private static readonly string WorkItemsUrl = BaseProjectUrl + "wit/workItems?ids={0}&$expand=Relations&" + ApiVersion.TrimStart('?');

        private static readonly string[] ExcludeTags = { "@attach", "@input", "@output", "@testplan", "@testsuite", "@testcase", "@priority", "@manual", "@before", "@after", "@owner", "@sharedsteps" };

        private static readonly IEnumerable<string> AttachmentTags = VstsDocTargetSettings.GetValue(nameof(AttachmentTags)).Split(new[] { ' ', ',', ';' }, StringSplitOptions.RemoveEmptyEntries).Select(x => x.EndsWith("=", StringComparison.Ordinal) ? x : $"{x}=");

        private static readonly string FeatureFilesPath = VstsDocTargetSettings[nameof(FeatureFilesPath)].GetFullPath();

        private static readonly string TestProjectAssemblyPath = VstsDocTargetSettings[nameof(TestProjectAssemblyPath)].GetFullPath();

        private static readonly string TestProjectPath = VstsDocTargetSettings[nameof(TestProjectPath)].GetFullPath();

        private static readonly Assembly TestAssembly = Assembly.LoadFrom(TestProjectAssemblyPath);

        private static readonly string TestStorage = Path.GetFileName(TestAssembly.CodeBase);

        private static readonly Regex DoubleQuotesOrAtTheRateRegex = new Regex("\".*?\"|@\\w*");

        private static readonly string CredsUrl = $"bddcore:{BaseUrl}";

        private static string accessToken = VstsDocTargetSettings.GetValue("AccessToken", false);

        private static string pat = string.Empty;

        private static string Pat
        {
            get
            {
                if (string.IsNullOrEmpty(pat))
                {
                    if (string.IsNullOrWhiteSpace(accessToken) || accessToken.EqualsIgnoreCase("xyz"))
                    {
                        var cred = CredentialManager.GetCredentials(CredsUrl);
                        if (cred == null)
                        {
                            var save = false;
                            cred = CredentialManager.PromptForCredentials(CredsUrl, ref save, $"Please provide PAT for {BaseUrl}", "Bdd.Core", "PAT");
                            CredentialManager.SaveCredentials(CredsUrl, cred);
                        }

                        accessToken = cred.Password;
                    }
                    else
                    {
                        var cred = CredentialManager.GetCredentials(CredsUrl);
                        if (cred == null)
                        {
                            CredentialManager.SaveCredentials(CredsUrl, new NetworkCredential("PAT", accessToken));
                        }
                    }

                    pat = "Basic " + Convert.ToBase64String(Encoding.ASCII.GetBytes($":{accessToken}"));
                }

                return pat;
            }
        }

        /// <summary>
        /// Fields: https://docs.microsoft.com/en-us/rest/api/vsts/wit/fields/list
        /// TestPlans: https://www.visualstudio.com/en-us/docs/integrate/api/test/plans
        /// TestSuites: https://www.visualstudio.com/en-us/docs/integrate/api/test/suites
        /// TestCases: https://www.visualstudio.com/en-us/docs/integrate/api/test/cases
        /// Create TestCase: https://www.visualstudio.com/en-us/docs/integrate/api/wit/work-items#create-a-work-item
        /// Update TestCase: https://www.visualstudio.com/en-us/docs/integrate/api/wit/work-items#update-a-field
        /// Create TestSuite: https://www.visualstudio.com/en-us/docs/integrate/api/test/suites#create-a-test-suite
        /// Batch Operations: https://docs.microsoft.com/en-us/rest/api/azure/devops/wit/WorkItemBatchUpdate?view=azure-devops-rest-4.1
        /// JSON-Path: https://goessner.net/articles/JsonPath/
        /// </summary>
        /// <param name="featureFilterAction">Only Features that match this condition will be processed and synced</param>
        /// <param name="scenarioFilterAction ">Only Scenarios that match this condition will be processed and synced</param>
        /// <param name="regeneratePicklesFile">Regenerates Pickles file if true</param>
        /// <param name="demoMode">Setting demo-mode to true does not really sync anything to VSTS (used for debugging)</param>
        /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
        public async Task<bool> GenerateVstsTestCasesFromBddFeatures(Func<Feature, bool> featureFilterAction = null, Func<FeatureElement, bool> scenarioFilterAction = null, bool regeneratePicklesFile = true, bool demoMode = false)
        {
            // PACKAGE-MANAGER CMD:
            // Pickle-Features -FeatureDirectory .\{Test-Project-Path}\Features -OutputDirectory .\{Test-Project-Path}\Docs -DocumentationFormat JSON
            var checkDuplicateTestCases = false;
            var tests = this.GetTestsWithTestCaseIds();
            var attachments = new ConcurrentDictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            ////var longTests = tests.Select(test => (test.Namespace + "." + test.Feature + "." + test.TestName)).Where(test => test.Length >= 255);
            ////Logger.Debug(string.Join(Environment.NewLine, longTests));

            var testsNotHavingTestCaseIds = tests.Where(x => x.Scenario == null).ToList();
            if (testsNotHavingTestCaseIds.Count > 0)
            {
                this.LogError(message: $"Tests (auto-generated) not having TestCaseIds:{Environment.NewLine}{string.Join(Environment.NewLine, testsNotHavingTestCaseIds.Select(x => x.TestName))}", justWarn: true);
            }

            var features = await this.PopulateFeatures(regeneratePicklesFile).ConfigureAwait(false);
            if (features == null)
            {
                this.LogError(message: $"No Features found!", justWarn: true);
                return false;
            }

            var defaultAssignedTo = AssignedTo.Trim();
            var defaultAssignedToSplit = defaultAssignedTo?.Split(new char[] { '@' }, 2)?.ToList();
            var tps = new HashSet<TestPlan>();
            try
            {
                Assert.Multiple(async () =>
                {
                    await this.PopulateAllTestCases(features, tps, featureFilterAction, scenarioFilterAction, attachments).ConfigureAwait(false);
                    if (checkDuplicateTestCases)
                    {
                        CheckDuplicateTestCases();
                    }

                    await SyncToVsts().ConfigureAwait(false);
                });
            }
            finally
            {
#pragma warning disable SG0018 // Path traversal
                File.WriteAllText((Path.GetFileNameWithoutExtension(PicklesFile) + "_syncResults" + Path.GetExtension(PicklesFile)).GetFullPath(), features.ToJson());
#pragma warning restore SG0018 // Path traversal
            }

            void CheckDuplicateTestCases()
            {
                var scs = features?.Features.Where(x => !x.Feature.HasTag(DocTags.Ignore) && featureFilterAction(x.Feature)).SelectMany(f => f.Feature.FeatureElements.Where(x => !x.HasTag(DocTags.Ignore) && scenarioFilterAction(x))).ToList();
                var tcs = tps.SelectMany(tp => tp.TestSuites).SelectMany(ts => ts.TestCases).ToList();
                var taggedTcs = tcs.Where(tc => scs.Any(s => s.GetTag(DocTags.TestCase)?.Equals(tc.Id, StringComparison.Ordinal) == true)).ToList();
                var dupTcs = tcs.Where(tc => taggedTcs.Any(t => t.Title.EqualsIgnoreCase(tc.Title))).GroupBy(c => c.Title).Where(g => g.Count() > 1).SelectMany(g => g).ToList();
                var redundantTcs = dupTcs.Where(tc => !taggedTcs.Any(t => t.Title.EqualsIgnoreCase(tc.Title))).ToList();
                Logger.Warn($"Redundant TCs: {string.Join(",", dupTcs.Select(r => r.Id))}");
                foreach (var item in redundantTcs)
                {
                    Logger.Warn($"{item.Id} - {item.Title}");
                }
            }

            async Task SyncToVsts()
            {
                var index = 0;
                foreach (var feature in features?.Features.Where(x => x.Feature.HasTag(DocTags.TestPlan, true) && x.Feature.HasTag(DocTags.TestSuite, true) && !x.Feature.HasTag(DocTags.Ignore) && featureFilterAction(x.Feature))) ////.Where(x => x.Feature.Name.Equals("FilterPaneForAlertRecipientsGrid", StringComparison.OrdinalIgnoreCase))
                {
                    var testPlanId = feature.Feature.GetTag(DocTags.TestPlan);
                    var testSuiteId = feature.Feature.GetTag(DocTags.TestSuite);
                    try
                    {
                        // Create Shared-Step for Background only for the first time in a Feature
                        var sharedStepsId = await HandleFeatureElement(feature, feature.Feature.Background, testPlanId, testSuiteId).ConfigureAwait(false);
                        Logger.Debug($"{nameof(sharedStepsId)} created/updated: {sharedStepsId}");
                        foreach (var currentScenario in feature.Feature.FeatureElements.Where(x => !x.HasTag(DocTags.Ignore) && scenarioFilterAction(x)))
                        {
                            var scenarioTestPlanId = currentScenario.GetTag(DocTags.TestPlan);
                            var scenarioTestSuiteId = currentScenario.GetTag(DocTags.TestSuite);
                            var testCaseId = await HandleFeatureElement(feature, currentScenario, scenarioTestPlanId, scenarioTestSuiteId, sharedStepsId).ConfigureAwait(false);
                            Logger.Debug($"{nameof(testCaseId)} created/updated: {testCaseId}");
                        }
                    }
                    catch (Exception ex)
                    {
                        await this.LogError(feature.Feature, null, testPlanId, testSuiteId, ex: ex).ConfigureAwait(false);
                    }
                }

                async Task<string> HandleFeatureElement(Feature_ feature, IFeatureElement featureElement, string testPlanId, string testSuiteId, string sharedStepsId = null)
                {
                    var workItemId = string.Empty;
                    if (featureElement != null)
                    {
                        var isBackground = featureElement.Type.Equals(nameof(Background), StringComparison.Ordinal);
                        var featureElementId = featureElement.GetTag(isBackground ? DocTags.SharedSteps : DocTags.TestCase);
                        var featureElementVersion = featureElement.GetTag(DocTags.Version);
                        var featureElementTestPlan = tps.SingleOrDefault(tp => tp.Id.EqualsIgnoreCase(testPlanId));
                        var featureElementTestSuite = featureElementTestPlan?.TestSuites?.SingleOrDefault(ts => ts.Id.EqualsIgnoreCase(testSuiteId));
                        var userStoryId = featureElementTestSuite?.UserStory?.Id;

                        try
                        {
                            var update = false;
                            var existingWorkItem = isBackground
                                ? featureElementTestSuite.SharedSteps?.SingleOrDefault(x => featureElementId?.EqualsIgnoreCase(x.Id) == true || x.Title?.Equals(featureElement.Name, StringComparison.OrdinalIgnoreCase) == true)
                                : featureElementTestSuite.TestCases?.SingleOrDefault(x => featureElementId?.EqualsIgnoreCase(x.Id) == true || x.Title?.Equals(featureElement.Name, StringComparison.OrdinalIgnoreCase) == true);
                            if (existingWorkItem != null)
                            {
                                var mismatchCheck = featureElementId == null || featureElementId.EqualsIgnoreCase(existingWorkItem.Id);
                                if (!mismatchCheck)
                                {
                                    this.LogError(message: $"Work-item ID mismatch: BDD {featureElement.Type} '{featureElementId} - {featureElement.Name}' / VSTS Work-item '{existingWorkItem.Id} - {existingWorkItem.Title}'", justWarn: true);
                                }

                                update = featureElementId != null && NeedsUpdate(existingWorkItem, featureElement);
                                if (update)
                                {
                                    Logger.Debug($"Version update: {featureElement.Type.ToCamelCase()}={featureElement.Name} (@version:{featureElementVersion ?? string.Empty}) / testCase={existingWorkItem.Id} - {existingWorkItem.Title} (@version:{existingWorkItem.Version ?? string.Empty})");
                                    AppendWorkItemTag(featureElement, featureElementId, featureElementVersion);
                                }
                                else
                                {
                                    AppendWorkItemTag(featureElement, existingWorkItem.Id, existingWorkItem.Version);
                                    if (!isBackground)
                                    {
                                        var tc = existingWorkItem as VstsTestCase;
                                        update = !featureElement.HasTag(DocTags.Manual) && (string.IsNullOrWhiteSpace(tc.AutomatedTestName) || (tc.AutomatedTestName != null && tc.AutomatedTestName.Trim().StartsWith(".", StringComparison.OrdinalIgnoreCase)));
                                    }

                                    if (!update)
                                    {
                                        if (string.IsNullOrWhiteSpace(featureElementId) && !demoMode)
                                        {
                                            AppendWorkItemTagInFeatureFile(feature, featureElement, existingWorkItem.Id);
                                        }

                                        return existingWorkItem.Id; // return featureElementId // return null;
                                    }
                                    else
                                    {
                                        Logger.Debug($"Fields update: {featureElement.Type.ToCamelCase()}={featureElement.Name} / workItem={existingWorkItem.Id} - {existingWorkItem.Title}");
                                    }
                                }
                            }

                            if (!isBackground)
                            {
                                HandleScenarioOutlines(featureElement as FeatureElement);
                            }

                            var id = featureElementId ?? existingWorkItem?.Id;
                            if (update && string.IsNullOrWhiteSpace(id))
                            {
                                this.LogError(feature.Feature, featureElement, testPlan: testPlanId, testSuite: testSuiteId, message: $"Cannot update a Work-item with empty Id");
                            }

                            var ops = isBackground ? GetSharedStepsContent(featureElement, update) : GetTestCaseContent(feature.Feature, featureElement, userStoryId, id, sharedStepsId, testPlanId, testSuiteId, update);
                            HandleAttachments(featureElement, ops, update);
                            var content = new CapturedStringContent(ops?.ToJson(), Encoding.UTF8, JsonPatchMediaType);
                            var create = isBackground ? SharedStepsCreateUrl : TestCaseCreateUrl;
                            var createOrUpdate = update ? string.Format(CultureInfo.InvariantCulture, WorkItemUrl, id) : create;
                            index++;
                            if (demoMode)
                            {
                                Logger.Info($"DemoMode: {index}) [{(update ? "Update" : "Add")}] " + createOrUpdate);
                            }
                            else
                            {
                                Logger.Info($"{index}) [{(update ? "Update" : "Add")}] " + createOrUpdate);
                                var result = await createOrUpdate
                                    .WithHeader(AuthorizationHeader, Pat)
                                    .PatchAsync(content)
                                    .ConfigureAwait(false);

                                var response = await result.Content.ReadAsJsonAsync<dynamic>().ConfigureAwait(false);
                                Logger.Trace(response);
                                workItemId = response.id;
                                Assert.AreEqual(result.StatusCode, HttpStatusCode.OK);

                                if (!update)
                                {
                                    AppendWorkItemTag(featureElement, workItemId, featureElementVersion ?? existingWorkItem?.Version);
                                }

                                if (string.IsNullOrWhiteSpace(featureElementId))
                                {
                                    AppendWorkItemTagInFeatureFile(feature, featureElement, workItemId);
                                }

                                // Add TCs to a Static Suite
                                if (!demoMode && !isBackground && string.IsNullOrWhiteSpace(userStoryId) && !featureElementTestSuite.TestCases.Any(x => x.Id.EqualsIgnoreCase(workItemId)))
                                {
                                    await string.Format(CultureInfo.InvariantCulture, TestCasesAddUrl, testPlanId, testSuiteId, workItemId)
                                            .WithHeader(AuthorizationHeader, Pat)
                                            .PostAsync(null)
                                            .ConfigureAwait(false);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            await this.LogError(feature.Feature, featureElement, testPlanId, testSuiteId, featureElementId, ex).ConfigureAwait(false);
                        }
                    }

                    return workItemId;
                }
            }

            const string add = "add";
            const string functionalTest = "Functional Test";

            void HandleAttachments(IFeatureElement featureElement, IList<Op> ops, bool update)
            {
                var tags = AttachmentTags?.Select(t => new { Tag = t, Files = featureElement.GetTag(t)?.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries) })?.Where(x => x.Files != null).ToList();
                if (tags?.Count > 0)
                {
                    foreach (var item in tags)
                    {
                        foreach (var file in item.Files)
                        {
                            var filePath = file.GetFullPath();
                            if (File.Exists(filePath))
                            {
                                var url = update
                                            ? attachments.AddOrUpdate(file, key => this.UploadAttachment(file, filePath, false).GetAwaiter().GetResult(), (key, existing) => this.UploadAttachment(existing, filePath, true).GetAwaiter().GetResult())
                                            : attachments.GetOrAdd(file, key => this.UploadAttachment(file, filePath).GetAwaiter().GetResult());

                                if (!string.IsNullOrWhiteSpace(url))
                                {
                                    var op = new Op
                                    {
                                        op = add,
                                        path = WorkItemRelations,
                                        value = new
                                        {
                                            rel = AttachedFile,
                                            url = url,
                                            attributes = new { comment = item.Tag.TrimEnd('=') },
                                        },
                                    };
                                    ops.Add(op);
                                }
                            }
                        }
                    }
                }
            }

            IList<Op> GetSharedStepsContent(IFeatureElement background, bool update)
            {
                var tags = string.Join("; ", background.Tags.Where(x => !ExcludeTags.Any(x.StartsWith)).Select(t => t.TrimStart('@')));
                var priority = background.GetTag(DocTags.Priority) ?? (background.HasTag(DocTags.Bvt) ? "1" : DefaultPriority);

                // op = test, add, replace, remove
                var ops = new[]
                {
                    new Op { op = add, path = SystemTitle, value = background.Name },
                    new Op { op = add, path = TestPriority, value = priority },
                    new Op { op = add, path = SystemAreaPath, value = AreaPath },
                    new Op { op = add, path = SystemTags, value = tags },
                    new Op { op = add, path = TcmSteps, value = GetHtml(background.Steps) },
                }.ToList();

                // Add Iteration-path only in case of creating new Test-Cases. Updates to existing ones should not change the Iteration.
                if (!update)
                {
                    ops.Add(new Op { op = add, path = SystemIterationPath, value = IterationPath });
                }

                return ops;
            }

            IList<Op> GetTestCaseContent(Feature feature, IFeatureElement scenario, string userStoryId, string scenarioTestCaseId, string sharedStepsId, string testPlanId, string testSuiteId, bool update)
            {
                if (feature.Name.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Length > 1)
                {
                    this.LogError(feature, scenario, message: $"Spaces in name", justWarn: true);
                }

                var tags = string.Join("; ", scenario.Tags.Where(x => !ExcludeTags.Any(x.StartsWith)).Select(t => t.TrimStart('@')));
                var test = tests.FirstOrDefault(x => scenarioTestCaseId?.Equals(x.TestCaseId, StringComparison.OrdinalIgnoreCase) == true || (x.Feature.Replace("Feature", string.Empty).Equals(feature.Name.Replace(" ", string.Empty), StringComparison.OrdinalIgnoreCase) && x.Scenario.Equals(scenario.Name, StringComparison.OrdinalIgnoreCase)));
                var testName = test.Namespace + "." + test.Feature + "." + test.TestName;
                if (testName.Length > 255)
                {
                    this.LogError(feature, featureElement: scenario, workItem: scenarioTestCaseId ?? string.Empty, message: $"Length > 255 chars ({testName})");
                }

                var isAutomated = !scenario.HasTag(DocTags.Manual) && !test.Equals(default((string Namespace, string Feature, string TestName, string Scenario, string TestCaseId)));
                var notAutomatedReason = isAutomated ? string.Empty : scenario.GetTag(DocTags.Manual)?.Humanize(LetterCasing.Title); // Planned
                var priority = scenario.GetTag(DocTags.Priority) ?? (scenario.HasTag(DocTags.Bvt) ? "1" : DefaultPriority);
                var owner = scenario.GetTag(DocTags.Owner)?.Trim() ?? defaultAssignedTo;
                if (owner?.Contains("@") != true && defaultAssignedToSplit?.Count == 2)
                {
                    owner += $"@{defaultAssignedToSplit?.LastOrDefault()}"; // Append Host
                }

                // op = test, add, replace, remove
                var ops = new[]
                {
                    new Op { op = add, path = SystemTitle, value = scenario.Name },
                    new Op { op = add, path = TestPriority, value = priority },
                    new Op { op = add, path = AutomationStatus, value = isAutomated ? Automated : (string.IsNullOrWhiteSpace(notAutomatedReason) ? NotAutomated : notAutomatedReason) },
                    new Op { op = add, path = AutomatedTestType, value = isAutomated ? functionalTest : string.Empty },
                    new Op { op = add, path = AutomatedTestId, value = isAutomated ? testName.ToGuid().ToString() : string.Empty },
                    new Op { op = add, path = AutomatedTestName, value = isAutomated ? testName : string.Empty },
                    new Op { op = add, path = AutomatedTestStorage, value = isAutomated ? TestStorage : string.Empty },
                    new Op { op = add, path = SystemAreaPath, value = AreaPath },
                    new Op { op = add, path = SystemTags, value = tags },
                    new Op { op = add, path = TcmSteps, value = GetHtml(scenario.Steps, sharedStepsId) },
                }.ToList();

                if (!string.IsNullOrWhiteSpace(owner))
                {
                    ops.Add(new Op { op = add, path = SystemAssignedTo, value = owner }); // new Op { op = add, path = "Tester", value = owner },
                }

                // Add Iteration-path only in case of creating new Test-Cases. Updates to existing ones should not change the Iteration.
                if (!update)
                {
                    ops.Add(new Op { op = add, path = SystemIterationPath, value = IterationPath });

                    // Static Suite?
                    if (!string.IsNullOrWhiteSpace(userStoryId))
                    {
                        ops.Add(new Op
                        {
                            op = add,
                            path = WorkItemRelations,
                            value = new
                            {
                                rel = TestedByRequirement, // System.LinkTypes.Hierarchy-Reverse = Parent
                                url = string.Format(CultureInfo.InvariantCulture, WorkItemUrl, userStoryId),
                            },
                        });
                    }
                }

                // Add reference to the TestCase in the SharedSteps item
                if (!string.IsNullOrWhiteSpace(sharedStepsId))
                {
                    ops.Add(new Op
                    {
                        op = add,
                        path = WorkItemRelations,
                        value = new
                        {
                            rel = SharedStepReferencedBy,
                            url = string.Format(CultureInfo.InvariantCulture, WorkItemUrl, sharedStepsId),
                        },
                    });
                }

                // Add any custom fields
                if (!string.IsNullOrWhiteSpace(AdditionalFields))
                {
                    var fields = AdditionalFields.Split(new[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries).Select(x => x.Split(new[] { '=', ':' }, StringSplitOptions.RemoveEmptyEntries)).ToDictionary(split => split[0].Trim(), split => split[1].Trim());
                    foreach (var field in fields)
                    {
                        ops.Add(new Op { op = add, path = Fields + field.Key, value = field.Value });
                    }
                }

                return ops;
            }

            const string stepsStart = "<steps id=\"0\" last=\"{0}\">";
            const string stepsEnd = "</steps>";

            string GetHtml(Step[] steps, string sharedStepsId = "")
            {
                var sb = new StringBuilder();
                var start = string.Format(CultureInfo.InvariantCulture, stepsStart, steps.Length + (string.IsNullOrWhiteSpace(sharedStepsId) ? 1 : 2));
                sb.Append(start);
                var currentStepDefType = StepDefs.Given;
                var i = 0;
                for (i = 0; i < steps.Length; i++)
                {
                    var step = steps[i];
                    var nextStepIsThen = (i < steps.Length - 1) && steps[i + 1].Keyword.Equals(StepDefs.Then, StringComparison.Ordinal);
                    var actionStepHtml = string.Empty;
                    if (TreatBddThenAsVstsExpectedResult && nextStepIsThen)
                    {
                        if (!step.Keyword.Equals(StepDefs.And, StringComparison.Ordinal))
                        {
                            currentStepDefType = step.Keyword;
                        }

                        sb.AppendFormat(CultureInfo.InvariantCulture, ValidateStepContentBegin, i + 2);
                        actionStepHtml = string.Format(CultureInfo.InvariantCulture, ActionStepHtml, step.Keyword, GetColoredQuotedString(step.Name)).HtmlEscape();
                        sb.Append(actionStepHtml);
                        sb.Append(GetTableHtml(step));
                        var validateStepHtml = string.Empty;
                        if (currentStepDefType.Equals(StepDefs.Given, StringComparison.Ordinal) || currentStepDefType.Equals(StepDefs.When, StringComparison.Ordinal))
                        {
                            do
                            {
                                i++;
                                var thenStep = steps[i];
                                validateStepHtml += string.Format(CultureInfo.InvariantCulture, ExpectedResultStepHtml, thenStep.Keyword, GetColoredQuotedString(thenStep.Name)).HtmlEscape();
                                validateStepHtml += GetTableHtml(thenStep);
                            }
                            while (i < steps.Length - 1 && !steps[i + 1].Keyword.Equals(StepDefs.Given, StringComparison.Ordinal) && !steps[i + 1].Keyword.Equals(StepDefs.When, StringComparison.Ordinal));
                        }

                        sb.Append(string.Format(CultureInfo.InvariantCulture, ValidateStepContentEnd, validateStepHtml));
                    }
                    else
                    {
                        sb.AppendFormat(CultureInfo.InvariantCulture, ActionStepContentBegin, i + 2);
                        actionStepHtml = string.Format(CultureInfo.InvariantCulture, ActionStepHtml, step.Keyword, GetColoredQuotedString(step.Name)).HtmlEscape();
                        sb.Append(actionStepHtml);
                        sb.Append(GetTableHtml(step));
                        sb.Append(ActionStepContentEnd);
                    }
                }

                sb.Append(stepsEnd);
                var result = string.IsNullOrWhiteSpace(sharedStepsId) ? sb.ToString() : sb.Replace(start, start + $"<compref id=\"{i + 1}\" ref=\"{sharedStepsId}\">").Replace(stepsEnd, "</compref>" + stepsEnd).ToString();
                return result;
            }

            // <div style="overflow-x:auto;">
            const string TableStart = "<div><table style=\"border-collapse:collapse; font-family:Consolas; text-align: left; border: 1px solid darkgray;\">";
            const string TableEnd = "</table></div>";
            string GetTableHtml(Step step)
            {
                var tableHtml = new StringBuilder();
                var table = step.TableArgument;
                if (table != null)
                {
                    tableHtml.Append(TableStart);
                    tableHtml.Append("<tr>");
                    foreach (var header in table.HeaderRow)
                    {
                        tableHtml.Append($"<th style=\"padding: 5px; text-align: left; border: 1px solid darkgray;\">{header}</th>");
                    }

                    tableHtml.Append("</tr>");

                    foreach (var row in table.DataRows)
                    {
                        tableHtml.Append("<tr>");
                        foreach (var col in row)
                        {
                            tableHtml.Append($"<td style=\"padding: 5px; text-align: left; border: 1px solid darkgray;\">{col}</td>");
                        }

                        tableHtml.Append("</tr>");
                    }

                    tableHtml.Append(TableEnd);
                }

                return tableHtml.ToString().HtmlEscape();
            }

            string GetColoredQuotedString(string str)
            {
                var matches = DoubleQuotesOrAtTheRateRegex.Matches(str).Cast<Match>().ToLookup(x => x.Value, x => string.Format(CultureInfo.InvariantCulture, QuotedStringFont, x.Value));
                foreach (var element in matches)
                {
                    str = str.Replace(element.Key, element.FirstOrDefault());
                }

                return str;
            }

            void AppendWorkItemTag(IFeatureElement featureElement, string createdId, string version)
            {
                var tagPrefix = featureElement.Type.Equals(nameof(Background), StringComparison.Ordinal) ? DocTags.SharedSteps : DocTags.TestCase;
                var existsingTags = featureElement.Tags.Where(x => !x.StartsWith(tagPrefix, StringComparison.OrdinalIgnoreCase) && !x.StartsWith(DocTags.Version, StringComparison.OrdinalIgnoreCase)).ToList();
                existsingTags.Add($"{tagPrefix}{createdId}");
                if (!string.IsNullOrWhiteSpace(version))
                {
                    existsingTags.Add($"{DocTags.Version}{version}");
                }

                featureElement.Tags = existsingTags.ToArray();
            }

            void AppendWorkItemTagInFeatureFile(Feature_ feature, IFeatureElement featureElement, string id)
            {
                var tagPrefix = featureElement.Type.Equals(nameof(Background), StringComparison.Ordinal) ? DocTags.SharedSteps : DocTags.TestCase;
                var featureFile = Directory.EnumerateFiles(FeatureFilesPath, feature.RelativeFolder, SearchOption.AllDirectories).SingleOrDefault();
                var featureLines = File.ReadAllLines(featureFile).Select(x => x.Trim()).ToList();
                var featureElementLine = featureLines.GetFeatureElementIndex(featureElement.Type.Equals(nameof(Background), StringComparison.Ordinal) ? feature.Feature.Name : featureElement.Name);
                if (featureElementLine <= 0)
                {
                    this.LogError(feature.Feature, featureElement, workItem: id, message: $"{featureElement.Type} not found in Feature");
                }

                if (!featureLines[featureElementLine - 1].Contains(tagPrefix))
                {
                    featureLines[featureElementLine - 1] = $"{tagPrefix}{id} " + featureLines[featureElementLine - 1];
#pragma warning disable SG0018 // Path traversal
                    File.WriteAllLines(Path.Combine(FeatureFilesPath, feature.RelativeFolder), featureLines);
#pragma warning restore SG0018 // Path traversal
                }

                ////else
                ////{
                ////    featureLines[scenarioLine - 1] = Regex.Replace(featureLines[scenarioLine - 1], @"@testcase=(\d*)\s", $"@testcase={testCaseId} ");
                ////}

                ////#pragma warning disable SG0018 // Path traversal
                ////                File.WriteAllLines(Path.Combine(FeaturesFolderRelativePath, feature.RelativeFolder), featureLines);
                ////#pragma warning restore SG0018 // Path traversal
            }

            bool NeedsUpdate(WorkItem existingWorkItem, IFeatureElement featureElement)
            {
                var needsUpdate = false;
                var scenarioVersion = featureElement.GetTag(DocTags.Version);

                //// https://stackoverflow.com/a/44586313
                if (string.IsNullOrWhiteSpace(existingWorkItem.Version) && !string.IsNullOrWhiteSpace(scenarioVersion))
                {
                    needsUpdate = true;
                }
                else if (!string.IsNullOrWhiteSpace(existingWorkItem.Version) && !string.IsNullOrWhiteSpace(scenarioVersion))
                {
                    // If local version is > VSTS version
                    if (Convert.ToInt16(scenarioVersion, CultureInfo.InvariantCulture) > Convert.ToInt16(existingWorkItem.Version, CultureInfo.InvariantCulture))
                    {
                        needsUpdate = true;
                    }
                }
                else if (!string.IsNullOrWhiteSpace(existingWorkItem.Version) && string.IsNullOrWhiteSpace(scenarioVersion))
                {
                    this.LogError(message: $"Version mismatch: scenario={featureElement.Name} (@version:empty) / testCase={existingWorkItem.Title} (@version:{existingWorkItem.Version})", justWarn: true);
                }

                return needsUpdate;
            }

            const string or = " / ";
            void HandleScenarioOutlines(FeatureElement scenario)
            {
                if (scenario.Examples?.Length > 0)
                {
                    var examples = new Dictionary<string, string>();
                    foreach (var e in scenario.Examples)
                    {
                        var arg = e.TableArgument;
                        for (var h = 0; h < arg.HeaderRow.Length; h++)
                        {
                            var header = arg.HeaderRow[h];
                            var rows = string.Join(or, arg.DataRows.Select(x => x[h].ToString()));
                            rows = rows.EndsWith(or, StringComparison.Ordinal) ? rows.Remove(rows.LastIndexOf(or, StringComparison.Ordinal)) : rows;
                            examples.Add(header, rows);
                        }
                    }

                    foreach (var step in scenario.Steps)
                    {
                        foreach (var example in examples.Where(x => step.Name.IndexOf($"<{x.Key}>", StringComparison.OrdinalIgnoreCase) >= 0))
                        {
                            if (!example.Equals(default(KeyValuePair<string, string>)))
                            {
                                step.Name = step.Name.Replace($"<{example.Key}>", example.Value);
                            }
                        }
                    }
                }
            }

            return true;
        }

        // TODO: Refactor to reduce duplicate code
        public async Task<bool> GenerateTestCaseUserStoryAssociationsMatrix()
        {
            try
            {
                var testCaseIdsWithTitles = new List<dynamic>();
                var tps = await TestPlansUrl.WithHeader(AuthorizationHeader, Pat)
                                                        .GetJsonAsync<JObject>()
                                                        .ConfigureAwait(false);

                for (var tp = 0; tp < tps["count"].Value<int>(); tp++)
                {
                    var testPlanId = tps.SelectToken($"value[{tp}].id").Value<string>();
                    var testPlanTitle = tps.SelectToken($"value[{tp}].name").Value<string>();

                    Logger.Info($"{tp + 1}. TP:{testPlanId} - {testPlanTitle}");
                    var tss = await string.Format(CultureInfo.InvariantCulture, TestSuitesUrl, testPlanId)
                                            .WithHeader(AuthorizationHeader, Pat)
                                            .GetJsonAsync<JObject>()
                                            .ConfigureAwait(false);

                    for (var ts = 0; ts < tss["count"].Value<int>(); ts++)
                    {
                        var testSuiteId = tss.SelectToken($"value[{ts}].id").Value<string>();
                        var testSuiteTitle = tss.SelectToken($"value[{ts}].name").Value<string>();
                        var suiteType = tss.SelectToken($"value[{ts}].suiteType").Value<string>();
                        Logger.Info($"\t{tp + 1}.{ts + 1}. TS:{testSuiteId} - {testSuiteTitle} ({suiteType})");
                        var tcs = await string.Format(CultureInfo.InvariantCulture, TestCasesUrl, testPlanId, testSuiteId)
                                            .WithHeader(AuthorizationHeader, Pat)
                                            .GetJsonAsync<JObject>()
                                            .ConfigureAwait(false);

                        var testCaseIds = tcs?.SelectTokens("..testCase").Select(s => (string)s["id"])?.ToList();
                        Logger.Info($"\t\t\tTC:{string.Join(",", testCaseIds)} ({testCaseIds.Count})");
                        if (testCaseIds?.Count > 0)
                        {
                            var workItems = await string.Format(CultureInfo.InvariantCulture, WorkItemsUrl, string.Join(",", testCaseIds))
                                            .WithHeader(AuthorizationHeader, Pat)
                                            .GetJsonAsync<JObject>()
                                            .ConfigureAwait(false);

                            foreach (var workItem in workItems?.SelectTokens("value").Children())
                            {
                                var workItemType = workItem?.SelectToken("fields['System.WorkItemType']").Value<string>();
                                if (!workItemType.EqualsIgnoreCase(SharedSteps))
                                {
                                    var id = workItem?.SelectToken("id").Value<string>();
                                    var relations = workItem?.SelectTokens("relations").ToList();
                                    dynamic tc = new System.Dynamic.ExpandoObject();
                                    tc.TestPlanId = testPlanId;
                                    tc.TestPlanTitle = testPlanTitle;
                                    tc.TestSuiteId = testSuiteId;
                                    tc.TestSuiteTitle = testSuiteTitle;
                                    tc.TestCaseId = id;
                                    tc.TestCaseTitle = workItem?.SelectToken("fields['System.Title']").Value<string>();
                                    tc.Automated = Automated.Equals(workItem?.SelectToken("fields['Microsoft.VSTS.TCM.AutomationStatus']").Value<string>(), StringComparison.OrdinalIgnoreCase);
                                    for (var i = 0; i < relations?.Count; i++)
                                    {
                                        var r = relations[i];
                                        r.SelectTokens("[*]")?.ToList().ForEach(async rel =>
                                        {
                                            var relation = new Relation { Rel = (string)rel["rel"], Url = (string)rel["url"] };
                                            if (relation.Rel.Equals(TestedByRequirement, StringComparison.Ordinal))
                                            {
                                                var result = await relation.Url
                                                            .WithHeader(AuthorizationHeader, Pat)
                                                            .GetJsonAsync<JObject>()
                                                            .ConfigureAwait(false);
                                                tc.UserStoryId = result.SelectToken("id")?.Value<int>();
                                                tc.UserStoryTitle = result.SelectTokens("..fields").FirstOrDefault()["System.Title"].Value<string>();
                                            }
                                        });
                                    }

                                    testCaseIdsWithTitles.Add(tc);
                                }
                            }
                        }
                    }
                }

                await new DataSources.CsvDataSource().WriteAll(testCaseIdsWithTitles, "./TestCaseUserStoryAssociations.csv".GetFullPath()).ConfigureAwait(false);
                System.Diagnostics.Process.Start("./TestCaseUserStoryAssociations.csv".GetFullPath());
                return true;
            }
            catch (Exception ex)
            {
                this.LogError(nameof(this.GenerateTestCaseUserStoryAssociationsMatrix), await ex.ToFullStringAsync().ConfigureAwait(false));
                return false;
            }
        }

        /// <summary>
        /// Bulk-deletes Azure DevOps Work-items
        /// Credit: https://stackoverflow.com/a/47027773
        /// </summary>
        /// <param name="testCases">Comma-separated list of Work-items to be deleted</param>
        /// <returns>The task</returns>
        public async Task<bool> DeleteTestCases(string testCases = null)
        {
            try
            {
                var success = true;
                const string delete = "DELETE";
                if (!string.IsNullOrWhiteSpace(testCases))
                {
                    var dialogResult = MessageBox.Show($"Items to delete: {testCases}", "CONTINUE?", MessageBoxButtons.OKCancel);
                    if (dialogResult == DialogResult.OK)
                    {
                        Logger.Debug(testCases);
                        var tcss = testCases.Split(new[] { ' ', ',', ';' }, StringSplitOptions.RemoveEmptyEntries).ChunkBy(MaxLimit);
                        foreach (var tcs in tcss)
                        {
                            var ops = tcs.Select(tc => new { method = delete, uri = $"/_apis/wit/workitems/{tc.Trim()}{ApiVersion}" })?.ToList();
                            using (var content = new CapturedStringContent(ops?.ToJson(), Encoding.UTF8, JsonBatchHttpRequestMediaType))
                            {
                                var result = await TestCaseBatchDeleteUrl
                                                .WithHeader(AuthorizationHeader, Pat)
                                                .PatchAsync(content)
                                                .ConfigureAwait(false);

                                // Sample response: { "count": 1, "value": [ { "code": 500, "headers": { "Content-Type": "application/json; charset=utf-8" }, "body": "{\"count\":1,\"value\":{\"Message\":\"VS401397: Bulk update of 372 work items exceeds batch limit of 200\"}}" } ] }
                                var response = await result.Content.ReadAsJsonAsync<JObject>().ConfigureAwait(false);
                                success = success && response.SelectTokens("..code").Values<int>().All(c => c.Equals(200));
                                var msgs = response.SelectTokens("..body").Values<string>().Select(JToken.Parse).Select(m => m.SelectToken("..Message").Value<string>());
                                Logger.Debug(string.Join(Environment.NewLine, msgs));
                            }
                        }
                    }
                }

                return success;
            }
            catch (Exception ex)
            {
                Logger.Error(await ex.ToFullStringAsync().ConfigureAwait(false));
                return false;
            }
        }

        /// <summary>
        /// Updates/Replaces attachments in VSTS
        /// </summary>
        /// <param name="attachments">A list of ID & File-path pairs</param>
        /// <returns>The completed Task</returns>
        public async Task UpdateAttachments(Dictionary<string, string> attachments)
        {
            foreach (var item in attachments)
            {
                await this.UploadAttachment(item.Key, item.Value).ConfigureAwait(false);
            }
        }

        // Credit: https://stackoverflow.com/a/50015900
        public async Task RenameTags(string remove = "@", Dictionary<string, string> replacements = null)
        {
#pragma warning disable SA1008 // Opening parenthesis must be spaced correctly
#pragma warning disable SA1101 // Prefix local calls with this
            if (string.IsNullOrWhiteSpace(remove) && replacements == null)
            {
                return;
            }

            var projects = await ProjectsUrl
                                .WithHeader(AuthorizationHeader, Pat)
                                .GetJsonAsync<JObject>()
                                .ConfigureAwait(false);

            var project = projects?.SelectToken("value").SingleOrDefault(s => s["name"].Value<string>().Equals(Project, StringComparison.Ordinal)).SelectToken("id").Value<string>();
            var rawTags = await string.Format(CultureInfo.InvariantCulture, TagsUrl, project)
                                .WithHeader(AuthorizationHeader, Pat)
                                .GetJsonAsync<JObject>()
                                .ConfigureAwait(false);

            var tags = rawTags.SelectToken("value").Select(s => (id: s["id"].Value<string>(), name: s["name"].Value<string>(), active: s["active"].Value<bool>()));

            if (!string.IsNullOrWhiteSpace(remove))
            {
                foreach (var tag in tags)
                {
                    await UpdateTag(tag.id, tag.name.Replace(remove, string.Empty)).ConfigureAwait(false);
                }
            }
            else //// if (replacements != null)
            {
                foreach (var item in replacements)
                {
                    var tag = tags.SingleOrDefault(x => x.name.EqualsIgnoreCase(item.Key));
                    await UpdateTag(tag.id, item.Value).ConfigureAwait(false);
                }
            }

            async Task UpdateTag(string id, string name)
            {
                try
                {
                    using (var content = new CapturedStringContent(new { name, active = true }.ToJson(), Encoding.UTF8, JsonBatchHttpRequestMediaType))
                    {
                        var result = await string.Format(CultureInfo.InvariantCulture, TagUrl, project, id)
                                                .WithHeader(AuthorizationHeader, Pat)
                                                .PatchAsync(content)
                                                .ConfigureAwait(false);
                        Logger.Debug(result.StatusCode);
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error(await ex.ToFullStringAsync().ConfigureAwait(false));
                }
            }
#pragma warning restore SA1101 // Prefix local calls with this
#pragma warning restore SA1008 // Opening parenthesis must be spaced correctly
        }

        /// <summary>
        /// Compares VSTS TestCases with BDD Features
        /// </summary>
        /// <param name="featureFilterAction">Only Features that match this condition will be processed and synced</param>
        /// <param name="scenarioFilterAction ">Only Scenarios that match this condition will be processed and synced</param>
        /// <param name="regeneratePicklesFile">Regenerates Pickles file if true</param>
        /// <returns>A <see cref="Task"/> representing the asynchronous operation.</returns>
        public async Task<bool> GenerateTestCasesReport(Func<Feature, bool> featureFilterAction = null, Func<FeatureElement, bool> scenarioFilterAction = null, bool regeneratePicklesFile = true)
        {
            var features = await this.PopulateFeatures(regeneratePicklesFile).ConfigureAwait(false);
            if (features == null)
            {
                this.LogError(message: $"No Features found!", justWarn: true);
                return false;
            }

            var allScenarios = features.Features.Where(f => !f.Feature.HasTag(DocTags.Ignore) && featureFilterAction(f.Feature)).SelectMany(x =>
            {
                var scs = x.Feature.FeatureElements.Where(s => !s.HasTag(DocTags.Ignore) && scenarioFilterAction(s)).ToList();
                scs.ForEach(s => this.OverrideFeatureTags(x.Feature, s, DocTags.Owner, DocTags.TestPlan, DocTags.TestSuite));
                return scs;
            }).ToList();

            Logger.Info($"FEATURES FOUND: {features.Features.Count()} / SCENARIOS FOUND: {allScenarios.Count}" + Environment.NewLine);
            var bddTestCases = allScenarios.Select(s => new TestCase { BddTestCaseId = s.GetTag(DocTags.TestCase), BddScenarioTitle = s.Name, BddManualTag = s.HasTag(DocTags.Manual), BddUITag = s.HasTag(DocTags.UI), BddTestSuiteId = s.GetTag(DocTags.TestSuite), BddTestPlanId = s.GetTag(DocTags.TestPlan) }).ToList();

            var remoteTestCases = new List<TestCase>();
            var tps = await TestPlansUrl.WithHeader(AuthorizationHeader, Pat)
                                        .GetJsonAsync<JObject>()
                                        .ConfigureAwait(false);

            var errors = new List<string>();
            for (var tp = 0; tp < tps["count"].Value<int>(); tp++)
            {
                var testPlanId = tps.SelectToken($"value[{tp}].id").Value<string>();
                var testPlanTitle = tps.SelectToken($"value[{tp}].name").Value<string>();

                Logger.Info($"{tp + 1}. TP:{testPlanId} - {testPlanTitle}");
                var tss = await string.Format(CultureInfo.InvariantCulture, TestSuitesUrl, testPlanId)
                                        .WithHeader(AuthorizationHeader, Pat)
                                        .GetJsonAsync<JObject>()
                                        .ConfigureAwait(false);

                for (var ts = 0; ts < tss["count"].Value<int>(); ts++)
                {
                    var testSuiteId = tss.SelectToken($"value[{ts}].id").Value<string>();
                    var testSuiteTitle = tss.SelectToken($"value[{ts}].name").Value<string>();
                    var suiteType = tss.SelectToken($"value[{ts}].suiteType").Value<string>();
                    Logger.Info($"\t{tp + 1}.{ts + 1}. TS:{testSuiteId} - {testSuiteTitle} ({suiteType})");
                    var tcs = await string.Format(CultureInfo.InvariantCulture, TestCasesUrl, testPlanId, testSuiteId)
                                        .WithHeader(AuthorizationHeader, Pat)
                                        .GetJsonAsync<JObject>()
                                        .ConfigureAwait(false);

                    var testCaseIds = tcs?.SelectTokens("..testCase").Select(s => (string)s["id"])?.ToList();
                    Logger.Info($"\t\t\tTC:{string.Join(",", testCaseIds)} ({testCaseIds.Count})");
                    if (testCaseIds?.Count > 0)
                    {
                        var workItems = await string.Format(CultureInfo.InvariantCulture, WorkItemsUrl, string.Join(",", testCaseIds))
                                        .WithHeader(AuthorizationHeader, Pat)
                                        .GetJsonAsync<JObject>()
                                        .ConfigureAwait(false);

                        var testCaseIdsWithTitles = workItems?.SelectTokens("..fields")?.Select((x, i) => new TestCase
                        {
                            VstsTestCaseId = (string)x["System.Id"] ?? testCaseIds[i],
                            VstsTestCaseTitle = (string)x["System.Title"],
                            VstsNotAutomated = !Automated.Equals((string)x["Microsoft.VSTS.TCM.AutomationStatus"], StringComparison.OrdinalIgnoreCase),
                            VstsClosedReason = (string)x["System.Reason"],
                            VstsTestSuiteId = testSuiteId,
                            VstsTestSuiteTitle = testSuiteTitle,
                            VstsTestPlanId = testPlanId,
                            VstsTestPlanTitle = testPlanTitle,
                            VstsUITag = ((string)x["System.Tags"])?.Replace("; ", ";")?.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries)?.Any(t => t.StartsWith(DocTags.UI, StringComparison.OrdinalIgnoreCase)) == true,
                        }).ToList();

                        testCaseIdsWithTitles.ForEach(async x =>
                        {
                            TestCase bddTestCase;
                            try
                            {
                                bddTestCase = bddTestCases.SingleOrDefault(y => y.BddTestCaseId?.Equals(x.VstsTestCaseId, StringComparison.OrdinalIgnoreCase) == true);
                            }
                            catch (Exception ex)
                            {
                                var errMsg = $"{x.VstsTestCaseId}: {await ex.ToFullStringAsync().ConfigureAwait(false)}";
                                errors.Add(errMsg);
                                Logger.Error(errMsg);
                                bddTestCase = bddTestCases.FirstOrDefault(y => y.BddTestCaseId?.Equals(x.VstsTestCaseId, StringComparison.OrdinalIgnoreCase) == true);
                            }

                            if (bddTestCase != null)
                            {
                                x.BddTestCaseId = bddTestCase.BddTestCaseId;
                                x.BddScenarioTitle = bddTestCase.BddScenarioTitle;
                                x.BddTestSuiteId = bddTestCase.BddTestSuiteId;
                                x.BddTestPlanId = bddTestCase.BddTestPlanId;
                                x.BddManualTag = bddTestCase.BddManualTag;
                                x.BddUITag = bddTestCase.BddUITag;
                            }
                        });

                        var staleTestCases = testCaseIdsWithTitles?.Where(t => !allScenarios.Any(z => z.Name.Trim().Equals(t.VstsTestCaseTitle?.Trim(), StringComparison.OrdinalIgnoreCase))).ToList();
                        if (staleTestCases?.Count > 0)
                        {
                            Logger.Warn($"\t\t\tSTALE TEST-CASES FOR TESTPLAN: {testPlanId} / TESTSUITE: {testSuiteId}" + Environment.NewLine + "\t\t\t" + string.Join(Environment.NewLine + "\t\t\t", staleTestCases.Select(s => $"{s.VstsTestCaseId}: {s.VstsTestCaseTitle}")) + Environment.NewLine);
                        }

                        remoteTestCases.AddRange(testCaseIdsWithTitles);
                    }

                    // Blank Test-Suites
                    if (!remoteTestCases.Any(x => x.VstsTestSuiteId.Equals(testSuiteId, StringComparison.OrdinalIgnoreCase)))
                    {
                        remoteTestCases.Add(new TestCase
                        {
                            VstsTestSuiteId = testSuiteId,
                            VstsTestSuiteTitle = testSuiteTitle,
                            VstsTestPlanId = testPlanId,
                            VstsTestPlanTitle = testPlanTitle,
                        });
                    }
                }

                // Blank Test-Plans
                if (!remoteTestCases.Any(x => x.VstsTestPlanId.Equals(testPlanId, StringComparison.OrdinalIgnoreCase)))
                {
                    remoteTestCases.Add(new TestCase
                    {
                        VstsTestPlanId = testPlanId,
                        VstsTestPlanTitle = testPlanTitle,
                    });
                }
            }

            var onlyBdd = bddTestCases.Where(x => !remoteTestCases.Any(y => x.BddTestCaseId?.Equals(y.BddTestCaseId, StringComparison.OrdinalIgnoreCase) == true)).ToList();
            var manualScenarios = allScenarios?.Where(t => t.HasTag(DocTags.Manual));
            Logger.Info($"TEST-CASES FROM BDD SCENARIOS: TOTAL = {bddTestCases.Count} / WITH-TEST-CASE-TAG = {bddTestCases.Where(t => !string.IsNullOrWhiteSpace(t.BddTestCaseId)).Count()} / BDD-ONLY = {onlyBdd.Count} / MANUAL-SCENARIOS = {manualScenarios.Count()}");
            remoteTestCases.AddRange(onlyBdd);

            using (var textWriter = new StreamWriter("TestCases.csv".GetFullPath()))
            using (var csvWriter = new CsvWriter(textWriter))
            {
                // .Where(x => !ClosedReasons.Contains(x.VstsClosedReason))
                csvWriter.WriteRecords(remoteTestCases.OrderBy(x => x.VstsTestCaseId).ThenBy(x => x.VstsTestSuiteId).ThenBy(x => x.VstsTestPlanId));
            }

            await ExcelHelper.GenerateExcel("TestCases.csv".GetFullPath(), remoteTestCases, errors).ConfigureAwait(false);
            File.Delete("TestCases.csv".GetFullPath());
            System.Diagnostics.Process.Start("TestCases.xlsx".GetFullPath());
            return true;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Spacing Rules", "SA1009:ClosingParenthesisMustBeSpacedCorrectly", Justification = "List of Tuple")]
        public Task<bool> ValidateGenericStepsInBddFeatures()
        {
            //// // https://dev.labs.cognitive.microsoft.com/docs/services/56332331778daf02acc0a50b/operations/58076bdadcf4c40708f83791
            //// var url = "https://api.labs.cognitive.microsoft.com/academic/v1.0/similarity?s1={0}&s2={1}";
            //// const string apiKeyValue = "75a501f2d5964fe4ae36a5b36f4ea2c9";
            //// const string apiKeyHeader = "Ocp-Apim-Subscription-Key";
            //// const string apiKeyValue = "f3ff42f025444790843b527839238032";
            //// const string appId = "098f46e8-d533-4135-a168-931060e3f971";
            //// var url = $"https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/{appId}?q=";

            const int diffThreshold = 4;
            var genericStepPrefixes = new List<string> { "Given I", "When I", "Then I", "And I" };
            var readmeFile = Path.Combine(Directory.GetParent(Directory.GetParent(FeatureFilesPath).FullName).FullName, "Readme.md");
            var readme = File.ReadAllLines(readmeFile).Select(x => x.Trim());
            var pattern = "\"(?!Button|submenu|menu|menuicon|Multi-Select).*?\""; // "\"[^\"]*\""; // "\".*?\""
            var regex = new Regex(pattern, RegexOptions.IgnoreCase);
            var genericSteps = readme.Where(x => genericStepPrefixes.Any(y => x.StartsWith(y, StringComparison.OrdinalIgnoreCase))).Select(z => regex.Replace(z, "\"*\"").ReplaceSuffixes(genericStepPrefixes)).Distinct();

            var featureFiles = Directory.GetFiles(FeatureFilesPath, "*.feature", SearchOption.AllDirectories);
            var steps = new List<KeyValuePair<string, string>>();
            foreach (var feature in featureFiles)
            {
                foreach (var step in File.ReadAllLines(feature).Select((line, index) => new { Line = line, Row = index + 1 }).Where(x => genericStepPrefixes.Any(y => x.Line.StartsWith(y, StringComparison.OrdinalIgnoreCase))))
                {
                    var features = Directory.GetParent(FeatureFilesPath).Name;
                    steps.Add(new KeyValuePair<string, string>(feature.Substring(feature.IndexOf($"{features}\\", StringComparison.OrdinalIgnoreCase) + features.Length + 1) + $" ({step.Row})", step.Line.Trim()));
                }
            }

            var distinct = steps.Select(x => x.Value).Distinct().ToList();
            Logger.Info(distinct.Count);

            var potentialMatches = new List<(string step, string potentialMatch, double confidence)>();
            foreach (var step in distinct) //// .Where(x => x.StartsWith("Given I am logged in", StringComparison.OrdinalIgnoreCase)))
            {
                var matches = new Dictionary<string, double>();
                foreach (var genericStep in genericSteps)
                {
                    var diff_match_patch = new DiffMatchPatch.diff_match_patch();
                    var result = diff_match_patch.diff_main(step.Trim().ReplaceSuffixes(genericStepPrefixes), genericStep).Count(x => x.operation != DiffMatchPatch.Operation.EQUAL);
                    if (result <= diffThreshold)
                    {
                        matches.Add(genericStep, result);
                    }
                }

                var match = matches.OrderBy(x => x.Value).FirstOrDefault();
                Logger.Info($"{step}{Environment.NewLine}{match.Key}{Environment.NewLine}{match.Value}{Environment.NewLine}");
                potentialMatches.Add((step, match.Key, match.Value));
            }

            ExcelHelper.GenerateGenericStepDiscrepancies("GenericStepDiscrepancies.xlsx".GetFullPath(), genericSteps, steps, potentialMatches);
            return Task.FromResult(true);
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Spacing Rules", "SA1009:ClosingParenthesisMustBeSpacedCorrectly", Justification = "List of Tuple")]
        public async Task<bool> ValidateStaleStepsInBddFeatures(bool regeneratePicklesFile = true)
        {
            var features = await this.PopulateFeatures(regeneratePicklesFile).ConfigureAwait(false);
            var automatedScenarios = features.Features.SelectMany(x => x.Feature.FeatureElements).Where(s => !s.HasTag(DocTags.Manual)).ToList();
            var executor = new ConsoleExecutor();
            var result = await executor.RunNugetTool("specflow", arguments: $"stepdefinitionreport \"{TestProjectPath}\" /BinFolder:\"{Directory.GetParent(TestProjectAssemblyPath).FullName}\"").ConfigureAwait(false);
            var resultsFile = "StepDefinitionReport.html".GetFullPath();
            if (File.Exists(resultsFile))
            {
                var results = new HtmlAgilityPack.HtmlDocument();
                results.Load(resultsFile);
                var doc = results.DocumentNode;
                var noBindings = doc.SelectNodes("//tr[@class='noBinding']");
                var noInstances = doc.SelectNodes("//tr[@class='noInstances']");
                Logger.Warn($"\nNO BINDINGS: {noBindings}");
                var noBindingSteps = new List<(string Step, string Scenario, string File)>();
                foreach (var nb in noBindings)
                {
                    var val = nb.SelectSingleNode(".//a[contains(@onclick, 'toggle')]").Attributes["onclick"].Value;
                    var id = val.Split('\'')[1]; //// <a href="#" onclick="toggle('ID0ET4VJB', event); return false;" class="button">[show]
                    var report = doc.SelectSingleNode($"//tr[@id='{id}']");
                    var scenarios = report.SelectNodes(".//a[@class='instanceRef']");
                    var step = report.SelectSingleNode(".//span[@class='stepKeyword']").ParentNode.InnerText.Trim();

                    Logger.Info($"STEP: {step}");
                    foreach (var instance in scenarios)
                    {
                        var scenarioTitle = instance.InnerText;
                        var location = instance.Attributes["title"].Value;
                        if (automatedScenarios.Any(s => scenarioTitle.Contains(s.Name))) //// TODO: Extract exact title from scenarioTitle
                        {
                            // Logger.Debug($"\t\t{scenarioTitle} ({location.Substring(location.IndexOf($"Features\\", StringComparison.OrdinalIgnoreCase) + "Features".Length + 1)})");
                            noBindingSteps.Add((step, scenarioTitle, location.Substring(location.IndexOf($"Features\\", StringComparison.OrdinalIgnoreCase) + "Features".Length + 1)));
                        }
                    }
                }

                Logger.Warn($"\nNO INSTANCES: {noInstances}");
                const string copy0 = " [copy]0";
                const string genericArg = @"(""?(.*)""?|(((.*))))";
                var argsInCurlyBraces = new Regex(@"\{([^\}]+)\}");
                var stepCodeFiles = Directory.EnumerateFiles(Directory.GetParent(FeatureFilesPath).Parent.FullName, "*Step*.cs", SearchOption.AllDirectories).ToDictionary(f => f, f => File.ReadAllLines(f).ToList());
                var noInstanceSteps = new List<(string Step, string Scenario, string File)>();
                foreach (var ni in noInstances)
                {
                    var step = ni.InnerText.Replace(copy0, string.Empty).Trim();
                    var find = argsInCurlyBraces.Replace(step, genericArg);
                    var stepCodeFile = stepCodeFiles.FirstOrDefault(x => x.Value?.Any(l => Regex.Match(l, find).Success) == true);
                    var stepCodeLine = string.Empty;
                    var stepCodeLineIdex = 0;
                    if (stepCodeFile.Value != null)
                    {
                        stepCodeLineIdex = stepCodeFile.Value.FindIndex(stepCodeFile.Value.FindIndex(l => Regex.Match(l, find).Success), l => l.Trim().StartsWith("public ", StringComparison.Ordinal));
                        stepCodeLine = stepCodeFile.Value[stepCodeLineIdex]?.Trim() ?? string.Empty;
                    }

                    noInstanceSteps.Add((step, stepCodeLine ?? string.Empty, stepCodeFile.Key + $" ({stepCodeLineIdex})" ?? string.Empty));
                }

                ExcelHelper.GenerateStaleStepDiscrepancies("StaleStepDiscrepancies.xlsx".GetFullPath(), noBindingSteps, noInstanceSteps);
            }

            return true;
        }

        public async Task<bool> UpgradeVersionForUpdatedScenarios()
        {
            const string prefix = "\tmodified:   ";
            const string suffix = ".feature";
            var executor = new ConsoleExecutor();
            var files = new List<string>();
            var localRepoPath = string.Empty;

            await executor.Run("git.exe", "rev-parse --show-toplevel", onOutputReceived: o =>
            {
                localRepoPath = o;
            }).ConfigureAwait(false);

            await executor.Run("git.exe", "fetch origin master").ConfigureAwait(false);

            // Uncommitted changes to Feature files
            await executor.Run("git.exe", "status", onOutputReceived: o =>
            {
                if (o.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) && o.EndsWith(suffix, StringComparison.OrdinalIgnoreCase))
                {
                    files.Add(o.Replace(prefix, string.Empty).Replace("\\", "/"));
                }
            }).ConfigureAwait(false);

            // Committed Feature file changes diff with master
            var result = await executor.Run("git.exe", $"diff --name-only origin/master {VstsDocTargetSettings[nameof(FeatureFilesPath)]}\\*{suffix}", onOutputReceived: o =>
            {
                if (!files.Contains(o))
                {
                    files.Add(".".GetRelativePath(Path.Combine(localRepoPath, o)).Replace("\\", "/"));
                }
            }).ConfigureAwait(false);

            if (result && files.Count > 0)
            {
                var updatedFeaturesDir = @"Features\Updated".GetFullPath();
                var masterFeaturesDir = @"Features\Master".GetFullPath();

                try
                {
                    if (Directory.Exists(updatedFeaturesDir))
                    {
                        Directory.Delete(updatedFeaturesDir, true);
                    }

                    if (Directory.Exists(masterFeaturesDir))
                    {
                        Directory.Delete(masterFeaturesDir, true);
                    }
                }
                catch
                {
                    // Ignore
                }

                Directory.CreateDirectory(updatedFeaturesDir);
                Directory.CreateDirectory(masterFeaturesDir);

                foreach (var file in files.Distinct())
                {
                    Logger.Info($"\n\nFEATURE FILE: {file}");

                    // Updated file
                    File.Copy(file.GetFullPath(), Path.Combine(updatedFeaturesDir, Path.GetFileName(file)), true);

                    // Master file
                    await executor.Run("cmd.exe", $"/C git show origin/master:\"{file}\" > \"{Path.Combine(masterFeaturesDir, Path.GetFileName(file))}\"").ConfigureAwait(false);

                    result = await RunPickles(updatedFeaturesDir, updatedFeaturesDir).ConfigureAwait(false);
                    if (result)
                    {
                        result = await RunPickles(masterFeaturesDir, masterFeaturesDir).ConfigureAwait(false);
                        if (result)
                        {
                            var updatedFeature = this.PopulateFeatures(Path.Combine(updatedFeaturesDir, PicklesFile))?.Features?.SingleOrDefault()?.Feature;
                            var updatedScenarios = updatedFeature?.FeatureElements.ToList<IFeatureElement>();
                            if (updatedFeature.Background != null)
                            {
                                updatedScenarios.Add(updatedFeature.Background);
                                this.OverrideFeatureTags(updatedFeature, updatedFeature.Background);
                            }

                            var masterFeature = this.PopulateFeatures(Path.Combine(masterFeaturesDir, PicklesFile))?.Features?.SingleOrDefault()?.Feature;
                            var masterScenarios = masterFeature?.FeatureElements.ToList<IFeatureElement>();
                            if (masterFeature.Background != null)
                            {
                                masterScenarios.Add(masterFeature.Background);
                                this.OverrideFeatureTags(masterFeature, masterFeature.Background);
                            }

                            if (updatedScenarios != null && masterScenarios != null)
                            {
                                foreach (var updatedScenario in updatedScenarios)
                                {
                                    var isBackground = updatedScenario.Type.EqualsIgnoreCase(nameof(Background));
                                    var typeTag = isBackground ? DocTags.SharedSteps : DocTags.TestCase;
                                    var masterScenario = masterScenarios.SingleOrDefault(x => x.Name.Equals(updatedScenario.Name, StringComparison.Ordinal) || x.GetTag(typeTag)?.Equals(updatedScenario.GetTag(typeTag), StringComparison.Ordinal) == true);
                                    var updatedVersion = updatedScenario.GetTag(DocTags.Version);
                                    var masterVersion = masterScenario.GetTag(DocTags.Version);

                                    var needsUpgrade = false;
                                    if (!updatedScenario.Name?.Trim()?.Equals(masterScenario?.Name?.Trim(), StringComparison.Ordinal) == true || !updatedScenario.Steps?.Length.Equals(masterScenario?.Steps?.Length) == true || !updatedScenario.Tags?.Count(x => x?.Contains("version") != true).Equals(masterScenario?.Tags?.Count(x => x?.Contains("version") != true)) == true || updatedScenario.Tags?.Any(x => x?.Contains("version") != true && masterScenario?.Tags.Contains(x) != true) == true)
                                    {
                                        Logger.Info($"UPDATED NAME/TAGS/STEPS: master={masterScenario?.Name ?? string.Empty} / local={updatedScenario.Name ?? string.Empty}");
                                        needsUpgrade = true;
                                    }

                                    if (!needsUpgrade)
                                    {
                                        for (var i = 0; i < updatedScenario.Steps.Length; i++)
                                        {
                                            var updatedStep = updatedScenario?.Steps[i];
                                            var masterStep = masterScenario?.Steps[i];
                                            if (!updatedStep?.Name?.Trim()?.Equals(masterStep?.Name?.Trim(), StringComparison.Ordinal) == true)
                                            {
                                                Logger.Info($"UPDATED STEP: master={masterStep?.Name ?? string.Empty} / local={updatedStep?.Name ?? string.Empty}");
                                                needsUpgrade = true;
                                            }
                                        }
                                    }

                                    if (needsUpgrade)
                                    {
                                        if ((string.IsNullOrWhiteSpace(masterVersion) && string.IsNullOrWhiteSpace(updatedVersion)) || masterVersion?.Equals(updatedVersion, StringComparison.Ordinal) == true)
                                        {
                                            Logger.Warn($"Needs Upgrade (master={masterVersion ?? string.Empty} / local={updatedVersion ?? string.Empty}): {updatedScenario.Name ?? string.Empty}");

                                            var featureLines = File.ReadAllLines(file.GetFullPath()).Select(x => x.Trim()).ToList();
                                            var scenarioLine = isBackground ? 1 : featureLines.GetFeatureElementIndex(updatedScenario.Name);
                                            if (featureLines[scenarioLine - 1].Contains(typeTag))
                                            {
                                                if (string.IsNullOrWhiteSpace(updatedVersion))
                                                {
                                                    featureLines[scenarioLine - 1] += $" {DocTags.Version}2";
                                                }
                                                else
                                                {
                                                    featureLines[scenarioLine - 1] = string.Join(" ", updatedScenario.Tags.Where(x => !x.Contains(DocTags.Version))) + $" {DocTags.Version}{int.Parse(updatedVersion, CultureInfo.InvariantCulture) + 1}";
                                                }

                                                File.WriteAllLines(file.GetFullPath(), featureLines);
                                            }
                                        }
                                        else
                                        {
                                            Logger.Info($"Already Upgraded (master={masterVersion ?? string.Empty} / local={updatedVersion ?? string.Empty}): {updatedScenario.Name ?? string.Empty}");
                                        }
                                    }
                                }
                            }
                        }
                    }

                    File.Delete(Path.Combine(updatedFeaturesDir, Path.GetFileName(file)));
                    File.Delete(Path.Combine(masterFeaturesDir, Path.GetFileName(file)));
                }

                var proj = Directory.EnumerateFiles(Directory.GetParent(FeatureFilesPath).Parent.FullName, "*.csproj").FirstOrDefault(); //// TOOD: Multiple projects
                await executor.RunNugetTool("specflow", arguments: $"generateall \"{proj}\"").ConfigureAwait(false);
            }

            return true;
        }

        private static async Task<bool> RunPickles(string featuresDir, string outputDir)
        {
            var executor = new ConsoleExecutor();
            var result = await executor.RunNugetTool("pickles.commandline", toolName: "pickles", arguments: $"--feature-directory \"{featuresDir.TrimEnd('\\')}\" --output-directory \"{outputDir.TrimEnd('\\')}\" --documentation-format JSON").ConfigureAwait(false);
            return result;
        }

        private async Task PopulateAllTestCases(DocFeatures features, HashSet<TestPlan> tps, Func<Feature, bool> featureFilterAction = null, Func<FeatureElement, bool> scenarioFilterAction = null, ConcurrentDictionary<string, string> attachments = null)
        {
            var index = 0;
            foreach (var feature in features?.Features.Where(x => !x.Feature.HasTag(DocTags.Ignore) && featureFilterAction(x.Feature))) ////.Where(x => x.Feature.Name.Equals("FilterPaneForAlertRecipientsGrid", StringComparison.OrdinalIgnoreCase))
            {
                var testPlanId = feature.Feature.GetTag(DocTags.TestPlan);
                var testSuiteId = feature.Feature.GetTag(DocTags.TestSuite);
                this.OverrideFeatureTags(feature.Feature, feature.Feature.Background);

                if (string.IsNullOrWhiteSpace(testPlanId) || string.IsNullOrWhiteSpace(testSuiteId))
                {
                    this.LogError(feature.Feature, testPlan: testPlanId, testSuite: testSuiteId, message: $"{DocTags.TestPlan} / {DocTags.TestSuite} not present", justWarn: true);
                }
                else
                {
                    try
                    {
                        var tp = tps.GetOrAdd(new TestPlan { Id = testPlanId });
                        var ts = tp.TestSuites.GetOrAdd(new TestSuite { Id = testSuiteId });
                        if (ts.UserStory == null)
                        {
                            await PopulateTestCases(testPlanId, testSuiteId, ts).ConfigureAwait(false);
                        }

                        foreach (var currentScenario in feature.Feature.FeatureElements.Where(x => !x.HasTag(DocTags.Ignore) && scenarioFilterAction(x)))
                        {
                            try
                            {
                                this.OverrideFeatureTags(feature.Feature, currentScenario, DocTags.Owner, DocTags.TestPlan, DocTags.TestSuite, DocTags.Version);
                                var scenarioTestPlanId = currentScenario.GetTag(DocTags.TestPlan);
                                var scenarioTestSuiteId = currentScenario.GetTag(DocTags.TestSuite);
                                if (string.IsNullOrWhiteSpace(scenarioTestPlanId) || string.IsNullOrWhiteSpace(scenarioTestSuiteId))
                                {
                                    this.LogError(feature.Feature, currentScenario, testPlan: scenarioTestPlanId, testSuite: scenarioTestSuiteId, message: $"{DocTags.TestPlan}{scenarioTestPlanId} / {DocTags.TestSuite}{scenarioTestSuiteId} empty", justWarn: true);
                                }
                                else if (!scenarioTestPlanId.Equals(testPlanId, StringComparison.OrdinalIgnoreCase) || !scenarioTestSuiteId.Equals(testSuiteId, StringComparison.OrdinalIgnoreCase))
                                {
                                    var stp = tps.GetOrAdd(new TestPlan { Id = scenarioTestPlanId });
                                    var sts = stp.TestSuites.GetOrAdd(new TestSuite { Id = scenarioTestSuiteId });
                                    if (sts.UserStory == null)
                                    {
                                        await PopulateTestCases(scenarioTestPlanId, scenarioTestSuiteId, sts).ConfigureAwait(false);
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                await this.LogError(feature.Feature, currentScenario, testPlanId, testSuiteId, ex: ex).ConfigureAwait(false);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        await this.LogError(feature.Feature, null, testPlanId, testSuiteId, ex: ex).ConfigureAwait(false);
                    }
                }
            }

            async Task PopulateTestCases(string testPlanId, string testSuiteId, TestSuite ts)
            {
                index++;
                Logger.Debug($"{index}) Populating Test-cases: testPlan={testPlanId} / testSuite={testSuiteId}");
                var userStoryId = await GetUserStoryId(testPlanId, testSuiteId, ts).ConfigureAwait(false);
                if (!string.IsNullOrWhiteSpace(userStoryId))
                {
                    ts.UserStory = new WorkItem { Id = userStoryId };
                }

                var testCases = await string.Format(CultureInfo.InvariantCulture, TestCasesUrl, testPlanId, testSuiteId)
                        .WithHeader(AuthorizationHeader, Pat)
                        .GetJsonAsync<JObject>()
                        .ConfigureAwait(false);

                var testCasesIds = testCases?.SelectTokens("..testCase").Select(s => (string)s["id"])?.ToList()?.ChunkBy(MaxLimit);
                if (testCasesIds?.Count > 0)
                {
                    foreach (var testCaseIds in testCasesIds)
                    {
                        var workItems = await string.Format(CultureInfo.InvariantCulture, WorkItemsUrl, string.Join(",", testCaseIds))
                                    .WithHeader(AuthorizationHeader, Pat)
                                    .GetJsonAsync<JObject>()
                                    .ConfigureAwait(false);

                        if (workItems != null)
                        {
                            var ids = workItems?.SelectTokens("value[*].id").ToList();
                            var fields = workItems?.SelectTokens("..fields").ToList();
                            var relations = workItems?.SelectTokens("..relations").ToList();
                            for (var i = 0; i < ids.Count; i++)
                            {
                                var id = (string)ids[i];
                                var x = fields[i];
                                var tc = new VstsTestCase
                                {
                                    Id = id,
                                    Title = (string)x["System.Title"],
                                    State = (string)x["System.State"],
                                    Reason = (string)x["System.Reason"],
                                    AutomationStatus = (string)x["Microsoft.VSTS.TCM.AutomationStatus"],
                                    AutomatedTestType = (string)x["Microsoft.VSTS.TCM.AutomatedTestType"],
                                    AutomatedTestId = (string)x["Microsoft.VSTS.TCM.AutomatedTestId"],
                                    AutomatedTestName = (string)x["Microsoft.VSTS.TCM.AutomatedTestName"],
                                    AutomatedTestStorage = (string)x["Microsoft.VSTS.TCM.AutomatedTestStorage"],
                                    Version = ((string)x["System.Tags"])?.Replace("; ", ";")?.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries)?.GetTag(DocTags.Version, true),
                                };

                                if (!ClosedReasons.Contains(tc.Reason))
                                {
                                    if (relations?.Count > 0 && i < relations?.Count)
                                    {
                                        var rels = relations[i]?.SelectTokens("[*]")?.Select(rel =>
                                        {
                                            var relation = new Relation { Rel = (string)rel["rel"], Url = (string)rel["url"] };
                                            if (relation.Rel.Equals(AttachedFile, StringComparison.Ordinal))
                                            {
                                                relation.Name = rel.SelectToken("..name").Value<string>();
                                                relation.Comment = rel.SelectToken("..comment")?.Value<string>();
                                                attachments?.GetOrAdd(relation.Name, relation.Url);
                                            }

                                            return relation;
                                        });
                                        tc.Relations.AddRange(rels);
                                    }

                                    ts.TestCases.GetOrAdd(tc);
                                }
                            }
                        }
                    }
                }

                var sharedStepsRelations = ts.TestCases.SelectMany(x => x.Relations?.Where(y => y.Rel?.Equals(SharedStepReferencedBy, StringComparison.Ordinal) == true));
                var ss = sharedStepsRelations?.Select(y => y.Url?.Substring(y.Url.LastIndexOf('/') + 1))?.Distinct().ToList();
                if (ss.Count > 0)
                {
                    var sharedSteps = await string.Format(CultureInfo.InvariantCulture, WorkItemsUrl, string.Join(",", ss))
                            .WithHeader(AuthorizationHeader, Pat)
                            .GetJsonAsync<JObject>()
                            .ConfigureAwait(false);

                    var sharedStepsIds = sharedSteps?.SelectTokens("value[*].id").ToList();
                    var sharedStepsFields = sharedSteps?.SelectTokens("..fields").ToList();
                    for (var i = 0; i < sharedStepsIds.Count; i++)
                    {
                        var id = (string)sharedStepsIds[i];
                        var x = sharedStepsFields[i];
                        var sharedStep = new WorkItem
                        {
                            Id = id,
                            Title = (string)x["System.Title"],
                            State = (string)x["System.State"],
                            Version = ((string)x["System.Tags"])?.Replace("; ", ";")?.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries).GetTag(DocTags.Version, true),
                        };

                        ts.SharedSteps.Add(sharedStep);
                    }
                }
            }

            async Task<string> GetUserStoryId(string testPlanId, string testSuiteId, TestSuite ts)
            {
                try
                {
                    if (!string.IsNullOrWhiteSpace(testPlanId) && !string.IsNullOrWhiteSpace(testSuiteId))
                    {
                        var testSuite = await string.Format(CultureInfo.InvariantCulture, TestSuiteUrl, testPlanId, testSuiteId)
                                .WithHeader(AuthorizationHeader, Pat)
                                .GetJsonAsync<JObject>()
                                .ConfigureAwait(false);
                        Assert.IsNotNull(testSuite);

                        var suiteType = testSuite?.SelectToken("suiteType")?.Value<string>();
                        ts.SuiteType = suiteType;
                        if (suiteType.EqualsIgnoreCase(RequirementTestSuiteType))
                        {
                            var userStoryId = testSuite?.SelectToken("requirementId")?.Value<string>();
                            Assert.IsNotNull(userStoryId);
                            return userStoryId;
                        }
                    }
                }
                catch (Exception ex)
                {
                    await this.LogError(testPlan: testPlanId, testSuite: testSuiteId, ex: ex).ConfigureAwait(false);
                }

                return null;
            }
        }

        private async Task<DocFeatures> PopulateFeatures(bool regeneratePicklesFile)
        {
            var picklesFile = PicklesFile.GetFullPath();
            var outputDir = Path.GetDirectoryName(picklesFile);

            try
            {
                if (regeneratePicklesFile)
                {
                    await RunPickles(FeatureFilesPath, outputDir).ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                Logger.Error(await ex.ToFullStringAsync().ConfigureAwait(false));
            }

            var features = this.PopulateFeatures(picklesFile, true);
            return features;
        }

        private DocFeatures PopulateFeatures(string picklesFile, bool showConfirmation = false, [CallerMemberName] string member = "")
        {
            if (showConfirmation)
            {
                var dialogResult = MessageBox.Show($"Account: '{Account}'{Environment.NewLine}Project: '{Project}'{Environment.NewLine}IterationPath: '{IterationPath}'{Environment.NewLine}AreaPath: '{AreaPath}'{Environment.NewLine}{nameof(FeatureFilesPath)}: '{VstsDocTargetSettings[nameof(FeatureFilesPath)]}'{Environment.NewLine}{Environment.NewLine}'{Path.GetFileName(picklesFile)}' last updated: '{File.GetLastWriteTime(picklesFile).ToString("R", CultureInfo.CurrentCulture)}'", "CONTINUE?", MessageBoxButtons.OKCancel);
                if (dialogResult == DialogResult.Cancel)
                {
                    Logger.Warn($"Operation canceled by User: {member}");
                    return null;
                }
            }

            var featuresText = picklesFile.GetContent(true);

            //// Assert.IsNotNull(featuresText);
            if (featuresText != null)
            {
                var result = JsonConvert.DeserializeObject<DocFeatures>(featuresText);
                return result;
            }
            else
            {
                Logger.Warn($"featuresText null: {picklesFile}");
                return null;
            }
        }

#pragma warning disable SA1009 // Closing parenthesis must be spaced correctly
        private IEnumerable<(string Namespace, string Feature, string TestName, string Scenario, string TestCaseId)> GetTestsWithTestCaseIds()
#pragma warning restore SA1009 // Closing parenthesis must be spaced correctly
        {
            const string testcasePrefix = "testcase=";
            var types = TestAssembly.GetTypes().Where(x => x.Name.EndsWith(nameof(Feature), StringComparison.OrdinalIgnoreCase));
            var methods = types.SelectMany(x => x.GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly)).Where(m => m.DeclaringType != typeof(object) && !m.IsSpecialName && m.CustomAttributes.Any(z => z.AttributeType.Name.Contains(nameof(DescriptionAttribute))));
            var cad = methods.Select(x =>
            {
                var desc = x.CustomAttributes?.FirstOrDefault(y => y.AttributeType.Name.Contains(nameof(DescriptionAttribute)));
                var cat = x.CustomAttributes?.FirstOrDefault(y => y.ConstructorArguments?.FirstOrDefault().Value?.ToString()?.StartsWith(testcasePrefix, StringComparison.OrdinalIgnoreCase) == true);
#pragma warning disable SA1008 // Opening parenthesis must be spaced correctly
#pragma warning disable SA1101 // Prefix local calls with this
                var item = (Namespace: x.ReflectedType.Namespace, Feature: x.ReflectedType.Name, TestName: x.Name, Scenario: desc?.ConstructorArguments?.FirstOrDefault().Value?.ToString(), TestCaseId: cat?.ConstructorArguments?.FirstOrDefault().Value?.ToString().Replace(testcasePrefix, string.Empty));
#pragma warning restore SA1101 // Prefix local calls with this
#pragma warning restore SA1008 // Opening parenthesis must be spaced correctly
                return item;
            });

            return cad;
        }

        private void OverrideFeatureTags(Feature feature, IFeatureElement featureElement, params string[] tagsToOverride)
        {
            if (featureElement != null)
            {
                var featureTags = feature.Tags.ToList();
                foreach (var tag in tagsToOverride)
                {
                    if (featureElement.HasTag(tag) && feature.HasTag(tag))
                    {
                        featureTags.Remove(featureTags.SingleOrDefault(t => t.StartsWith(tag, StringComparison.OrdinalIgnoreCase)));
                    }
                }

                featureElement.Tags = featureElement.Tags.Union(featureTags).ToArray();
            }
        }

        private async Task<string> UploadAttachment(string name, string filePath, bool update = false)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    var bytes = File.ReadAllBytes(filePath);
                    var request = (update
                                ? name + ApiVersion
                                : string.Format(CultureInfo.InvariantCulture, CreateAttachmentUrl, HttpUtility.UrlEncode(name)))
                                    .WithHeader(AuthorizationHeader, Pat)
                                    .WithHeader(ContentTypeHeader, OctetStreamMediaType);

                    using (var byteArrayContent = new ByteArrayContent(bytes))
                    {
                        var result = update
                                ? await request
                                        .WithHeader(ContentSizeHeader, bytes.Length)
                                        .WithHeader(ContentRangeHeader, string.Format(CultureInfo.InvariantCulture, ContentRangeValue, bytes.Length - 1, bytes.Length))
                                        .PutAsync(byteArrayContent)
                                        .ConfigureAwait(false)
                                : await request
                                        .PostAsync(byteArrayContent)
                                        .ConfigureAwait(false);

                        var content = await result.Content.ReadAsJsonAsync<JObject>().ConfigureAwait(false);
                        var id = content.SelectToken("id").Value<string>();
                        var uri = content.SelectToken("url").Value<string>();
                        var nm = content.SelectToken("..name")?.Value<string>();
                        Logger.Info($"{id} - {nm ?? string.Empty}: {uri}");
                        return uri;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error(await ex.ToFullStringAsync().ConfigureAwait(false));
            }

            return null;
        }

        private async Task LogError(Feature feature = null, IFeatureElement featureElement = null, string testPlan = "", string testSuite = "", string workItem = "", Exception ex = null, bool assert = true, bool justWarn = false, [CallerMemberName] string member = "", [CallerLineNumber] int line = 0)
        {
            var message = await ex.ToFullStringAsync(member, line).ConfigureAwait(false);
            this.LogError(feature, featureElement, testPlan, testSuite, workItem, message, assert, justWarn);
        }

        private void LogError(Feature feature = null, IFeatureElement featureElement = null, string testPlan = "", string testSuite = "", string workItem = "", string message = null, bool assert = true, bool justWarn = false)
        {
            var details = new StringBuilder();
            if (feature != null)
            {
                var owner = feature.GetTag(DocTags.Owner) ?? "owner?";
                details.Append($"[{owner}] {nameof(feature)}={feature.Name}");
            }

            if (featureElement != null)
            {
                details.Append($" / {featureElement.Type}={featureElement.Name}");
            }

            if (!string.IsNullOrWhiteSpace(testPlan))
            {
                details.Append($" / {nameof(testPlan)}={testPlan}");
            }

            if (!string.IsNullOrWhiteSpace(testSuite))
            {
                details.Append($" / {nameof(testSuite)}={testSuite}");
            }

            if (!string.IsNullOrWhiteSpace(workItem))
            {
                var name = featureElement.Type.Equals(nameof(Background), StringComparison.Ordinal) ? "sharedSteps" : "testCase";
                details.Append($" / {name}={workItem}");
            }

            this.LogError(message, details.ToString().TrimStart('/'), assert, justWarn);
        }

        private void LogError(string message, string details, bool assert = true, bool justWarn = false)
        {
            var exceptionMessage = string.IsNullOrWhiteSpace(message) ? details : $"{message}: {details}";
            if (justWarn)
            {
                Logger.Warn(exceptionMessage);
                if (assert)
                {
                    Assert.Warn(exceptionMessage);
                }
            }
            else
            {
                Logger.Error(exceptionMessage);
                if (assert)
                {
                    Assert.Fail(exceptionMessage);
                }
            }
        }

        internal struct StepDefs
        {
            internal const string Given = "Given";
            internal const string When = "When";
            internal const string Then = "Then";
            internal const string And = "And";
            internal const string But = "But";
        }
    }
}