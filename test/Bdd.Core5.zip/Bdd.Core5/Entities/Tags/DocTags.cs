﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DocTags.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.Entities.Tags
{
    public static class DocTags
    {
        public const string TestPlan = "@testplan=";

        public const string TestSuite = "@testsuite=";

        public const string TestCase = "@testcase=";

        public const string SharedSteps = "@sharedsteps=";

        public const string Version = "@version=";

        public const string Priority = "@priority=";

        public const string Manual = "@manual";

        public const string UI = "@ui";

        public const string Api = "@api";

        public const string Ignore = "@ignore";

        public const string Owner = "@owner=";

        public const string Bvt = "@bvt";

        public const string Attach = "@attach=";

        public const string Input = "@input=";

        public const string Output = "@output=";
    }
}