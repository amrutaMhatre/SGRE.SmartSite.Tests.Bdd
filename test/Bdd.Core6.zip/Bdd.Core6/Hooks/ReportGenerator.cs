﻿// <copyright file="ReportGenerator.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>

namespace Bdd.Core.Hooks
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Xml.Linq;

    using AventStack.ExtentReports;
    using AventStack.ExtentReports.MarkupUtils;

    using Bdd.Core.Entities.Tags;
    using Bdd.Core.Utils;

    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;

    using NLog;

    using TechTalk.SpecFlow;

    /// <summary>
    /// http://extentreports.com/docs/versions/4/net/.
    /// </summary>
    [Binding]
    public class ReportGenerator
    {
        public const string ReportLogs = nameof(ReportLogs);

        private const int Order = 10;
        private const string Owner = "owner";

        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private static readonly NameValueCollection ReportSettings = ConfigurationManager.GetSection("reporting") as NameValueCollection;
        private static readonly bool Enabled = ReportSettings != null && bool.TryParse(ReportSettings["Enabled"], out var enabled) && enabled;
        private static readonly bool ShowSteps = Enabled && bool.TryParse(ReportSettings["ShowSteps"], out var showSteps) && showSteps;
        private static readonly bool ShowLogs = Enabled && bool.TryParse(ReportSettings["ShowLogs"], out var showLogs) && showLogs;
        private static readonly List<string> TagsToExclude = new List<string> { DataSourceTags.InputTag, DataSourceTags.OutputTag, DataSourceTags.BeforeTag, DataSourceTags.AfterTag, DocTags.Owner.TrimStart('@') };

        private static ConcurrentBag<string> categoriesList;
        private static ConcurrentBag<string> ownersList;

        [BeforeTestRun(Order = Order)]
        public static async Task Initialize()
        {
            await ExtentManager.Initialize().ConfigureAwait(false);
        }

        [AfterTestRun(Order = Order)]
        public static void Flush()
        {
            ExtentManager.Flush();
        }

        [BeforeFeature(Order = Order)]
        public static void BeforeFeature(FeatureContext featureContext)
        {
            try
            {
                if (Enabled)
                {
                    categoriesList = new ConcurrentBag<string>();
                    ownersList = new ConcurrentBag<string>();

                    var featureNode = ExtentManager.CreateFeatureNode(featureContext);
                    var categories = featureContext.FeatureInfo.Tags.Where(x => !TagsToExclude.Any(t => x.StartsWith(t, StringComparison.OrdinalIgnoreCase))).ToList();
                    PopulateMetadata(categories, featureContext.GetTag(Owner));
                }
            }
            catch (Exception ex)
            {
                Logger.Warn(ex);
            }
#pragma warning restore CA1031 // Do not catch general exception types
        }

        [AfterFeature(Order = Order)]
        public static void AfterFeature(FeatureContext featureContext)
        {
            try
            {
                if (Enabled)
                {
                    var featureNode = ExtentManager.GetFeatureNode();
                    AddMetadata(featureNode, categoriesList.ToArray(), ownersList.ToArray());
                    LogToReport(featureNode, featureContext);
                }
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
            {
                Logger.Warn(ex);
            }
#pragma warning restore CA1031 // Do not catch general exception types
        }

        [Before(Order = Order)]
        public void BeforeScenario(ScenarioContext scenarioContext, FeatureContext featureContext)
        {
            try
            {
                if (Enabled)
                {
                    var scenarioNode = ExtentManager.CreateScenarioNode(scenarioContext);
                    var categories = scenarioContext.ScenarioInfo.Tags.Where(x => !TagsToExclude.Any(t => x.StartsWith(t, StringComparison.OrdinalIgnoreCase))).ToList();
                    PopulateMetadata(categories, scenarioContext.GetTag(Owner));
                    AddMetadata(scenarioNode, categories.ToArray(), scenarioContext.GetTag(Owner) ?? featureContext.GetTag(Owner));
                }
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
            {
                Logger.Warn(ex);
            }
#pragma warning restore CA1031 // Do not catch general exception types
        }

        [After(Order = Order)]
        public async Task AfterScenario(ScenarioContext scenarioContext)
        {
            try
            {
                if (Enabled)
                {
                    var scenarioNode = ExtentManager.GetScenarioNode();
                    //////// extent.AddTestRunnerLogs(scenarioContext.Get<List<object>>(ReportLogs).Select(x => x.ToString()).ToArray());
                    //////// scenarioNode.Info(scenarioContext.Get<List<object>>(ReportLogs).Select(x => x.ToString()).FirstOrDefault());
                    ////var logContext = scenarioNode.Model.LogContext.Get(scenarioNode.Model.LogContext.Count - 1);
                    ////logContext.Details += Environment.NewLine + string.Join(Environment.NewLine, scenarioContext.Get<List<object>>(ReportLogs).Select(x => x.ToString()));
                    await HandleStatus(scenarioNode, scenarioContext).ConfigureAwait(false);
                    LogToReport(scenarioNode, scenarioContext);
                }
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
            {
                Logger.Warn(await ex.ToFullStringAsync().ConfigureAwait(false));
            }
#pragma warning restore CA1031 // Do not catch general exception types
        }

        [AfterStep(Order = Order)]
        public async Task AfterStep(ScenarioContext scenarioContext)
        {
            try
            {
                if (ShowSteps)
                {
                    var stepNode = ExtentManager.CreateStepNode(scenarioContext);
                    await HandleStatus(stepNode, scenarioContext).ConfigureAwait(false);
                    LogToReport(stepNode, scenarioContext.StepContext);
                }
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
            {
                Logger.Warn(await ex.ToFullStringAsync().ConfigureAwait(false));
            }
#pragma warning restore CA1031 // Do not catch general exception types
        }

        private static void PopulateMetadata(List<string> categories, string owner)
        {
            try
            {
                categories.ForEach(categoriesList.Add);
                ownersList.Add(owner);
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
            {
                Logger.Warn(ex);
            }
#pragma warning restore CA1031 // Do not catch general exception types
        }

        private static void AddMetadata(ExtentTest node, string[] categories, params string[] authors)
        {
            try
            {
                if (categories.Length > 0)
                {
                    node.AssignCategory(categories.Distinct().ToArray());
                }

                if (authors.Length > 0)
                {
                    node.AssignAuthor(authors.Distinct().ToArray());
                }
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
            {
                Logger.Warn(ex);
            }
#pragma warning restore CA1031 // Do not catch general exception types
        }

        private static async Task HandleStatus(ExtentTest node, ScenarioContext scenarioContext)
        {
            try
            {
                if (scenarioContext.TestError != null)
                {
                    // var pageSource = scenarioContext.GetDriverContext().SavePageSource();
                    var screenshot = string.Empty;
                    var filename = string.Empty;
                    var file = scenarioContext.GetDriverContext()?.TakeAndSaveScreenshot()?.LastOrDefault();
                    if (!string.IsNullOrWhiteSpace(file))
                    {
                        filename = Path.GetFileName(file);
                        screenshot = ExtentManager.ReportPath.GetRelativePath(file);
                    }

                    node.Fail(await scenarioContext.TestError.ToFullStringAsync().ConfigureAwait(false), string.IsNullOrWhiteSpace(screenshot) ? null : MediaEntityBuilder.CreateScreenCaptureFromPath(screenshot, filename).Build());
                }
                else if (scenarioContext.ScenarioExecutionStatus == ScenarioExecutionStatus.StepDefinitionPending)
                {
                    node.Skip("Step-Definition(s) pending");
                }
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
            {
                Logger.Warn(await ex.ToFullStringAsync().ConfigureAwait(false));
            }
#pragma warning restore CA1031 // Do not catch general exception types
        }

        private static void LogToReport(ExtentTest node, SpecFlowContext context)
        {
            if (ShowLogs && context.ContainsKey(ReportLogs))
            {
                foreach (var log in context.Get<List<object>>(ReportLogs))
                {
                    if (log is JToken)
                    {
                        node.Log(Status.Debug, MarkupHelper.CreateCodeBlock(JsonConvert.SerializeObject(log), CodeLanguage.Json));
                    }
                    else if (log is XElement)
                    {
                        node.Log(Status.Debug, MarkupHelper.CreateCodeBlock(log.ToString().Trim(), CodeLanguage.Xml));
                    }
                    else if (log is Dictionary<string, object>)
                    {
                        // string[][] data = { ((Dictionary<string, object>)log).Keys.ToArray(), ((Dictionary<string, object>)log).Values.Select(x => x.ToString()).ToArray() };
                        var dict = ((Dictionary<string, object>)log).Select(x => new string[] { x.Key, x.Value.ToString() });
                        node.Log(Status.Debug, MarkupHelper.CreateTable(dict.ToArray()));
                    }
                    else
                    {
                        node.Log(Status.Debug, MarkupHelper.CreateLabel(log.ToString(), ExtentColor.Yellow));
                    }
                }
            }
        }
    }
}
