﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="TestDataHooks.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.Hooks
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Text.RegularExpressions;
    using System.Threading.Tasks;

    using global::Bdd.Core.DataSources;
    using global::Bdd.Core.Entities.Tags;
    using global::Bdd.Core.Utils;

    using NLog;

    using NUnit.Framework;

    using TechTalk.SpecFlow;
    using TechTalk.SpecFlow.Bindings.Reflection;

    /// <summary>
    /// The base class for all tests
    /// <see href="https://github.com/ObjectivityLtd/Ocaramba/wiki/ProjectTestBase-class">More details on wiki</see>
    /// </summary>
    /// <seealso cref="Ocaramba.TestBase" />
    [Binding]
    public sealed class TestDataHooks
    {
        private const int Order = 2;
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        private static readonly ConcurrentDictionary<Type, object> TypeInstances = new ConcurrentDictionary<Type, object>();
        private static readonly Type[] Types = AppDomain.CurrentDomain.GetAssemblies().Where(p => !p.IsDynamic).SelectMany(x => x.GetExportedTypes()).Where(t => t.IsClass).ToArray();
        private static IEnumerable<KeyValuePair<Type, Dictionary<MethodInfo, StepArgumentTransformationAttribute[]>>> stepArgTransformMethods;

        private static IEnumerable<KeyValuePair<Type, Dictionary<MethodInfo, StepArgumentTransformationAttribute[]>>> StepArgTransformMethods
        {
            get
            {
                if (stepArgTransformMethods == null)
                {
                    var bindingTypes = Types.Where(t => t.GetCustomAttribute(typeof(BindingAttribute), true) != null).ToArray();
                    stepArgTransformMethods = bindingTypes.ToDictionary(t => t, t => t.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly).Where(m => m.GetCustomAttributes<StepArgumentTransformationAttribute>(true)?.Any() == true).ToDictionary(m => m, m => m.GetCustomAttributes<StepArgumentTransformationAttribute>(true).ToArray())).Where(x => x.Value?.Values.Count > 0);
                }

                return stepArgTransformMethods;
            }
        }

        [BeforeFeature(Order = Order)]
        public static async Task BeforeFeature(FeatureContext featureContext)
        {
            foreach (var tag in featureContext.FeatureInfo.Tags.Where(x => x.StartsWith(DataSourceTags.InputTag, StringComparison.OrdinalIgnoreCase)))
            {
                var tagValue = featureContext.GetTag(tag);
                var ext = Path.GetExtension(tagValue);
                var type = Types.SingleOrDefault(x => x.Name.Equals(Path.GetFileNameWithoutExtension(tagValue), StringComparison.Ordinal));
                if (string.IsNullOrEmpty(ext) || type == null)
                {
                    await featureContext.SetValue<dynamic>(tag).ConfigureAwait(false);
                }
                else
                {
                    var result = false;
                    try
                    {
                        var method = typeof(SpecFlowExtensions).GetMethod("SetValue", new Type[] { typeof(FeatureContext), typeof(string), typeof(string) });
                        var genericMethod = method?.MakeGenericMethod(type);
                        result = (bool)await genericMethod.InvokeAsync(null, new object[] { featureContext, tag, null, featureContext }).ConfigureAwait(false);
                    }
                    catch (Exception ex)
                    {
                        Logger.Warn(ex);
                    }

                    if (!result)
                    {
                        result = await featureContext.SetValue<dynamic>(tag).ConfigureAwait(false);
                    }
                }
            }

            foreach (var tag in featureContext.FeatureInfo.Tags.Where(x => x.StartsWith(DataSourceTags.OutputTag, StringComparison.OrdinalIgnoreCase)))
            {
                await featureContext.SetValue<IDataSource>(tag).ConfigureAwait(false);
            }

            foreach (var tag in featureContext.FeatureInfo.Tags.Where(x => x.StartsWith(DataSourceTags.BeforeTag, StringComparison.OrdinalIgnoreCase)))
            {
                await featureContext.SetValue<dynamic>(tag).ConfigureAwait(false);
            }

            foreach (var tag in featureContext.FeatureInfo.Tags.Where(x => x.StartsWith(DataSourceTags.ChaosTag, StringComparison.OrdinalIgnoreCase)))
            {
                await featureContext.SetValue<dynamic>(tag).ConfigureAwait(false);
            }
        }

        [AfterFeature(Order = Order)]
        public static async Task AfterFeature(FeatureContext featureContext)
        {
            foreach (var tag in featureContext.FeatureInfo.Tags.Where(x => x.StartsWith(DataSourceTags.AfterTag, StringComparison.OrdinalIgnoreCase)))
            {
                await featureContext.SetValue<dynamic>(tag).ConfigureAwait(false);
            }

            await RollbackChaos(featureContext).ConfigureAwait(false);
        }

        [BeforeScenario(Order = Order)]
        public async Task BeforeScenario(ScenarioContext scenarioContext, FeatureContext featureContext)
        {
            foreach (var tag in scenarioContext.ScenarioInfo.Tags.Where(x => x.StartsWith(DataSourceTags.InputTag, StringComparison.OrdinalIgnoreCase)))
            {
                var tagValue = scenarioContext.GetTag(tag);
                var ext = Path.GetExtension(tagValue);
                var type = Types.SingleOrDefault(x => x.Name.Equals(Path.GetFileNameWithoutExtension(tagValue), StringComparison.Ordinal));
                if (string.IsNullOrEmpty(ext) || type == null)
                {
                    await scenarioContext.SetValue<dynamic>(tag, parentContext: featureContext).ConfigureAwait(false);
                }
                else
                {
                    var result = false;
                    try
                    {
                        var method = typeof(SpecFlowExtensions).GetMethod("SetValue", new Type[] { typeof(ScenarioContext), typeof(string), typeof(string), typeof(FeatureContext) });
                        var genericMethod = method?.MakeGenericMethod(type);
                        result = (bool)await genericMethod.InvokeAsync(null, new object[] { scenarioContext, tag, null, featureContext }).ConfigureAwait(false);
                    }
                    catch (Exception ex)
                    {
                        Logger.Warn(ex);
                    }

                    if (!result)
                    {
                        result = await scenarioContext.SetValue<dynamic>(tag, parentContext: featureContext).ConfigureAwait(false);
                    }
                }
            }

            foreach (var tag in scenarioContext.ScenarioInfo.Tags.Where(x => x.StartsWith(DataSourceTags.OutputTag, StringComparison.OrdinalIgnoreCase)))
            {
                await scenarioContext.SetValue<IDataSource>(tag, parentContext: featureContext).ConfigureAwait(false);
            }

            foreach (var tag in scenarioContext.ScenarioInfo.Tags.Where(x => x.StartsWith(DataSourceTags.BeforeTag, StringComparison.OrdinalIgnoreCase)))
            {
                await scenarioContext.SetValue<dynamic>(tag, parentContext: featureContext).ConfigureAwait(false);
            }

            foreach (var tag in scenarioContext.ScenarioInfo.Tags.Where(x => x.StartsWith(DataSourceTags.ChaosTag, StringComparison.OrdinalIgnoreCase)))
            {
                await scenarioContext.SetValue<dynamic>(tag, parentContext: featureContext).ConfigureAwait(false);
            }
        }

        [AfterScenario(Order = Order)]
        public async Task AfterScenario(ScenarioContext scenarioContext, FeatureContext featureContext)
        {
            foreach (var tag in scenarioContext.ScenarioInfo.Tags.Where(x => x.StartsWith(DataSourceTags.AfterTag, StringComparison.OrdinalIgnoreCase)))
            {
                await scenarioContext.SetValue<dynamic>(tag, parentContext: featureContext).ConfigureAwait(false);
            }

            await RollbackChaos(scenarioContext).ConfigureAwait(false);
        }

        [BeforeStep(Order = Order)]
        public async Task BeforeStep(ScenarioContext scenarioContext, FeatureContext featureContext)
        {
            await ExecuteBeforeAfter(scenarioContext, featureContext, DataSourceTags.BeforeTag).ConfigureAwait(false);
        }

        [AfterStep(Order = Order)]
        public async Task AfterStep(ScenarioContext scenarioContext, FeatureContext featureContext)
        {
            await ExecuteBeforeAfter(scenarioContext, featureContext, DataSourceTags.AfterTag).ConfigureAwait(false);
            //// await RollbackChaos(scenarioContext.StepContext).ConfigureAwait(false);
        }

        private static async Task ExecuteBeforeAfter(ScenarioContext scenarioContext, FeatureContext featureContext, string beforeOrAfter)
        {
            // Populate the Step-parameter values in SpecFlowContext automatically so they can be used in Runtime-Invocations easily
            var binding = scenarioContext.StepContext.StepInfo.BindingMatch;
            var method = ((RuntimeBindingMethod)binding.StepBinding.Method).MethodInfo;
            var parameters = method.GetParameters()?.ToList();
            for (var i = 0; i < parameters?.Count; i++)
            {
                try
                {
                    var p = parameters[i];
                    var val = binding.Arguments[i];
                    var t = p.ParameterType;
                    if (!t.IsPrimitive && t != typeof(decimal) && t != typeof(string) && t != typeof(DateTime) && t != typeof(DateTimeOffset) && t != typeof(TechTalk.SpecFlow.Table))
                    {
#pragma warning disable SA1008 // Opening parenthesis must be spaced correctly

                        // var tm = StepArgTransformMethods.Select(x => (Type: x.Key, Method: x.Value.SingleOrDefault(y => y.Key.ReturnType == t && y.Value.Any(a => Regex.IsMatch(val.ToString(), a.Regex))).Key)).SingleOrDefault();
                        var tm = StepArgTransformMethods.Select(x => (Type: x.Key, Method: x.Value.SingleOrDefault(y => y.Key.ReturnType == t && y.Value.Any(a => Regex.IsMatch(val.ToString(), a.Regex))).Key, Regex: x.Value?.SingleOrDefault(y => y.Key.ReturnType == t).Value?.SingleOrDefault(a => Regex.IsMatch(val.ToString(), a.Regex)))).SingleOrDefault();
#pragma warning restore SA1008 // Opening parenthesis must be spaced correctly

                        // val = scenarioContext.GetCredential(val.ToString(), $"{DataSourceTags.InputTag}Credentials.xlsx");
                        if (tm.Method != null)
                        {
                            object instance = null;
                            if (!tm.Method.IsStatic)
                            {
                                instance = TypeInstances.GetOrAdd(tm.Type, Activator.CreateInstance(tm.Type, tm.Type.GetConstructorContextParameters(scenarioContext, featureContext)));
                            }

                            string[] matches = null;
                            if (val is string)
                            {
                                // param = (from Match match in Regex.Matches(val.ToString(), "\"([^\"]*)\"") select match.ToString().Trim('"')).ToArray();
                                matches = Regex.Match(val.ToString(), tm.Regex.Regex)?.Groups?.Cast<Group>()?.Select(x => x.Value)?.Skip(1)?.ToArray();
                            }

                            var stepArgTransformationParams = tm.Method.GetParameters()?.ToList();
                            object[] param = stepArgTransformationParams?.Select((pr, j) => Convert.ChangeType(matches[j], pr.ParameterType, CultureInfo.InvariantCulture))?.ToArray();
                            val = tm.Method.Invoke(instance, param ?? new object[] { val });
                        }
                    }

                    scenarioContext.Set(Convert.ChangeType(val, p.ParameterType, CultureInfo.InvariantCulture), p.Name.ToPascalCase());
                }
                catch (Exception ex)
                {
                    Logger.Error(await ex.ToFullStringAsync().ConfigureAwait(false));
                }
            }

            // Handle BeforeAfterStep attributes
            foreach (var ba in method.CustomAttributes.Where(a => a.AttributeType == typeof(BeforeAfterStepAttribute)))
            {
                if (ba?.ConstructorArguments?.Count > 0)
                {
                    var tagValue = ba.ConstructorArguments?[beforeOrAfter == DataSourceTags.BeforeTag ? 0 : 1]; // Before = 0, After = 1
                    if (tagValue != null && !string.IsNullOrWhiteSpace(tagValue.Value.Value?.ToString()))
                    {
                        await scenarioContext.SetValue<dynamic>(beforeOrAfter + tagValue.Value.Value, parentContext: featureContext).ConfigureAwait(false);
                    }
                }
            }
        }

        private static Task RollbackChaos(SpecFlowContext specFlowContext)
        {
            if (ChaosMonkey.Enabled)
            {
                Assert.Multiple(async () =>
                {
                    if (specFlowContext.ContainsKey(ChaosMonkey.LowChaosKey))
                    {
                        foreach (var component in specFlowContext.Get<string[]>(ChaosMonkey.LowChaosKey))
                        {
                            var success = await KeyVaultHelper.EnableDisableSecretAsync(ChaosMonkey.Settings[component], true).ConfigureAwait(false);
                            specFlowContext.LogToReport($"{ChaosMonkey.LowChaosKey} - {component} - Rollback = {success}");
                            Assert.IsTrue(success);
                        }
                    }

                    if (specFlowContext.ContainsKey(ChaosMonkey.MediumChaosKey))
                    {
                        foreach (var component in specFlowContext.Get<string[]>(ChaosMonkey.MediumChaosKey))
                        {
                            // specFlowContext.LogToReport($"{ChaosMonkey.MediumChaosKey} - Rollback: {component} - {success}");
                            // Assert.IsTrue(success);
                        }
                    }

                    if (specFlowContext.ContainsKey(ChaosMonkey.HighChaosKey))
                    {
                        foreach (var component in specFlowContext.Get<string[]>(ChaosMonkey.HighChaosKey))
                        {
                            // specFlowContext.LogToReport($"{ChaosMonkey.HighChaosKey} - Rollback: {component} - {success}");
                            // Assert.IsTrue(success);
                        }
                    }
                });
            }

            return Task.CompletedTask;
        }
    }
}