﻿// <copyright file="SqlConnectionConfig.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>

namespace Bdd.Core.Hooks
{
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Data.SqlClient;
    using System.Threading.Tasks;

    using global::Bdd.Core.Utils;

    public static class SqlConnectionConfig
    {
        private static readonly NameValueCollection KeyVaultSettings = ConfigurationManager.GetSection("keyVault") as NameValueCollection ?? throw new ConfigurationErrorsException("keyVault");
        private static readonly NameValueCollection DatabaseSettings = ConfigurationManager.GetSection("database") as NameValueCollection ?? throw new ConfigurationErrorsException("database");

        public static async Task<string> AccessTokenCallback(string keyPrefix)
        {
            var authority = $"https://login.windows.net/{DatabaseSettings["AdTenant"]}";
            var resource = "https://database.windows.net/";
            var sqlClientIdKey = KeyVaultSettings.GetValue("SqlClientIdKey", keyPrefix);
            var sqlClientSecretKey = KeyVaultSettings.GetValue("SqlClientSecretKey", keyPrefix);

            if (!string.IsNullOrWhiteSpace(sqlClientIdKey) && !string.IsNullOrWhiteSpace(sqlClientSecretKey))
            {
                var sqlClientId = (await KeyVaultHelper.GetKeyVaultSecretAsync(sqlClientIdKey).ConfigureAwait(false)).Value;
                var sqlClientSecret = (await KeyVaultHelper.GetKeyVaultSecretAsync(sqlClientSecretKey).ConfigureAwait(false)).Value;
                var accessToken = await KeyVaultHelper.GetAccessTokenAsync(authority, resource, sqlClientId, sqlClientSecret).ConfigureAwait(false);
                return accessToken;
            }

            return null;
        }

        public static Task<SqlConnectionStringBuilder> ConnectionBuilderCallback(string keyPrefix)
        {
            var connBuilder = GetSqlConnectionBuilder(keyPrefix);
            return Task.FromResult(connBuilder);
        }

        private static SqlConnectionStringBuilder GetSqlConnectionBuilder(string keyPrefix)
        {
            var builder = new SqlConnectionStringBuilder();
            builder.DataSource = DatabaseSettings.GetValue("DbServer", keyPrefix);
            builder.InitialCatalog = DatabaseSettings.GetValue("DbKey", keyPrefix);
            builder.ConnectTimeout = 25;
            builder.ConnectRetryCount = 5;
            builder.ConnectRetryInterval = 5;
            builder.LoadBalanceTimeout = 600;
            builder.MaxPoolSize = 300;
            builder.MinPoolSize = 10;
            builder.MultiSubnetFailover = true;

            var uid = DatabaseSettings.GetValue("DbUser", keyPrefix);
            if (!string.IsNullOrWhiteSpace(uid))
            {
                builder.UserID = uid;
            }

            var pwd = DatabaseSettings.GetValue("DbPwd", keyPrefix);
            if (!string.IsNullOrWhiteSpace(pwd))
            {
                builder.Password = pwd;
            }

            return builder;
        }
    }
}
