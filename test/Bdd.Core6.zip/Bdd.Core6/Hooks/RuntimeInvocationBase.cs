﻿// <copyright file="RuntimeInvocationBase.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>

namespace Bdd.Core.Hooks
{
    using System.Linq;
    using System.Reflection;

    using Bdd.Core.Utils;

    using Ocaramba;

    using TechTalk.SpecFlow;

    [RuntimeInvocation]
    public class RuntimeInvocationBase
    {
        public RuntimeInvocationBase()
        {
        }

        public RuntimeInvocationBase(ScenarioContext scenarioContext, FeatureContext featureContext)
        {
            this.ScenarioContext = scenarioContext;
            this.FeatureContext = featureContext;
        }

#pragma warning disable CA2227 // Collection properties should be read only
        public ScenarioContext ScenarioContext { get; set; }

        public FeatureContext FeatureContext { get; set; }

        public DriverContext DriverContext
        {
            get
            {
                if (this.ScenarioContext.TryGetValue(nameof(this.DriverContext), out DriverContext driverContext))
                {
                    return driverContext;
                }

                return null;
            }
        }
#pragma warning restore CA2227 // Collection properties should be read only

        protected object CreateObject(string[] contextKeys)
        {
            return contextKeys.CreateObject(this.ScenarioContext, this.FeatureContext);
        }

        protected object CreateObject(string contextKey)
        {
            return contextKey.CreateObject(this.ScenarioContext, this.FeatureContext);
        }

        protected object[] CreateArray(string[] contextKeys, ParameterInfo[] parameters)
        {
            return contextKeys.CreateArray(parameters, this.ScenarioContext, this.FeatureContext).ToArray();
        }
    }
}
