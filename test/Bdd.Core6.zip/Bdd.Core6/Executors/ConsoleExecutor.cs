﻿// <copyright file="ConsoleExecutor.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>

namespace Bdd.Core.Executors
{
    using System;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;

    using Bdd.Core.Utils;

    using NLog;

    public class ConsoleExecutor : Disposable
    {
        private readonly Logger logger = LogManager.GetCurrentClassLogger();
        private Process process;

        ////private readonly int timeout = BrowserOptions.DefaultTimeout;;

        public Task<bool> RunNugetTool(string nugetName, string version = "", string toolName = null, string arguments = "", bool waitForExit = true, Action<string> onCompletion = null, Action<string> onOutputReceived = null, Action<string> onErrorReceived = null)
        {
            var toolPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), $@".nuget\packages\{nugetName}");
            var latest = string.IsNullOrWhiteSpace(version) ? Directory.EnumerateDirectories(toolPath).OrderByDescending(x => x)?.FirstOrDefault() : Directory.EnumerateDirectories(toolPath).SingleOrDefault(x => x.Equals(version, StringComparison.OrdinalIgnoreCase));
            var tool = Path.Combine(latest, $@"tools\{toolName ?? nugetName}.exe");
            return this.Run(tool, arguments, waitForExit, onCompletion, onOutputReceived, onErrorReceived);
        }

        public async Task<bool> Run(string exePath, string arguments, bool waitForExit = true, Action<string> onCompletion = null, Action<string> onOutputReceived = null, Action<string> onErrorReceived = null, string workingDirectory = null, bool createNoWindow = true)
        {
            var error = false;
            var exitCode = 0;
            this.process = new Process { EnableRaisingEvents = true };
            this.process.Disposed += (object sender, EventArgs e) =>
            {
                this.logger.Trace($"{exePath} disposed!");
            };

            DataReceivedEventHandler outputHandler = null;
            DataReceivedEventHandler errorHandler = null;

            try
            {
                this.process.StartInfo = new ProcessStartInfo
                {
                    FileName = exePath,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = createNoWindow,
                    WindowStyle = ProcessWindowStyle.Hidden,
                    Arguments = arguments,
#pragma warning disable S3358 // Ternary operators should not be nested
                    WorkingDirectory = string.IsNullOrEmpty(workingDirectory) ? (GenericExtensions.TestAssembly != null ? Path.GetDirectoryName(new Uri(GenericExtensions.TestAssembly.CodeBase).LocalPath) : string.Empty.GetFullPath()) : workingDirectory,
#pragma warning restore S3358 // Ternary operators should not be nested
                };

                outputHandler = (sender, args) =>
                {
                    var output = args?.Data;
                    if (!string.IsNullOrEmpty(output))
                    {
                        if (output.StartsWith("Warn", StringComparison.OrdinalIgnoreCase))
                        {
                            this.logger.Warn(output);
                        }
                        else if (output.Contains("Exception:"))
                        {
                            this.logger.Error(output);
                        }
                        else
                        {
                            this.logger.Info(output);
                        }

                        onOutputReceived?.Invoke(output);
                    }
                };

                errorHandler = (sender, args) =>
                {
                    var err = args?.Data;
                    if (!string.IsNullOrEmpty(err))
                    {
                        if (err.StartsWith("Warn", StringComparison.OrdinalIgnoreCase))
                        {
                            this.logger.Warn(err);
                        }
                        else
                        {
                            this.logger.Error(err);
                        }

                        error = true;
                        onErrorReceived?.Invoke(err);
                    }
                };

                this.process.OutputDataReceived += outputHandler;
                this.process.ErrorDataReceived += errorHandler;

                this.logger.Warn($"{Environment.NewLine}EXECUTING ({nameof(waitForExit)} = {waitForExit}): {exePath} {arguments}");

                this.process.Start();
                this.process.BeginOutputReadLine();
                this.process.BeginErrorReadLine();

                if (waitForExit)
                {
                    this.process.WaitForExit();
                    onCompletion?.Invoke(this.process.ExitCode.ToString(CultureInfo.InvariantCulture));

                    ////if (process.WaitForExit(this.timeout))
                    ////{
                    ////    this.logger.Debug($"{exePath} exited with code: {process.ExitCode}");
                    ////    executeOnOutput?.Invoke(process.ExitCode.ToString(CultureInfo.InvariantCulture));
                    ////}
                    ////else
                    ////{
                    ////    this.logger.Warn($"{exePath} timed out!");
                    ////}
                }
            }
            catch (Exception ex)
            {
                this.logger.Error(await ex.ToFullStringAsync().ConfigureAwait(false));
                error = true;
            }
            finally
            {
                ////if (waitForExit)
                ////{
                ////    process.OutputDataReceived -= outputHandler;
                ////    process.ErrorDataReceived -= errorHandler;
                ////    exitCode = process.ExitCode;
                ////    process.Close();
                ////    process.Dispose();
                ////}
            }

            if (error)
            {
                this.logger.Debug($"Erred: {error}");
            }

            return exitCode == 0; // && !error
        }

        protected override void DisposeManagedResources()
        {
            if (!this.process.HasExited)
            {
                this.process.Kill();
            }

            this.process = null;
        }
    }
}
