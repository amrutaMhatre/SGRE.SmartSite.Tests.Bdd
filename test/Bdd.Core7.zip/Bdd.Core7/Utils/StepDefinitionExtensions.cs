﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="PageExtensions.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.Utils
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using global::Bdd.Core.Executors.UI.Common;
    using global::Bdd.Core.StepDefinitions;
    using Objectivity.Test.Automation.Common;

    /// <summary>
    /// Extensions
    /// </summary>
    public static class StepDefinitionExtensions
    {
        private static readonly ConcurrentDictionary<string, dynamic> StepDefInstances = new ConcurrentDictionary<string, dynamic>();

        private static IEnumerable<Type> stepDefTypes = GenericExtensions.TestAssembly.GetExportedTypes()?.Where(t => typeof(StepDefinitionBase).IsAssignableFrom(t) && t.IsClass && !t.IsAbstract && !t.Name.Equals(nameof(ProjectPageBase), StringComparison.Ordinal));

        public static T GetStepDef<T>(this StepDefinitionBase stepDefinition, bool createNew = false)
            where T : StepDefinitionBase
        {
            var instance = stepDefinition.DriverContext.GetStepDef<T>(createNew);
            return instance;
        }

        private static T GetStepDef<T>(this DriverContext driverContext, bool createNew = false)
            where T : StepDefinitionBase
        {
            var stepDefType = stepDefTypes.SingleOrDefault(t => typeof(T).IsAssignableFrom(t));
            if (createNew)
            {
                return Activator.CreateInstance(stepDefType) as T;
            }
            else
            {
                // TODO: What if Scenario-Outlines are executed in parallel (and one finishes before the other)?
                // Any way to have the Scenario-Outline arguments also part of the key to maintain the uniqueness?
                var key = driverContext.TestTitle;
                Debug.Assert(!string.IsNullOrWhiteSpace(key), "GetStepDef<Page> 'key' is empty!");
                var instance = StepDefInstances.GetOrAdd(stepDefType.Name + "." + key ?? string.Empty, Activator.CreateInstance(stepDefType) as T);
                return instance;
            }
        }

        public static void ClearStepDefs(this DriverContext driverContext)
        {
            var key = driverContext.TestTitle;
            foreach (var instance in StepDefInstances.Keys.Where(k => k.EndsWith(key, StringComparison.Ordinal)))
            {
                if (StepDefInstances.TryRemove(instance, out var value))
                {
                    ////(value as ProjectPageBase).DriverContext = null;
                    value = null;
                }
            }
        }
    }
}