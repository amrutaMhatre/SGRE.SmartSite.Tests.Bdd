﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ExtentManager.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.Utils
{
    using System;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Globalization;
    using System.IO;
    using System.IO.Compression;
    using System.Linq;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Threading;
    using System.Threading.Tasks;

    using AventStack.ExtentReports;
    using AventStack.ExtentReports.Gherkin.Model;
    using AventStack.ExtentReports.Reporter;
    using AventStack.ExtentReports.Reporter.Configuration;

    using NLog;

    using NUnit.Framework;

    using TechTalk.SpecFlow;

    // https://github.com/anshooarora/extentreports-csharp/tree/master/ExtentReports/ExtentReports.Tests/Parallel.
    public static class ExtentManager
    {
        private static readonly SemaphoreSlim Lock = new SemaphoreSlim(1, 1);
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        private static readonly NameValueCollection ReportSettings = ConfigurationManager.GetSection("reporting") as NameValueCollection;
        private static readonly bool Enabled = ReportSettings != null && bool.TryParse(ReportSettings["Enabled"], out var enabled) && enabled;
        private static readonly bool DarkTheme = Enabled && bool.TryParse(ReportSettings["DarkTheme"], out var darkTheme) && darkTheme;
        private static readonly Lazy<ExtentReports> Lazy = new Lazy<ExtentReports>(() => new ExtentReports());

        [ThreadStatic]
        private static ExtentTest featureNode;

        [ThreadStatic]
        private static ExtentTest scenarioNode;

        [ThreadStatic]
        private static ExtentTest stepNode;

        public static ExtentReports Instance => Lazy.Value;

        public static string ReportPath { get; set; }

        public static async Task Initialize()
        {
            try
            {
                if (Enabled)
                {
                    var testProject = (ConfigurationManager.AppSettings["TestProjectName"] ?? Assembly.GetCallingAssembly().FullName) + " - " + ConfigurationManager.AppSettings["Env"] ?? string.Empty;
                    var style = "body {font-family: 'Segoe UI';}";

                    await Lock.WaitAsync().ConfigureAwait(false);
                    ReportPath = Path.Combine((ReportSettings["Path"] ?? @"TestOutput\Reports").GetFullPath(false), testProject, DateTime.Now.ToString("dd_MMM_yy_hh_mm_ss_tt", CultureInfo.CurrentCulture));
                    if (!Directory.Exists(ReportPath))
                    {
                        Directory.CreateDirectory(ReportPath);
                    }

                    Lock.Release();

                    var htmlReporter = new ExtentHtmlReporter(ReportPath + "/");
                    htmlReporter.Config.Theme = DarkTheme ? Theme.Dark : Theme.Standard;
                    htmlReporter.Config.CSS = style;
                    htmlReporter.Config.EnableTimeline = true;
                    htmlReporter.Config.DocumentTitle = testProject;
                    htmlReporter.Config.ReportName = testProject.ToUpperInvariant();

                    Instance.AddSystemInfo("Host", Environment.MachineName);
                    Instance.AddSystemInfo("User", Environment.UserName);
                    Instance.AnalysisStrategy = AnalysisStrategy.BDD;
                    Instance.AttachReporter(htmlReporter);
                }
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
            {
                Logger.Warn(ex);
            }
#pragma warning restore CA1031 // Do not catch general exception types
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static void Flush()
        {
            try
            {
                if (Enabled)
                {
                    Instance.Flush();
                    //// await ExtentManager.AttachReportAsync().ConfigureAwait(false);
                }
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
            {
                Logger.Warn(ex);
            }
#pragma warning restore CA1031 // Do not catch general exception types
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static ExtentTest CreateFeatureNode(FeatureContext featureContext)
        {
            featureNode = Instance.CreateTest<Feature>(featureContext.FeatureInfo.Title, featureContext.FeatureInfo.Description);
            return featureNode;
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static ExtentTest CreateScenarioNode(ScenarioContext scenarioContext)
        {
            scenarioNode = featureNode.CreateNode<Scenario>(scenarioContext.ScenarioInfo.Title, scenarioContext.ScenarioInfo.Description);
            return scenarioNode;
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static ExtentTest CreateStepNode(ScenarioContext scenarioContext)
        {
            var stepContext = scenarioContext.StepContext;
            var keyword = stepContext.StepInfo.StepInstance.Keyword;
            var text = stepContext.StepInfo.Text;
            stepNode = scenarioNode.CreateNode(new GherkinKeyword(keyword.TrimEnd()), keyword + text);
            return stepNode;
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static ExtentTest GetFeatureNode()
        {
            return featureNode;
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static ExtentTest GetScenarioNode()
        {
            return scenarioNode;
        }

        [MethodImpl(MethodImplOptions.Synchronized)]
        public static ExtentTest GetStepNode()
        {
            return stepNode;
        }

        public static async Task AttachReportAsync()
        {
            var report = @"ExtentReport.zip".GetFullPath();
            if (File.Exists(report))
            {
                File.Delete(report);
            }

            var counter = 0;
            while (counter < 10 && !Directory.EnumerateFiles(ReportPath).Any())
            {
                await Task.Delay(1000).ConfigureAwait(false);
                counter++;
            }

            ZipFile.CreateFromDirectory(ReportPath, report);
            TestContext.AddTestAttachment(report);
        }
    }
}
