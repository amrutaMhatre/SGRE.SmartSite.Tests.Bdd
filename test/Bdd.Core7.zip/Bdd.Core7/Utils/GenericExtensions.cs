﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="GenericExtensions.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.Utils
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.ComponentModel;
    using System.Configuration;
    using System.Data;
    using System.Diagnostics;
    using System.Drawing;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Reflection;
    using System.Resources;
    using System.Runtime.CompilerServices;
    using System.Security.Principal;
    using System.Text;
    using System.Threading.Tasks;

    using AdysTech.CredentialManager;

    using Bdd.Core.Docs;
    using Bdd.Core.Entities;

    using Bogus;

    using Flurl.Http;

    using Humanizer;

    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using Newtonsoft.Json.Serialization;

    using NLog;

    public static class GenericExtensions
    {
        public const string Delimiter = "-";

        public static readonly string TestProject = (ConfigurationManager.AppSettings["TestProjectName"] ?? Assembly.GetCallingAssembly().FullName) ?? "Bdd.Core";

        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        private static IDictionary<Type, MethodInfo[]> typesWithMethods;

        private static Assembly testAssembly;

        private static string hostDetails;

        private static Faker faker = new Faker("en");

        public static string HostDetails
        {
            get
            {
                if (string.IsNullOrEmpty(hostDetails))
                {
                    var user = string.IsNullOrWhiteSpace(WindowsIdentity.GetCurrent()?.Name) ? WindowsIdentity.GetCurrent()?.Name : $@"{Environment.UserDomainName}\{Environment.UserName}";
                    var hostName = Dns.GetHostName(); // Environment.MachineName; // System.Windows.Forms.SystemInformation.ComputerName
                    hostDetails = $"{hostName} @ {user}";
                }

                return hostDetails;
            }
        }

        public static Assembly TestAssembly
        {
            get
            {
                if (testAssembly == null && !string.IsNullOrEmpty(TestAssemblyName))
                {
                    testAssembly = Assembly.Load(TestAssemblyName);
                }

                return testAssembly;
            }
        }

        public static string TestAssemblyName
        {
            get
            {
                if (ConfigurationManager.AppSettings.AllKeys.Contains("TestProjectName"))
                {
                    return ConfigurationManager.AppSettings["TestProjectName"];
                }

                return string.Empty;
            }
        }

        public static string DefaultKeyPrefix => ConfigurationManager.AppSettings[nameof(DefaultKeyPrefix)];

        public static string AsString(this IList<string> list, string separator = ", ")
        {
            return string.Join(separator, list ?? new[] { string.Empty });
        }

        public static T ChangeType<T>(this string content)
        {
            return (T)Convert.ChangeType(content, typeof(T), CultureInfo.InvariantCulture);
        }

        public static DataTable ConvertToDatatable<T>(this IList<T> data)
        {
            var props =
                    TypeDescriptor.GetProperties(typeof(T));
            var table = new DataTable();
            for (var i = 0; i < props.Count; i++)
            {
                var prop = props[i];
                table.Columns.Add(prop.Name, prop.PropertyType);
            }

            var values = new object[props.Count];
            foreach (var item in data)
            {
                for (var i = 0; i < values.Length; i++)
                {
                    values[i] = props[i].GetValue(item);
                }

                table.Rows.Add(values);
            }

            return table;
        }

        public static string Fake(this string propertyName)
        {
            if (typesWithMethods == null)
            {
                typesWithMethods = faker.GetType()?
                    .GetProperties(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly).Where(p => typeof(IHasRandomizer).IsAssignableFrom(p.PropertyType))
                    .ToDictionary(x => x.PropertyType, x => x.PropertyType.GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly));

                if (Debugger.IsAttached)
                {
                    foreach (var item in typesWithMethods)
                    {
                        Logger.Debug($"{item.Key.Name.ToUpperInvariant()}:\n{string.Join("\n", item.Value.Select(m => m.Name))}\n");
                    }
                }
            }

            var typeAndMethods = typesWithMethods?.FirstOrDefault(x => x.Value.Any(m => m.Name.Equals(propertyName, StringComparison.OrdinalIgnoreCase)));
            var prop = faker.GetType().GetProperty(typeAndMethods?.Key.Name == "PhoneNumbers" ? "Phone" : typeAndMethods?.Key.Name);
            var method = prop?.PropertyType.GetMethod(propertyName);
            var args = new List<object>();
            var parameters = method?.GetParameters();
            if (parameters != null)
            {
                args.AddRange(parameters.Select(par => par.HasDefaultValue ? par.DefaultValue : null));
            }

            var fakeText = method?.Invoke(prop.GetValue(faker), args.ToArray())?.ToString();
            return fakeText;
        }

        public static T FromJson<T>(this string source, JsonSerializerSettings jsonSerializerSettings = null)
        {
            return !string.IsNullOrWhiteSpace(source)
                ? (jsonSerializerSettings == null
                    ? JsonConvert.DeserializeObject<T>(source)
                    : JsonConvert.DeserializeObject<T>(source, jsonSerializerSettings))
                : default(T);
        }

        public static Assembly GetBaseTypeAssembly(this Type t, string baseTypeName)
        {
            var cur = t.BaseType;
            while (cur != null)
            {
                if (cur.Name.Equals(baseTypeName, StringComparison.Ordinal))
                {
                    return cur.Assembly;
                }

                cur = cur.BaseType;
            }

            return t.Assembly;
        }

        public static string GetContent(this string expectedResultOrFilePath, bool returnNullIfNotFound = false, params object[] args)
        {
            var value = File.Exists(expectedResultOrFilePath) ? File.ReadAllText(expectedResultOrFilePath) : (returnNullIfNotFound ? null : expectedResultOrFilePath);
            if (value == null)
            {
                return null;
            }

            return args == null || args.Length == 0 ? value : string.Format(CultureInfo.InvariantCulture, value, args);
        }

        public static IEnumerable<string> GetContentAsRows(this string expectedResultOrFilePath)
        {
            var value = File.Exists(expectedResultOrFilePath) ? File.ReadAllLines(expectedResultOrFilePath) : new[] { expectedResultOrFilePath };
            return value;
        }

        public static string GetFullPath(this string file, bool callingAssemblyPath = true)
        {
            try
            {
                var value = Path.IsPathRooted(file) ? file : Path.Combine(Path.GetDirectoryName(new Uri(TestAssembly?.CodeBase ?? (callingAssemblyPath ? Assembly.GetCallingAssembly() : Assembly.GetExecutingAssembly()).CodeBase).LocalPath), file);
                return value;
            }
            catch
            {
                // Do nothing
            }

            return file;
        }

        // Credit: https://stackoverflow.com/a/32113484
        public static string GetRelativePath(this string fromPath, string toPath, bool callingAssemblyPath = true)
        {
            if (!Path.IsPathRooted(fromPath))
            {
                fromPath = fromPath.GetFullPath(callingAssemblyPath);
            }

            if (!Path.IsPathRooted(toPath))
            {
                toPath = toPath.GetFullPath(callingAssemblyPath);
            }

            Uri fromUri = new Uri(AppendDirectorySeparatorChar(fromPath));
            Uri toUri = new Uri(AppendDirectorySeparatorChar(toPath));

            if (fromUri.Scheme != toUri.Scheme)
            {
                return toPath;
            }

            Uri relativeUri = fromUri.MakeRelativeUri(toUri);
            string relativePath = Uri.UnescapeDataString(relativeUri.ToString());

            if (string.Equals(toUri.Scheme, Uri.UriSchemeFile, StringComparison.OrdinalIgnoreCase))
            {
                relativePath = relativePath.Replace(Path.AltDirectorySeparatorChar, Path.DirectorySeparatorChar);
            }

            return relativePath;
        }

        public static string AppendDirectorySeparatorChar(this string path)
        {
            // Append a slash only if the path is a directory and does not have a slash.
            if (!Path.HasExtension(path) && !path.EndsWith(Path.DirectorySeparatorChar.ToString(CultureInfo.InvariantCulture), StringComparison.OrdinalIgnoreCase))
            {
                return path + Path.DirectorySeparatorChar;
            }

            return path;
        }

        public static Type GetItemType<T>(this IEnumerable<T> enumerable)
        {
            return typeof(T);
        }

        public static async Task<T> ReadAsJsonAsync<T>(this HttpContent content)
        {
            var dataAsString = await content.ReadAsStringAsync().ConfigureAwait(false);
            return JsonConvert.DeserializeObject<T>(dataAsString);
        }

        public static IDictionary<string, object> ToDictionary<T>(this T keyValuePairs)
            where T : new()
        {
            var json = JsonConvert.SerializeObject(keyValuePairs, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Include });
            var result = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
            return result;
        }

        public static IDictionary<string, string> ToStringDictionary(this IDictionary<string, object> dictionary)
        {
            var result = dictionary.ToDictionary(x => x.Key, x => x.Value?.ToString());
            return result;
        }

        public static IList<ExpandoObject> ToExpandoList(this IEnumerable<dynamic> enumerable)
        {
            var result = enumerable.ToDictionaryList().Select(x => x.ToExpando()).ToList();
            return result;
        }

        public static IList<IDictionary<string, object>> ToDictionaryList(this IEnumerable<dynamic> enumerable)
        {
            var result = enumerable.Select(x => (IDictionary<string, object>)x).ToList();
            return result;
        }

        public static dynamic ToDynamic(this IEnumerable enumerable)
        {
            var result = enumerable.ToObject<dynamic>();
            return result;
        }

        public static ExpandoObject ToExpando(this IEnumerable enumerable)
        {
            var result = enumerable.ToObject<ExpandoObject>();
            return result;
        }

        public static IEnumerable<dynamic> ToExpandoList(this DataRow[] dataRows, bool removeSpacesInColumnNames = false, Dictionary<string, string> columnMappings = null)
        {
            var result = dataRows.Select(x =>
                x.ItemArray.Select((a, i) =>
                {
                    var col = x.Table.Columns[i].ColumnName;
                    return new
                    {
                        Key = columnMappings?.ContainsKey(col) == true ? columnMappings[col] : (removeSpacesInColumnNames ? col.Replace(" ", string.Empty) : col),
                        Value = a,
                    };
                }).ToDictionary(item => item.Key, item => item.Value).ToObject<dynamic>());
            return result;
        }

        public static string ToJson(this object source, Formatting formatting = Formatting.Indented, JsonSerializerSettings jsonSerializerSettings = null, bool camelizePropertyNames = false)
        {
            if (jsonSerializerSettings == null)
            {
                jsonSerializerSettings = new JsonSerializerSettings
                {
                    Error = (o, e) =>
                    {
                        var currentError = e.ErrorContext.Error.Message;
                        Logger.Warn(currentError);
                        e.ErrorContext.Handled = true;
                    },
                    ContractResolver = camelizePropertyNames ? new CamelCasePropertyNamesContractResolver() : new DefaultContractResolver(),
                };
            }

            return source != null ? JsonConvert.SerializeObject(source, formatting, jsonSerializerSettings) : string.Empty;
        }

        public static IEnumerable<T> ToList<T>(this DataTable dataTable, bool removeSpacesInColumnNames = false, Dictionary<string, string> columnMappings = null)
        {
            var result = dataTable.Select().ToList<T>(removeSpacesInColumnNames, columnMappings);
            return result;
        }

        public static IEnumerable<T> ToList<T>(this DataRow[] dataRows, bool removeSpacesInColumnNames = false, Dictionary<string, string> columnMappings = null)
        {
            var result = dataRows.ToExpandoList(removeSpacesInColumnNames, columnMappings).ToList();
            return result.ToList<T>();
        }

        public static IEnumerable<T> ToList<T>(this List<dynamic> list)
        {
            var result = list.ConvertAll(o => ((JObject)o).ToObject<T>());
            return result;
        }

        public static List<T> ToList<T>(this IEnumerable<ExpandoObject> list)
            where T : new()
        {
            var result = list.ToList().ToList<T>();
            return result;
        }

        public static List<T> ToList<T>(this List<ExpandoObject> list)
            where T : new()
        {
            var result = list.ConvertAll(o => o.ToObject<T>());
            return result;
        }

        public static T ToObject<T>(this object instance)
            where T : new()
        {
            var json = JsonConvert.SerializeObject(instance, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Include });
            var result = JsonConvert.DeserializeObject<T>(json);
            return result;
        }

        public static StringContent ToStringContent(this object source, JsonSerializerSettings jsonSerializerSettings = null, bool camelizePropertyNames = false)
        {
            if (jsonSerializerSettings == null)
            {
                jsonSerializerSettings = new JsonSerializerSettings
                {
                    DateTimeZoneHandling = DateTimeZoneHandling.Unspecified,
                    ContractResolver = camelizePropertyNames ? new CamelCasePropertyNamesContractResolver() : new DefaultContractResolver(),
                };
            }

            var json = source.ToJson(jsonSerializerSettings: jsonSerializerSettings);
            return new StringContent(json, Encoding.UTF8, HttpHeaders.JsonContentKey);
        }

        public static StringContent ToXmlStringContent(this object source)
        {
            return new StringContent(source.ToString(), Encoding.UTF8, HttpHeaders.XmlContentKey);
        }

        public static Dictionary<string, string> ToStringDictionary(this JObject jobject)
        {
            var children = jobject?.Children().SkipWhile(x => (x as JProperty)?.Name?.StartsWith("@odata", StringComparison.OrdinalIgnoreCase) == true);
            return children?.ToDictionary(
                x => ((JProperty)x).Name,
                x => ((JProperty)x).Value is JArray
                    ? string.Join(",", (JArray)((JProperty)x).Value)
                    : (((JProperty)x).Value as JValue)?.ToString(CultureInfo.InvariantCulture));
        }

        public static Guid ToGuid(this string data)
        {
            var guid = GuidUtility.Create(GuidUtility.IsoOidNamespace, data);
            return guid;
        }

        public static string Format(this string route, params object[] args)
        {
            return string.Format(CultureInfo.InvariantCulture, route, args);
        }

        public static int GetEntityTypeIdForCurrentEntity(this string entityType)
        {
            Dictionary<string, int> entityInfo = new Dictionary<string, int>() { { "Manufacturer", 3 }, { "Dealer", 4 }, { "Branch", 5 }, { "Company", 6 }, { "Site", 7 } };
            return entityInfo[entityType];
        }

        public static bool IsInDescendingOrder<T>(this IList<T> list)
        {
            return list.SequenceEqual(list.OrderByDescending(item => item));
        }

        public static string ToPascalCase(this string text)
        {
            return text.Dehumanize().Pascalize();
        }

        public static string ToCamelCase(this string text)
        {
            return text.Dehumanize().Camelize();
        }

        public static string GetLocalizedString(this string text, string language)
        {
            string modifiedString;
            string extraString;
            if (text.Contains('_'))
            {
                modifiedString = text.Split('_')[1];
                extraString = text.Split('_')[0];
            }
            else
            {
                modifiedString = text;
                extraString = string.Empty;
            }

            if (!string.IsNullOrEmpty(extraString))
            {
                if (!extraString.StartsWith("fr", StringComparison.InvariantCulture) || !extraString.Split('_')[0].StartsWith("es", StringComparison.InvariantCulture))
                {
                    if (extraString.Contains(' '))
                    {
                        extraString = extraString.Split(' ')[0];
                    }
                    else
                    {
                        extraString = string.Empty;
                    }
                }
            }

            if (language.Contains("French"))
            {
                return $"{extraString} fr-CA_{modifiedString}".TrimStart(' ');
            }
            else if (language.Contains("Spanish"))
            {
                return $"{extraString} es-MX_{modifiedString}".TrimStart(' ');
            }
            else
            {
                return text;
            }
        }

        public static string GetResourceValue(this string resourceKey, string resourceFileName = "Resources")
        {
            var testAssembly = TestAssembly;
            var resourceManager = new ResourceManager($"{TestAssemblyName}.Properties.{resourceFileName}", testAssembly);
            string value = resourceManager.GetString(resourceKey, CultureInfo.InvariantCulture);
            return !string.IsNullOrEmpty(value) ? value : null;
        }

        public static Color ToColor(this string htmlColor)
        {
            return ColorTranslator.FromHtml(htmlColor.PadLeft(7, '#'));
        }

        public static int ToColorRgb(this string htmlColor)
        {
            return ColorTranslator.ToOle(htmlColor.ToColor());
        }

        public static string GetFullTestPlanName(this TestCase testCase)
        {
            return testCase.VstsTestPlanId + ":" + testCase.VstsTestPlanTitle?.Replace("-", string.Empty)?.Replace("Test Plan", string.Empty)?.Trim();
        }

        public static string ReplaceSuffixes(this string phrase, IEnumerable<string> suffixes, string replacement = "*")
        {
            foreach (var suffix in suffixes)
            {
                phrase = phrase.Replace(suffix, replacement);
            }

            return phrase;
        }

        public static bool ContainsIgnoreCase(this string item, string subString)
        {
            return item.IndexOf(subString, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        public static bool IsAsyncMethod(this MethodInfo method)
        {
            var asyncStateAttribute = (AsyncStateMachineAttribute)method.GetCustomAttribute(typeof(AsyncStateMachineAttribute));
            return asyncStateAttribute != null;
        }

        public static bool IsTask(this MethodInfo method)
        {
            return method.ReturnType.GetMethod("GetAwaiter") != null; //// .GenericTypeArguments(), .GetGenericTypeDefinition()
        }

        public static bool HasConstructorWithParameterType<T>(this Type type)
        {
            return type.GetConstructor(new[] { typeof(T) }) != null;
        }

        public static string[] SplitOrDefault(this string input, char delimiter = ':', StringSplitOptions splitOptions = StringSplitOptions.None)
        {
            if (!input.Contains(delimiter))
            {
                input += delimiter;
            }

            var split = input.Split(new[] { delimiter }, splitOptions);
            return split;
        }

        public static T GetOrAdd<T>(this HashSet<T> list, T item)
        {
            if (list.Add(item))
            {
                return item;
            }
            else
            {
                return list.SingleOrDefault(x => x.Equals(item));
            }
        }

        public static bool EqualsIgnoreCase(this string string1, string string2)
        {
            return string1?.Equals(string2, StringComparison.OrdinalIgnoreCase) == true;
        }

        public static bool StartsWithIgnoreCase(this string string1, string string2)
        {
            return string1?.StartsWith(string2, StringComparison.OrdinalIgnoreCase) == true;
        }

        public static bool EndsWithIgnoreCase(this string string1, string string2)
        {
            return string1?.EndsWith(string2, StringComparison.OrdinalIgnoreCase) == true;
        }

        public static int ToSmallInt(this object input)
        {
            return Convert.ToInt16(input, CultureInfo.InvariantCulture);
        }

        public static int ToInt(this object input)
        {
            return Convert.ToInt32(input, CultureInfo.InvariantCulture);
        }

        public static long ToLong(this object input)
        {
            return Convert.ToInt64(input, CultureInfo.InvariantCulture);
        }

        public static double ToDouble(this object input)
        {
            return Convert.ToDouble(input, CultureInfo.InvariantCulture);
        }

        public static decimal ToDecimal(this object input)
        {
            return Convert.ToDecimal(input, CultureInfo.InvariantCulture);
        }

        public static DateTime ToDateTime(this object input)
        {
            return Convert.ToDateTime(input, CultureInfo.InvariantCulture);
        }

        public static string HtmlEscape(this string html)
        {
            // HttpUtility.HtmlEncode(string.Format(CultureInfo.InvariantCulture, StepHtml, step.Keyword, step.Name));
            return html.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
        }

        public static async Task<string> ToFullStringAsync(this Exception e, [CallerMemberName] string member = "", [CallerLineNumber] int line = 0)
        {
            if (e != null)
            {
                var message = e.Message;
                var fex = e as FlurlHttpException;
                if (fex != null)
                {
                    try
                    {
                        var vex = await fex.GetResponseJsonAsync<JObject>().ConfigureAwait(false);
                        message = vex?.SelectToken("..message")?.Value<string>() ?? (vex?.SelectToken("..Message")?.Value<string>() ?? e.Message);
                    }
                    catch
                    {
                        message = fex.Message;
                    }
                }

                var lines = string.Join(" > ", new StackTrace(e, true)?.GetFrames()?.Where(x => x.GetFileLineNumber() > 0)?.Select(x => $"{x.GetMethod()}#{x.GetFileLineNumber()}"));
                return $"{message} ({(string.IsNullOrWhiteSpace(lines) ? (member + "#" + line) : (member + "#" + line + " - " + lines))})";
            }

            return string.Empty;
        }

        public static string GetValue(this NameValueCollection settings, string key, bool throwIfNotFound = true, string configSectionName = "vstsDocTarget")
        {
            return string.IsNullOrWhiteSpace(settings[key]) || settings[key].StartsWith("{", StringComparison.Ordinal)
                ? (throwIfNotFound ? throw new ConfigurationErrorsException($"Invalid '{key}' under <{configSectionName}> config-section!") : string.Empty)
                : settings[key];
        }

        public static string GetValue(this NameValueCollection settings, string key, string prefix, bool windowsCredsFallback = false)
        {
            var keyWithPrefix = key.WithKeyPrefix(prefix);
            if (settings.AllKeys.Contains(keyWithPrefix))
            {
                key = keyWithPrefix;
            }

            var value = settings[key];
            if (windowsCredsFallback)
            {
                try
                {
                    key = $"{TestProject}{Delimiter}{ConfigurationManager.AppSettings["Env"]}{Delimiter}{key}";
                    var credsValue = CredentialManager.GetCredentials(key)?.Password;
                    if (!string.IsNullOrEmpty(credsValue))
                    {
                        value = credsValue;
                    }
                }
                catch
                {
                    // Logger.Warn("GetValue: " + ex.ToFullStringAsync().GetAwaiter().GetResult());
                }

                // Fallback to KeyVault
                try
                {
                    if (string.IsNullOrWhiteSpace(value))
                    {
                        // KeyVault doesn't support special-chars (other than hyphen) in the names
                        var keyVaultSecretKey = key.Replace("@", Delimiter).Replace("_", Delimiter).Replace(".", Delimiter);
                        value = KeyVaultHelper.GetKeyVaultSecretAsync(keyVaultSecretKey).GetAwaiter().GetResult().Value;
                    }
                }
                catch (Exception ex)
                {
                    Logger.Warn($"GetValue: {ex.ToFullStringAsync().GetAwaiter().GetResult()}");
                }
            }

            return value;
        }

        public static string WithKeyPrefix(this string key, string prefix)
        {
            if (prefix == null)
            {
                prefix = DefaultKeyPrefix;
            }

            return $"{prefix}{key}";
        }

        public static List<List<T>> ChunkBy<T>(this IEnumerable<T> source, int chunkSize)
        {
            return source
            .Select((x, i) => new { Index = i, Value = x })
            .GroupBy(x => x.Index / chunkSize)
            .Select(x => x.Select(v => v.Value).ToList())
            .ToList();
        }

        // Credit: https://stackoverflow.com/a/39679855
        public static async Task<object> InvokeAsync(this MethodInfo methodInfo, object o, params object[] parameters)
        {
            var task = (Task)methodInfo.Invoke(o, parameters);
            await task.ConfigureAwait(false);
            var resultProperty = task.GetType().GetProperty("Result");
            return resultProperty.GetValue(task);
        }
    }
}