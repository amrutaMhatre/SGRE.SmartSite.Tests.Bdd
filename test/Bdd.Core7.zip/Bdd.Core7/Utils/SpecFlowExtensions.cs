﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SpecFlowExtensions.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.Utils
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Text.RegularExpressions;
    using System.Threading.Tasks;

    using AdysTech.CredentialManager;

    using Bdd.Core.DataSources;
    using Bdd.Core.Docs;
    using Bdd.Core.Entities;
    using Bdd.Core.Entities.Tags;
    using Bdd.Core.Hooks;

    using Newtonsoft.Json;

    using NLog;

    using Ocaramba;

    using TechTalk.SpecFlow;

    public static class SpecFlowExtensions
    {
        public static readonly Dictionary<string, Type> DataSources = new Dictionary<string, Type>(StringComparer.OrdinalIgnoreCase)
        {
            { ".sql", typeof(SqlDataSource) },
            { ".json", typeof(JsonDataSource) },
            { ".xml", typeof(XmlDataSource) },
            { ".csv", typeof(CsvDataSource) },
            { ".xlsx", typeof(ExcelDataSource) },
            { ".xls", typeof(ExcelDataSource) },
            { ".txt", typeof(TextDataSource) },
            { ".yml", typeof(YamlDataSource) },
            { ".yaml", typeof(YamlDataSource) },
        };

        private const char TagDelimiter = '=';

        private const string AnySpaces = @"\s*";

        private const string ScenarioPrefix = "Scenario:";

        private const string FeaturePrefix = "Feature:";

        private const string ScenarioOutlinePrefix = "Scenario Outline:";

        private static readonly ConcurrentDictionary<string, dynamic> Inputs = new ConcurrentDictionary<string, dynamic>();
        private static readonly ConcurrentDictionary<string, dynamic> CredsList = new ConcurrentDictionary<string, dynamic>();
        private static readonly ConcurrentDictionary<string, string> Creds = new ConcurrentDictionary<string, string>();

        private static readonly List<string> RegexSpecialChars = new List<string> { @"\", "*", "+", "?", "|", "{", "[", "(", ")", "^", "$", ".", "#" };

        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        public static IDataSource GetDataSource(this ScenarioContext scenarioContext, FeatureContext parentContext, string tag)
        {
            return GetDataSourceInternal(scenarioContext, parentContext, tag);
        }

        public static IDataSource GetDataSource(this FeatureContext parentContext, string tag)
        {
            return GetDataSourceInternal(null, parentContext, tag);
        }

        public static Task<bool> SetValue<T>(this FeatureContext context, string tag, string setterKey = null)
        {
            var dataSource = GetDataSource(context, tag);
            return context.SetInternal<T>(dataSource, tag, setterKey);
        }

        public static Task<bool> SetValue<T>(this ScenarioContext context, string tag, string setterKey = null, FeatureContext parentContext = null)
        {
            var dataSource = GetDataSource(context, parentContext, tag);
            return context.SetInternal<T>(dataSource, tag, setterKey);
        }

        public static ExpandoObject CreateObject(this string contextKey, ScenarioContext scenarioContext, FeatureContext featureContext)
        {
            if (string.IsNullOrWhiteSpace(contextKey))
            {
                return null;
            }

            var json = $"{{{GetJsonValue<dynamic>(contextKey, scenarioContext, featureContext)}}}";
            var obj = JsonConvert.DeserializeObject<ExpandoObject>(json);
            return obj;
        }

        public static ExpandoObject CreateObject(this string[] contextKeys, ScenarioContext scenarioContext, FeatureContext featureContext)
        {
            if (contextKeys == null || contextKeys.Length == 0)
            {
                return null;
            }

            // TODO: Handle multiple types or just handle all strings in SQL?
            var json = $"{{{string.Join(",", contextKeys.Select(contextKey => GetJsonValue<dynamic>(contextKey, scenarioContext, featureContext)))}}}";
            var obj = JsonConvert.DeserializeObject<ExpandoObject>(json);
            return obj;
        }

        public static IEnumerable<object> CreateArray(this string[] contextKeys, ParameterInfo[] parameters, ScenarioContext scenarioContext, FeatureContext featureContext)
        {
            var results = new List<object>();
            for (var i = 0; i < parameters?.Length; i++)
            {
                var parameter = parameters[i]?.Name;
                var contextKey = contextKeys?.SingleOrDefault(x => x.Split(':')?.FirstOrDefault()?.Equals(parameter, StringComparison.OrdinalIgnoreCase) == true);
                results.Add(GetValue<dynamic>(contextKey ?? parameter, scenarioContext, featureContext).Value);
            }

            return results;
        }

        public static string GetEndpoint(this string route, string hostPrefix = null, string filter = null, string[] formatArgs = null)
        {
            var azureAdConfig = ConfigurationManager.GetSection("azureAd") as NameValueCollection;
            var apiUrl = azureAdConfig["ApiUrl"];
            var host = formatArgs == null ? apiUrl : string.Format(CultureInfo.InvariantCulture, apiUrl, formatArgs);
            var url = new Uri(new Uri(hostPrefix ?? host), route + (filter ?? string.Empty)).ToString();
            return formatArgs == null ? url : string.Format(CultureInfo.InvariantCulture, url, formatArgs);
        }

        public static bool HasTag(this IFeatureElement scenario, string tagName, bool returnFalseIfEmpty = false)
        {
            return scenario?.Tags?.HasTag(tagName) == true && (!returnFalseIfEmpty || !string.IsNullOrWhiteSpace(scenario?.Tags?.GetTag(tagName)));
        }

        public static bool HasTag(this Feature feature, string tagName, bool returnFalseIfEmpty = false)
        {
            return feature?.Tags?.HasTag(tagName) == true && (!returnFalseIfEmpty || !string.IsNullOrWhiteSpace(feature?.Tags?.GetTag(tagName)));
        }

        public static bool HasTag(this IEnumerable<string> tags, string tagName)
        {
            //// TODO: Equals instead of StartsWith?
            return tags?.Any(x => x?.StartsWith(tagName, StringComparison.OrdinalIgnoreCase) == true) == true;
        }

        public static string GetTag(this IFeatureElement scenario, string tagName)
        {
            return scenario?.Tags?.GetTag(tagName);
        }

        public static string GetTag(this Feature feature, string tagName)
        {
            return feature?.Tags?.GetTag(tagName);
        }

        public static string GetTag(this FeatureContext context, string tagName)
        {
            return context?.FeatureInfo.Tags?.GetTag(tagName);
        }

        public static string GetTag(this ScenarioContext context, string tagName)
        {
            return context?.ScenarioInfo.Tags?.GetTag(tagName);
        }

        public static string GetTag(this IEnumerable<string> tags, string tagName, bool removeAtTheRatePrefix = false)
        {
            if (removeAtTheRatePrefix)
            {
                tagName = tagName?.TrimStart('@');
            }

            try
            {
                return tags?.SingleOrDefault(x => x?.StartsWith(tagName, StringComparison.OrdinalIgnoreCase) == true && x.Contains('='))?.Split('=')?.LastOrDefault();
            }
            catch
            {
                //// Debugger.Break();
                Logger.Warn($"Duplicate Tags: {string.Join(" ", tags)} ({tagName})");
                return tags?.LastOrDefault(x => x?.StartsWith(tagName, StringComparison.OrdinalIgnoreCase) == true && x.Contains('='))?.Split('=')?.LastOrDefault();
            }
        }

        public static T GetTag<T>(this IEnumerable<string> tags, string tagName, bool removeAtTheRatePrefix = false)
        {
            return (T)Convert.ChangeType(tags?.GetTag(tagName, removeAtTheRatePrefix), typeof(T), CultureInfo.InvariantCulture);
        }

        public static int GetFeatureElementIndex(this List<string> featureLines, string scenarioName)
        {
            RegexSpecialChars.ForEach(x => scenarioName = scenarioName.Replace(x, $@"\{x}"));
            var regex = new Regex($"^{AnySpaces}({ScenarioPrefix}|{ScenarioOutlinePrefix}|{FeaturePrefix}){AnySpaces}({scenarioName})");
            var scenarioLine = featureLines.FindIndex(s => regex.Match(s).Success);
            return scenarioLine;
        }

        public static object[] GetConstructorContextParameters(this Type type, ScenarioContext scenarioContext, FeatureContext featureContext)
        {
            var constructorParams = type.GetConstructor(new[] { typeof(ScenarioContext), typeof(FeatureContext) }) != null ? new object[] { scenarioContext, featureContext } : null;
            if (constructorParams == null)
            {
                constructorParams = type.GetConstructor(new[] { typeof(FeatureContext), typeof(ScenarioContext) }) != null ? new object[] { featureContext, scenarioContext } : null;
            }

            if (constructorParams == null)
            {
                constructorParams = type.GetConstructor(new[] { typeof(ScenarioContext) }) != null ? new object[] { scenarioContext } : null;
            }

            if (constructorParams == null)
            {
                constructorParams = type.GetConstructor(new[] { typeof(FeatureContext) }) != null ? new object[] { featureContext } : null;
            }

            return constructorParams;
        }

        public static T GetContextValue<T>(this string key, T value, ScenarioContext scenarioContext, FeatureContext featureContext)
        {
            var result = value;
            var val = value?.ToString();
            var contextKey = key.ToPascalCase();
            if (string.IsNullOrWhiteSpace(val))
            {
                if (scenarioContext?.ContainsKey(contextKey.ToPascalCase()) == true)
                {
                    result = scenarioContext.Get<T>(contextKey.ToPascalCase());
                }
                else if (scenarioContext?.ContainsKey(contextKey) == true)
                {
                    result = scenarioContext.Get<T>(contextKey);
                }
                else if (featureContext?.ContainsKey(contextKey.ToPascalCase()) == true)
                {
                    result = featureContext.Get<T>(contextKey.ToPascalCase());
                }
                else if (featureContext?.ContainsKey(contextKey) == true)
                {
                    result = featureContext.Get<T>(contextKey);
                }
            }
            else if (val.Equals("{sc}", StringComparison.OrdinalIgnoreCase))
            {
                result = scenarioContext.Get<T>(contextKey);
            }
            else if (val.Equals("{fc}", StringComparison.OrdinalIgnoreCase))
            {
                result = featureContext.Get<T>(contextKey);
            }

            return result;
        }

        public static T GetCredential<T>(this ScenarioContext scenarioContext, FeatureContext parentContext, string role, string key)
            where T : Credentials, new()
        {
            // Remove this IF condition altogether so we only return the Creds when @input=Credentials.xlsx is set in the Features/Scenarios?
            if (!scenarioContext.ContainsKey(key))
            {
                var dataSource = scenarioContext.GetDataSource(parentContext, key);
                var result = Inputs.GetOrAdd(key, k => dataSource.ReadAsync<dynamic>().GetAwaiter().GetResult());
                scenarioContext[key] = result;
            }

            var delimiter = GenericExtensions.Delimiter;
            var testProject = GenericExtensions.TestProject;
            var userKey = (scenarioContext["Env"] ?? string.Empty) + delimiter + role;
            var user = (T)CredsList.GetOrAdd(userKey, k =>
            {
                var list = scenarioContext[key] as List<ExpandoObject>;
                var creds = list.ToList<T>()?.Where(z => string.IsNullOrWhiteSpace(z?.Env) || z?.Env?.Equals(scenarioContext["Env"]) == true);
                var items = creds?.OrderByDescending(x => x?.Role?.Length).Where(x => role?.EqualsIgnoreCase(x?.Role) == true)?.ToList();
                return items?.SingleOrDefault(x => items?.Count == 1 || !string.IsNullOrWhiteSpace(x?.Env)) ?? items?.FirstOrDefault(); // TODO: SingleOrDefault
            });

            if (string.IsNullOrWhiteSpace(user.Password))
            {
                // Windows Credentials Manager - Generic Credential Format:
                //  Internet or network address: ProjectName.Env.Role.UserName
                //  User name: ProjectName.Env.Role.UserName
                //  Password: Your password
                //  NOTE: If the Env or Role is blank, leave the . in place. e.g.: ProjectName...UserName
                var secretKey = string.IsNullOrWhiteSpace(user.SecretKey) ? $"{testProject}{delimiter}{user.Env ?? string.Empty}{delimiter}{user.Role ?? string.Empty}{delimiter}{user.User}" : $"{testProject}{delimiter}{user.SecretKey}";
                Logger.Info($"secretKey: {secretKey}");
                user.Password = Creds.GetOrAdd(secretKey, k =>
                {
                    var pwd = string.Empty;

                    // Check if the pwd is passed via run-settings (e.g. via AzDO pipeline variable)
                    if (ConfigurationManager.AppSettings.AllKeys.Contains(secretKey))
                    {
                        pwd = ConfigurationManager.AppSettings[secretKey];
                    }

                    try
                    {
                        if (string.IsNullOrWhiteSpace(pwd))
                        {
                            pwd = CredentialManager.GetCredentials(secretKey)?.Password;
                        }
                    }
                    catch
                    {
                        // Do nothing
                    }

                    try
                    {
                        if (string.IsNullOrWhiteSpace(pwd))
                        {
                            // KeyVault doesn't support special-chars (other than hyphen) in the names
                            var keyVaultSecretKey = secretKey.Replace("@", delimiter).Replace("_", delimiter).Replace(".", delimiter);
                            pwd = KeyVaultHelper.GetKeyVaultSecretAsync(keyVaultSecretKey).GetAwaiter().GetResult().Value;
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Warn($"GetCredential: {ex.ToFullStringAsync().GetAwaiter().GetResult()}");
                    }

                    return pwd;
                });
            }

            Logger.Debug($"GetCredential: user={user?.ToString() ?? string.Empty}");
            return user;
        }

        public static IDataSource GetDataSourceByExtension(this ScenarioContext scenarioContext, FeatureContext featureContext, string fullFilePath)
        {
            return GetDataSourceByExtensionInternal(scenarioContext, featureContext, fullFilePath);
        }

        public static IDataSource GetDataSourceByExtension(this FeatureContext featureContext, ScenarioContext scenarioContext, string fullFilePath)
        {
            return GetDataSourceByExtensionInternal(scenarioContext, featureContext, fullFilePath);
        }

        public static void LogToReport(this SpecFlowContext context, object message)
        {
            if (!context.ContainsKey(ReportGenerator.ReportLogs))
            {
                context.Set(new List<object>(), ReportGenerator.ReportLogs);
            }

            var logs = context.Get<List<object>>(ReportGenerator.ReportLogs);
            logs.Add(message);
            Logger.Trace(message.ToString());
        }

        public static void LogToReport(this SpecFlowContext context, string key, object value)
        {
            context.LogToReport($"{key} = {value}");
        }

        public static DriverContext GetDriverContext(this ScenarioContext scenarioContext)
        {
            DriverContext driverContext = null;
            if (scenarioContext?.TryGetValue(nameof(DriverContext), out driverContext) == true)
            {
                return driverContext;
            }

            return null;
        }

        private static IDataSource GetDataSourceInternal(ScenarioContext scenarioContext, FeatureContext featureContext, string tag)
        {
            var keyValue = tag.Split(new[] { TagDelimiter }, StringSplitOptions.RemoveEmptyEntries);
            var folder = ConfigurationManager.AppSettings[keyValue.FirstOrDefault()];
            var file = keyValue.LastOrDefault();
            string extension = null;
            try
            {
                extension = Path.GetExtension(file);
            }
            catch (Exception ex)
            {
                Logger.Error(ex.ToFullStringAsync().GetAwaiter().GetResult());
            }

            // Null means runtime-method
            if (!string.IsNullOrWhiteSpace(extension) && DataSources.ContainsKey(extension))
            {
                var fullPath = Path.Combine(folder, file);
                return GetDataSourceByExtensionInternal(scenarioContext, featureContext, fullPath);
            }

            return new RuntimeInvocationDataSource { Input = tag, ScenarioContext = scenarioContext, FeatureContext = featureContext };
        }

        private static IDataSource GetDataSourceByExtensionInternal(ScenarioContext scenarioContext, FeatureContext featureContext, string fullFilePath)
        {
            var extension = Path.GetExtension(fullFilePath);
            var dataSource = (IDataSource)Activator.CreateInstance(DataSources[extension]);
            dataSource.Input = fullFilePath;
            dataSource.ScenarioContext = scenarioContext;
            dataSource.FeatureContext = featureContext;
            return dataSource;
        }

        private static async Task<bool> SetInternal<T>(this SpecFlowContext context, IDataSource dataSource, string tag, string setterKey = null)
        {
            if (dataSource != null)
            {
                if (tag.StartsWith(DataSourceTags.InputTag, StringComparison.OrdinalIgnoreCase))
                {
                    try
                    {
                        var result = Inputs.GetOrAdd(setterKey ?? tag, key =>
                        {
                            return dataSource.ReadAsync<T>().GetAwaiter().GetResult();
                        }); // TODO: Have another method for ReadAllAsync?
                        Logger.Debug($"SetInternal: result={result?.ToString() ?? string.Empty}");
                        context[setterKey ?? tag] = result;
                    }
                    catch (Exception ex)
                    {
                        Logger.Warn(ex);
                        return false;
                    }
                }
                else if (tag.StartsWith(DataSourceTags.OutputTag, StringComparison.OrdinalIgnoreCase))
                {
                    context[setterKey ?? tag] = dataSource;
                }
                else if (tag.StartsWith(DataSourceTags.BeforeTag, StringComparison.OrdinalIgnoreCase)
                    || tag.StartsWith(DataSourceTags.AfterTag, StringComparison.OrdinalIgnoreCase)
                    || tag.StartsWith(DataSourceTags.ChaosTag, StringComparison.OrdinalIgnoreCase))
                {
                    var result = await dataSource.ReadAsync<T>().ConfigureAwait(false);
                    context[setterKey ?? tag] = result;
                }

                return true;
            }

            return false;
        }

#pragma warning disable SA1008 // Opening parenthesis must be spaced correctly
        private static (string Key, T Value) GetValue<T>(string contextKey, ScenarioContext scenarioContext, FeatureContext featureContext)
        {
            var value = default(T);
            var split = contextKey.SplitOrDefault(':');
            var key = split.FirstOrDefault();
            if (split.Length > 1)
            {
                var val = (T)Convert.ChangeType(split.LastOrDefault(), typeof(T), CultureInfo.InvariantCulture);
                value = key.GetContextValue<T>(val, scenarioContext, featureContext);
            }

            return (key, value);
        }

        private static string GetJsonValue<T>(string contextKey, ScenarioContext scenarioContext, FeatureContext featureContext)
        {
            var (key, value) = GetValue<T>(contextKey, scenarioContext, featureContext);
            var json = GetJsonPair(key, value);
            return json;
        }

        private static string GetJsonPair(string key, dynamic value)
        {
            dynamic val = value == null ? "null" : (value.GetType() == typeof(string) ? $"'{value}'" : value);
            return $"'{key}': {val}";
        }
#pragma warning restore SA1008 // Opening parenthesis must be spaced correctly
    }
}