﻿// <copyright file="KeyVaultHelper.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>

namespace Bdd.Core.Utils
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.IO;
    using System.Security;
    using System.Threading.Tasks;

    using Microsoft.Azure.KeyVault;
    using Microsoft.Azure.KeyVault.Models;
    using Microsoft.Azure.Services.AppAuthentication;
    using Microsoft.IdentityModel.Clients.ActiveDirectory;

    using NLog;

    public static class KeyVaultHelper
    {
        private static readonly ConcurrentDictionary<string, string> AccessTokens = new ConcurrentDictionary<string, string>();
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        public static string EncryptSecret { get; set; }

        private static NameValueCollection Settings => ConfigurationManager.GetSection("keyVault") as NameValueCollection ?? throw new ConfigurationErrorsException("keyVault");

        private static string KeyPrefix { get; set; }

        public static async Task<SecretBundle> GetKeyVaultSecretAsync(string clientSecretKey, string keyPrefix = null)
        {
            var vaultUri = new Uri(Settings.GetValue("VaultUri", keyPrefix));
            var secret = await GetKeyVaultSecretAsync(vaultUri, clientSecretKey, keyPrefix).ConfigureAwait(false);
            return secret;
        }

        public static async Task<SecretBundle> GetKeyVaultSecretAsync(Uri vaultUri, string clientSecretKey, string keyPrefix = null)
        {
            KeyPrefix = keyPrefix;
            var secretUri = $"{vaultUri}{clientSecretKey}";
            using (var keyVaultClient = GetKeyVaultClient())
            {
                var secret = await keyVaultClient.GetSecretAsync(secretUri).ConfigureAwait(false);
                return secret;
            }
        }

        public static async Task<bool> EnableDisableSecretAsync(string clientSecretKey, bool enable, string keyPrefix = null)
        {
            try
            {
                KeyPrefix = keyPrefix;
                using (var keyVaultClient = GetKeyVaultClient())
                {
                    var vaultUri = new Uri(Settings.GetValue("VaultUri", keyPrefix));
                    var secretUri = $"{vaultUri}{clientSecretKey}";
                    var attributes = new SecretAttributes { Enabled = enable }; // , Expires = expiryTime, NotBefore
                    await keyVaultClient.UpdateSecretAsync(secretUri, null, attributes).ConfigureAwait(false);
                    return true;
                }
            }
#pragma warning disable CA1031 // Do not catch general exception types
            catch (Exception ex)
            {
                Logger.Error(ex.ToFullStringAsync());
                return false;
            }
#pragma warning restore CA1031 // Do not catch general exception types
        }

        public static async Task<string> GetAccessTokenAsync(string authority, string resource, string clientId, string clientSecret)
        {
            var authContext = new AuthenticationContext(authority, TokenCache.DefaultShared);
            var clientCredentials = GetClientCredential(clientId, clientSecret);
            var result = await authContext.AcquireTokenAsync(resource, clientCredentials).ConfigureAwait(false);

            if (result == null)
            {
                throw new InvalidOperationException($"Unable to get token for application {clientId}");
            }

            return result.AccessToken;
        }

        public static ClientCredential GetClientCredential(string clientId, string clientSecret)
        {
            if (string.IsNullOrWhiteSpace(clientId) || string.IsNullOrWhiteSpace(clientSecret))
            {
                return null;
            }

            return new ClientCredential(clientId, clientSecret);
        }

        public static ClientAssertionCertificate GetCertificate(string certThumbprint, string clientId)
        {
            if (certThumbprint == null)
            {
                return null;
            }

            var clientAssertionCertPfx = CertificateHelper.GetCertificateByThumbprint(certThumbprint);
            return new ClientAssertionCertificate(clientId, clientAssertionCertPfx);
        }

        public static ClientAssertionCertificate GetCertificate(string certPath, SecureString certPwd, string clientId)
        {
            if (string.IsNullOrWhiteSpace(certPath) || !File.Exists(certPath))
            {
                return null;
            }

            var clientAssertionCertPfx = CertificateHelper.GetCertificateByPath(certPath, certPwd);
            return new ClientAssertionCertificate(clientId, clientAssertionCertPfx);
        }

        private static ClientAssertionCertificate GetCertificate(string keyPrefix = null)
        {
            var clientId = Settings.GetValue("ClientId", keyPrefix);
            var certThumbprint = Settings.GetValue("CertThumbprint", keyPrefix);

            if (!string.IsNullOrWhiteSpace(certThumbprint))
            {
                var clientAssertionCertPfx = CertificateHelper.GetCertificateByThumbprint(certThumbprint);
                return new ClientAssertionCertificate(clientId, clientAssertionCertPfx);
            }
            else
            {
                var certPath = Settings.GetValue("CertPath", keyPrefix);
                if (string.IsNullOrWhiteSpace(certPath))
                {
                    return null;
                }
                else
                {
                    using (var certPwd = new SecureString())
                    {
                        foreach (var c in Settings.GetValue("CertPwd", keyPrefix, true))
                        {
                            certPwd.AppendChar(c);
                        }

                        var clientAssertionCertPfx = CertificateHelper.GetCertificateByPath(certPath.GetFullPath(), certPwd);
                        return new ClientAssertionCertificate(clientId, clientAssertionCertPfx);
                    }
                }
            }
        }

        private static Task<string> GetAccessTokenAsync(string authority, string resource, string scope)
        {
            if (string.IsNullOrWhiteSpace(authority) || string.IsNullOrWhiteSpace(resource))
            {
                return Task.FromResult(string.Empty);
            }

            var accessToken = AccessTokens.GetOrAdd($"{authority}{resource}{scope}", k =>
            {
                var context = new AuthenticationContext(authority, TokenCache.DefaultShared);
                AuthenticationResult result = null;
                var cert = GetCertificate(KeyPrefix);
                if (cert != null)
                {
                    result = context.AcquireTokenAsync(resource, cert).GetAwaiter().GetResult();
                }
                else
                {
                    var creds = GetClientCredential(Settings.GetValue("ClientId", KeyPrefix), Settings.GetValue("ClientSecret", KeyPrefix, true));
                    if (creds != null)
                    {
                        result = context.AcquireTokenAsync(resource, creds).GetAwaiter().GetResult();
                    }
                }

                var token = result?.AccessToken;
                return token;
            });

            return Task.FromResult(accessToken);
        }

        private static KeyVaultClient.AuthenticationCallback KeyVaultAuthTokenCallback()
        {
            var azureServiceTokenProvider = new AzureServiceTokenProvider();
            return new KeyVaultClient.AuthenticationCallback(azureServiceTokenProvider.KeyVaultTokenCallback);
        }

        private static KeyVaultClient GetKeyVaultClient(string keyPrefix = null)
        {
            if (string.IsNullOrWhiteSpace(Settings.GetValue("CertThumbprint", keyPrefix)) && string.IsNullOrWhiteSpace(Settings.GetValue("ClientId", keyPrefix)) && string.IsNullOrWhiteSpace(Settings.GetValue("ClientSecret", keyPrefix)))
            {
                return new KeyVaultClient(KeyVaultAuthTokenCallback());
            }
            else
            {
                // For Managed Identity: https://docs.microsoft.com/en-us/azure/key-vault/service-to-service-authentication#authenticating-with-visual-studio
                // AzureServicesAuthConnectionString = "RunAs=App;AppId=AppId;TenantId=TenantId;CertificateThumbprint=Thumbprint;CertificateStoreLocation=CurrentUser"
                // AzureServicesAuthConnectionString = $"RunAs=App;AppId=AppId;TenantId=TenantId;AppKey={KeyVaultSettings.GetValue("ClientSecret", KeyPrefix)}"
                // To disable Managed Identity on AppService/AzFunction: Set WEBSITE_DISABLE_MSI setting to true
                return new KeyVaultClient(GetAccessTokenAsync);
            }
        }
    }
}