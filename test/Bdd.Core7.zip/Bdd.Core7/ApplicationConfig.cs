﻿// <copyright file="ApplicationConfig.cs" company="Microsoft">
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//    THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//    OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//    ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//    OTHER DEALINGS IN THE SOFTWARE.
// </copyright>

namespace Bdd.Core
{
    using System;
    using System.Configuration;
    using System.Linq;
    using System.Reflection;

    using Bdd.Core.Utils;

    /// <summary>
    /// Credit: https://stackoverflow.com/a/6151688, https://stackoverflow.com/a/1838960
    /// </summary>
    public abstract class ApplicationConfig : Disposable
    {
        public static ApplicationConfig Change(string path)
        {
            return new ChangeAppConfig(path);
        }

        private class ChangeAppConfig : ApplicationConfig
        {
            private readonly string oldConfig =
                AppDomain.CurrentDomain.GetData("APP_CONFIG_FILE").ToString();

            public ChangeAppConfig(string path)
            {
                AppDomain.CurrentDomain.SetData("APP_CONFIG_FILE", path);
                ResetConfigMechanism();
            }

            protected override void DisposeManagedResources()
            {
                AppDomain.CurrentDomain.SetData("APP_CONFIG_FILE", this.oldConfig);
                ResetConfigMechanism();
            }

            private static void ResetConfigMechanism()
            {
                typeof(ConfigurationManager).GetField("s_initState", BindingFlags.NonPublic | BindingFlags.Static).SetValue(null, 0);
                typeof(ConfigurationManager).GetField("s_configSystem", BindingFlags.NonPublic | BindingFlags.Static).SetValue(null, null);
                typeof(ConfigurationManager).Assembly.GetTypes().First(x => x.FullName == "System.Configuration.ClientConfigPaths").GetField("s_current", BindingFlags.NonPublic | BindingFlags.Static).SetValue(null, null);
            }
        }
    }
}
