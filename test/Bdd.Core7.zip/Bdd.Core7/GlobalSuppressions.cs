﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="GlobalSuppressions.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using System.Diagnostics.CodeAnalysis;

[assembly: SuppressMessage("StyleCop.CSharp.SpacingRules", "SA1008:Opening parenthesis must be spaced correctly", Justification = "New convention for Tuples", Scope = "member", Target = "~M:Bdd.Core.DataSources.RuntimeInvocationDataSource.Execute``1(System.String)~``0")]

[assembly: SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1629:Documentation text should end with a period", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.DataSources.DocDbDataSource")]
[assembly: SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1629:Documentation text should end with a period", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.DataSources.ExcelDataSource")]
[assembly: SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1629:Documentation text should end with a period", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.Docs.DocProcessor")]
[assembly: SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1629:Documentation text should end with a period", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.Hooks.TestDataHooks")]
[assembly: SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1629:Documentation text should end with a period", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.Utils.ReportGenerator")]

[assembly: SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.DataSources.ExcelDataSource")]
[assembly: SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.DataSources.SqlDataSource")]
[assembly: SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.Docs.DocProcessor")]
[assembly: SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.Utils.ReportGenerator")]
[assembly: SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.Executors.ConsoleExecutor")]
[assembly: SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.Utils.SpecFlowExtensions")]
[assembly: SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.Utils.GenericExtensions")]
[assembly: SuppressMessage("Design", "CA1031:Do not catch general exception types", Justification = "Minor", Scope = "type", Target = "~T:Bdd.Core.Hooks.TestDataHooks")]

[assembly: SuppressMessage("Reliability", "CA2000:Dispose objects before losing scope", Justification = "Required to retain the instance", Scope = "member", Target = "~M:Bdd.Core.Utils.KeyVaultHelper.GetCertificate(System.String,System.Security.SecureString,System.String)~Microsoft.IdentityModel.Clients.ActiveDirectory.ClientAssertionCertificate")]
[assembly: SuppressMessage("Reliability", "CA2000:Dispose objects before losing scope", Justification = "Required to retain the instance", Scope = "member", Target = "~M:Bdd.Core.Utils.KeyVaultHelper.GetCertificate(System.String)~Microsoft.IdentityModel.Clients.ActiveDirectory.ClientAssertionCertificate")]

[assembly: SuppressMessage("Design", "CA1056:Uri properties should not be strings", Justification = "Minor", Scope = "member", Target = "~P:Bdd.Core.Entities.AzureAdBase.AuthUrl")]