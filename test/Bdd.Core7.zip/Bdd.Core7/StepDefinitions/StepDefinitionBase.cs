﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="StepDefinitionBase.cs" company="Microsoft">
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//   THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
//   OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
//   ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Bdd.Core.StepDefinitions
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.IO;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Runtime.CompilerServices;
    using System.Threading.Tasks;
    using System.Xml.Linq;
    using AgileObjects.ReadableExpressions;

    using Bdd.Core.Entities;
    using Bdd.Core.Entities.Tags;
    using Bdd.Core.Utils;
    using global::Bdd.Core.DataSources;

    using KellermanSoftware.CompareNetObjects;
    using Newtonsoft.Json.Linq;
    using NLog;

    using NUnit.Framework;

    using Ocaramba;

    using TechTalk.SpecFlow;

    public class StepDefinitionBase : Steps
    {
        protected static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        private const int MaxDifferences = 200;

        private const bool IgnoreCollectionOrder = true;

        private const bool CaseSensitive = true;

        private readonly bool enableScreenShot = string.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["SeleniumScreenShotEnabled"]) ? false : bool.Parse(ConfigurationManager.AppSettings["SeleniumScreenShotEnabled"]);

        private readonly bool enableSavePageSource = string.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["GetPageSourceEnabled"]) ? false : bool.Parse(ConfigurationManager.AppSettings["GetPageSourceEnabled"]);

        public virtual Credentials UserDetails => this.ScenarioContext.ContainsKey(nameof(this.UserDetails)) ? this.ScenarioContext.Get<Credentials>(nameof(this.UserDetails)) : new Credentials();

        public DriverContext DriverContext
        {
            get
            {
                return this.ScenarioContext.GetDriverContext();
            }
        }

        protected ExcelDataSource ExcelHandler => new ExcelDataSource();

        protected int ImplicitlyWaitMilliseconds => (int)BaseConfiguration.ImplicitlyWaitMilliseconds;

        /// <summary>
        /// Gets the first DataSource from the @input tag.
        /// </summary>
        /// <value>
        /// The first DataSource from the @input tag.
        /// </value>
        protected dynamic Input
        {
            get
            {
                return this.Inputs.FirstOrDefault();
            }
        }

        /// <summary>
        /// Gets all the results for @input tags.
        /// </summary>
        /// <value>
        /// All results for @input tags.
        /// </value>
        protected IEnumerable<dynamic> Inputs
        {
            get
            {
                var inputs = this.ScenarioContext.ScenarioInfo?.Tags?.Where(t => t.StartsWith(DataSourceTags.InputTag, StringComparison.OrdinalIgnoreCase)).ToList();
                if (inputs?.Count > 0)
                {
                    return inputs.ConvertAll(input =>
                    {
                        this.ScenarioContext.TryGetValue(input, out dynamic result);
                        return result;
                    });
                }
                else
                {
                    inputs = this.FeatureContext.FeatureInfo?.Tags?.Where(t => t.StartsWith(DataSourceTags.InputTag, StringComparison.OrdinalIgnoreCase)).ToList();
                    return inputs.ConvertAll(input =>
                    {
                        this.FeatureContext.TryGetValue(input, out dynamic result);
                        return result;
                    });
                }
            }
        }

        /// <summary>
        /// Gets the first DataSource for @output tag.
        /// </summary>
        /// <value>
        /// The first DataSource for @output tag.
        /// </value>
        protected IDataSource Output
        {
            get
            {
                return this.Outputs.FirstOrDefault();
            }
        }

        /// <summary>
        /// Gets all the DataSources for @output tags.
        /// </summary>
        /// <value>
        /// All DataSources for @output tags.
        /// </value>
        protected IEnumerable<IDataSource> Outputs
        {
            get
            {
                var outputs = this.ScenarioContext.ScenarioInfo?.Tags?.Where(t => t.StartsWith(DataSourceTags.OutputTag, StringComparison.OrdinalIgnoreCase)).ToList();
                if (outputs?.Count > 0)
                {
                    return outputs.ConvertAll(output =>
                    {
                        this.ScenarioContext.TryGetValue(output, out IDataSource result);
                        return result;
                    });
                }
                else
                {
                    outputs = this.FeatureContext.FeatureInfo?.Tags?.Where(t => t.StartsWith(DataSourceTags.OutputTag, StringComparison.OrdinalIgnoreCase)).ToList();
                    return outputs.ConvertAll(output =>
                    {
                        this.FeatureContext.TryGetValue(output, out IDataSource result);
                        return result;
                    });
                }
            }
        }

        private SqlDataSource SqlHandler => new SqlDataSource();

        private List<Action> Asserts
        {
            get
            {
                if (this.ScenarioContext.TryGetValue("Asserts", out List<Action> asserts))
                {
                    return asserts;
                }

                return new List<Action>();
            }
        }

        public Task<T> ReadSqlScalarAsync<T>(string input, string keyPrefix = null, params object[] args)
        {
            return this.SqlHandler.ReadAsync<T>(input, keyPrefix, args);
        }

        public Task<IDictionary<string, object>> ReadSqlAsDictionaryAsync(string input, string keyPrefix = null, params object[] args)
        {
            return this.SqlHandler.ReadAsDictionaryAsync(input, keyPrefix, args);
        }

        public Task<IDictionary<string, string>> ReadSqlAsStringDictionaryAsync(string input, string keyPrefix = null, params object[] args)
        {
            return this.SqlHandler.ReadAsStringDictionaryAsync(input, keyPrefix, args);
        }

        public Task<dynamic> ReadSqlAsync(string input, string keyPrefix = null, params object[] args)
        {
            return this.SqlHandler.ReadAsExpandoAsync(input, keyPrefix, args);
        }

        public Task<IEnumerable<IDictionary<string, object>>> ReadAllSqlAsDictionaryAsync(string input, string keyPrefix = null, params object[] args)
        {
            return this.SqlHandler.ReadAllAsDictionaryAsync(input, keyPrefix, args);
        }

        public Task<IEnumerable<dynamic>> ReadAllSqlAsync(string input, string keyPrefix = null, params object[] args)
        {
            return this.SqlHandler.ReadAllAsExpandoAsync(input, keyPrefix, args);
        }

        public Task<IEnumerable<T>> ReadAllSqlAsync<T>(string input, string keyPrefix = null, params object[] args)
        {
            return this.SqlHandler.ReadAllAsync<T>(input, keyPrefix, args);
        }

        public async Task<bool> AssertDiscrepancies<T>(Task<ICollection<T>> expected, Task<ICollection<T>> actual, bool caseSensitive = CaseSensitive, int maxDifferences = MaxDifferences, bool ignoreCollectionOrder = IgnoreCollectionOrder, [CallerFilePath] string file = "", [CallerMemberName] string member = "", [CallerLineNumber] int line = 0)
        {
            var message = this.GetMessage(file, member, line);

            var e = await expected.ConfigureAwait(false);
            Assert.IsNotNull(e, message);
            Assert.NotZero(e.Count, message);

            var a = await actual.ConfigureAwait(false);
            Assert.IsNotNull(a, message);
            Assert.NotZero(a.Count, message);

            return this.VerifyDiffs(e, a, caseSensitive, maxDifferences, ignoreCollectionOrder, warnOnly: false);
        }

        public bool VerifyDiffs(dynamic expected, dynamic actual, bool caseSensitive = CaseSensitive, int maxDifferences = MaxDifferences, bool ignoreCollectionOrder = IgnoreCollectionOrder, bool treatStringEmptyAndNullTheSame = true, bool warnOnly = true)
        {
            var compareLogic = new CompareLogic
            {
                Config = new ComparisonConfig
                {
                    MaxDifferences = maxDifferences,
                    IgnoreCollectionOrder = ignoreCollectionOrder,
                    TreatStringEmptyAndNullTheSame = treatStringEmptyAndNullTheSame,
                    MaxMillisecondsDateDifference = DateTime.MaxValue.Millisecond,
                    CaseSensitive = caseSensitive,
                },
            };

            var comparison = compareLogic.Compare(expected, actual);
            if (warnOnly)
            {
                this.WarnIf(comparison.Differences.Count > 0, comparison.DifferencesString);
            }
            else
            {
                this.VerifyThat(() => Assert.IsEmpty(comparison.Differences, comparison.DifferencesString));
            }

            return comparison.Differences.Count == 0;
        }

        public void VerifyThat(Action assert)
        {
            if (this.DriverContext == null)
            {
                this.Asserts?.Add(assert);
            }
            else
            {
                Verify.That(this.DriverContext, assert, this.enableScreenShot, this.enableSavePageSource);
            }
        }

        public void VerifyThat(params Action[] asserts)
        {
            if (this.DriverContext == null)
            {
                this.Asserts?.AddRange(asserts);
            }
            else
            {
                Verify.That(this.DriverContext, this.enableScreenShot, this.enableSavePageSource, asserts);
            }
        }

        public bool WarnDiscrepancies<T>(ICollection<T> expected, ICollection<T> actual, bool caseSensitive = CaseSensitive, int maxDifferences = MaxDifferences, bool ignoreCollectionOrder = IgnoreCollectionOrder, [CallerFilePath] string file = "", [CallerMemberName] string member = "", [CallerLineNumber] int line = 0)
        {
            var message = this.GetMessage(file, member, line);

            this.WarnIf(expected == null || expected.Count == 0, message);
            this.WarnIf(actual == null || actual.Count == 0, message);

            return this.VerifyDiffs(expected, actual, caseSensitive, maxDifferences, ignoreCollectionOrder);
        }

        public void WarnIf(Expression<Func<bool>> condition, string message = null, [CallerFilePath] string file = "", [CallerMemberName] string member = "", [CallerLineNumber] int line = 0)
        {
            if (condition.Compile().Invoke())
            {
                Assert.Warn($"{message ?? this.GetMessage(file, member, line)} - {condition.ToReadableString()}");
            }
        }

        public async Task WarnIf(Expression<Func<Task<bool>>> condition, string message = null, [CallerFilePath] string file = "", [CallerMemberName] string member = "", [CallerLineNumber] int line = 0)
        {
            if (await condition.Compile().Invoke().ConfigureAwait(false))
            {
                Assert.Warn($"{message ?? this.GetMessage(file, member, line)} - {condition.ToReadableString()}");
            }
        }

        public void WarnIf(bool condition, string message, [CallerFilePath] string file = "", [CallerMemberName] string member = "", [CallerLineNumber] int line = 0)
        {
            if (condition)
            {
                Assert.Warn($"{message ?? this.GetMessage(file, member, line)} - {message}");
            }
        }

        protected void LogToReport(object message)
        {
            this.ScenarioContext.StepContext.LogToReport(message);
        }

        protected void LogToReport(string key, object value)
        {
            this.LogToReport($"{key} = {value}");
        }

        protected string GetValue(string key)
        {
            if (this.ScenarioContext.ContainsKey(key))
            {
                return this.ScenarioContext.Get<string>(key);
            }

            return null;
        }

        protected T GetValue<T>(string key)
        {
            if (this.ScenarioContext.ContainsKey(key))
            {
                return this.ScenarioContext.Get<T>(key);
            }

            return default(T);
        }

        protected void SetValue<T>(string key, T value)
        {
            this.ScenarioContext.Set<T>(value, key);
        }

        private string GetMessage(string file = "", string member = "", int line = 0)
        {
            return $"{member} ({Path.GetFileNameWithoutExtension(file)}#{line})";
        }
    }
}